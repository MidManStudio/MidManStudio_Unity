# StickToTheDeath: Moving the Player to the PSD Rig

## Overview

The player is moving from `SuperiorPlayer.prefab` (one skinned body sprite plus two separate
arm sprites) to `Stickman_Base.prefab` (the PSD rig, with 2D IK limb solvers already added on
both arms and both legs). `BotPlayer.prefab` has the same skeleton and arm layout as
`SuperiorPlayer` and swaps the player scripts for bot scripts, so the same arrangement applies
to it.

No script looks up a bone or child by name. Everything goes through serialized references, so
the move is prefab wiring. The code that assumed the old rig is `PlayerInitializer` and
`PlayerDamageFlash` and `PlayerMovementController` (the renderers), `PlayerAnimationController` and `BotAnimationController`
(animator state names), and the death flow (the separate ragdoll object). All of them now handle the
PSD rig.

## Old player layout

`SuperiorPlayer.prefab` has 75 GameObjects and 39 scripts.

| Part | Contents |
|---|---|
| Root (layer 3, tag `Player`) | Body `SpriteRenderer` (sorting order 26) with `SpriteSkin`, the IK manager listing four solvers, `CapsuleCollider2D` (0.8 by 4, offset 0.05, 0.85), `Rigidbody2D` (dynamic, gravity 5, continuous detection, rotation frozen), two `AudioSource`, `Animator` (`SuperiorPlayer.controller`) and all player and network scripts |
| `Arm_Holder` (layer 10) | `ArmMove`, `ArmMovementController`, `ArmAnimationController`, `ItemNetTransform`, `ArmsRecoilController`, `Animator` (`Arm_Holder.controller`), `ParentConstraint`. Children: the two arm limb solvers with targets, and the two arm sprites (right order 28, left order 22), each with its own three-bone chain. The right and left fist bones each hold a `Gun_Holder`, and the right fist also holds `GrenadeShotPoint` |
| Skeleton | `Torsobone.1`, `.2`, `.3` (head, collar, wing and `TorsoArmHolder` hang off `.3`), two three-bone legs, and two `Lower-ExtraBone` bones |
| Leg IK | `RightLegLimbSolver` and `LeftLegLimbSolver`, each with a `_Target`, directly under the root |
| Attach points | `FeetPos`, `FacePoint`, `Grnade_TrowingPoint`, `JetPack_Holder` (with `ParentConstraint`), `ConstraintAimHandler`, `farSummonLocation`, `closeSummonLocation` (all layer 10), `IgniteHolder` and `Helper` (layer 0) |
| Debug (inactive) | `ClientBelife`, `ServerBelife`, `AnimHelpers` |

## PSD rig layout

`Stickman_Base.psd` has 20 bones.

```
Body_Bone_1
  Body_Bone_2
    Body_Bone_3
      Right_Arm_Bone_1 > Right_Arm_Bone_2 > Right_Fist_Bone_1
      Left_Arm_Bone_1  > Left_Arm_Bone_2  > Left_Fist_Bone_1
  Head_Bone_1
    Hair_Bone_1 > Hair_Bone_2 > Hair_Bone_3
                > Hair_Bone_4
  Right_Leg_Bone_1 > Right_Leg_Bone_2 > Right_Leg_Bone_3
  Left_Leg_Bone_1  > Left_Leg_Bone_2  > Left_Leg_Bone_3
```

The PSD imports at 160 pixels per unit. Hip to ankle is about 1.46 units, against about 1.61 in the old
rig, so the proportions are close. `Stickman_Base.prefab` adds `IkSolvers/Legs` and `IkSolvers/Arms`
with four limb solvers and targets.

Rough bone mapping (old to new): `Torsobone.1/2/3` to `Body_Bone_1/2/3`, `HeadBone.1` to `Head_Bone_1`,
`Back-Hair-Bone.*` to `Hair_Bone_*`, leg bones to `*_Leg_Bone_1/2/3`, arm bones to `*_Arm_Bone_1/2` and
`*_Fist_Bone_1`. `Colar-Bone`, `IncaseOfIcasities-Wing-Bone`, `Lower-ExtraBone` and the head separators
have no PSD equivalent.

## Wiring to re-point on the new prefab

Fields that reference something inside the prefab (123 on the player). The ones that matter:

| Script | Field | Old target |
|---|---|---|
| `IAmPlayerServiceLocator` | `_armHandler` | `Arm_Holder` `ArmMove` |
| `IAmPlayerServiceLocator` | `_playerRightFist`, `_playerLeftFist` | the two `Gun_Holder` transforms |
| `IAmPlayerServiceLocator` | `_jetpackHolder`, `_igniteHolder` | `JetPack_Holder`, `IgniteHolder` |
| `IAmPlayerServiceLocator` | `_mainPlayerSpriteRenderer`, `_rightArmSpriteRenderer`, `_leftArmSpriteRenderer` | old body and arm renderers, only used by `get_BodyRenderers` when the applier has no resolvers, not needed on the PSD prefab |
| `PlayerInitializer` | `m_PsdSkinApplier` | the new `PsdStickmanSkinApplier` |
| `PlayerInitializer` | `m_PlayersSpriteRenderer` and the two arm renderers | not needed with the applier |
| IK manager | solver list | four limb solvers |
| `LegSwayController` | `_rightLegLimbSolver`, `_leftLegLimbSolver` | the leg solvers |
| `ArmAnimationController` | `_armAnimator`, `_rightHandLimbSolver`, `_leftHandLimbSolver` | `Arm_Holder` animator and arm solvers |
| `ArmMovementController` | `_limitedRotator` | `ConstraintAimHandler` |
| `ArmMove` | the three arm controllers | on `Arm_Holder` |
| `GrenadeHandler` | `_shotPoint` | `GrenadeShotPoint` |
| `PlayerMovementController` | `_feetPosition`, `_facePoint` | `FeetPos`, `FacePoint` |
| `PlayerEffectsController` | `_feetPosition` | `FeetPos` |
| `PlayerScoreSummonHandler` | `_closeSummonLocation`, `_farSummonLocation` | the two summon locations |
| `NetworkPredictionComponent` | `clientBeliefObj`, `serverBeliefObj` | the two belief objects |

The `SpriteLibrary` and the applier resolvers are set up by the editor tool `MidManStudio/Sttd/Stickman/2. Set Up Rig On Selected Prefab`.
See [editor tools](editor-tools.md).

The authority tint in `PlayerMovementController` colors every body renderer from `get_BodyRenderers`, so it needs no
reference. The player flips by turning the root 180 degrees around Y, not by scaling.
`PlayerMovementController.IsFacingRight` reads the flip state of the arm handler and falls back to
`localScale.x` only when `_armHandler` is empty. That scale never changes with this flip, so keep `_armHandler`
assigned or the camera treats the player as always facing right.

## Animation

The player clips animate very few transforms:

| Animated transform | Curve types | Clips |
|---|---|---|
| `LeftLegLimbSolver`, `RightLegLimbSolver` | position, euler | all locomotion clips |
| `Torsobone.1` | position | all locomotion clips |
| `RightArmLimbSolver`, `LeftArmLimbSolver` | position, euler | all arm clips |
| `Gun_Holder`, `GrenadeShotPoint` under the right fist | position | four arm clips |
| hair, collar, wing, extra and head separator bones | rotation | idle clip only |

`Arm-Ideal`, `Player-WeaponSwap-Anim` and `Player-WeaponSwitch-Anim` have no curves.

Because the clips move IK solvers rather than bones, they can transfer if the solver objects keep the
same names and the same place in the hierarchy as the Animator's root, with a position offset so the rest
pose matches the new rig. `Torsobone.1` position curves are absolute values and need an offset to
`Body_Bone_1`. Hair and extra bone rotations would need re-authoring.

## Layer and sorting reminders

- Root: layer 3, tag `Player`. `Arm_Holder` and the attach points are layer 10, except `IgniteHolder` and `Helper`, which are layer 0.
- Sorting: left arm 22, body 26, right arm 28, summon locations 8. The PSD importer sets one order per
  layer, so keep the left arm behind the body and the right arm in front.

## Decisions

- **Arms:** the arm bones are already in the PSD rig and `Stickman_Base` already has the IK solvers, so the
  arm scripts and their references move over. Scripts that are not network objects can sit on an empty
  GameObject on the player.
- **Clips:** the old clips are not retargeted. `Stickman_Base.controller` has its own animations. Its
  state names differ from the old ones, so use the context menu "Use Stickman_Base state names" on
  `PlayerAnimationController` and `BotAnimationController`. The new controller has no slide state.
- **Ragdoll:** death only, in place, with `StickmanRigRagdoll`.
- **Body renderers:** `IAmPlayerServiceLocator.get_BodyRenderers` is the one place that says which renderers draw the body. It returns the PSD part renderers once the applier has resolvers, and the old body and two arm renderers before that, without nulls. `PlayerInitializer`, `PlayerDamageFlash` and the authority tint use it. The legacy writes in `PlayerInitializer` skip renderers that are not assigned. Weapons, the jetpack, the direction indicator and the old `RagDollHandler` keep their own renderers.

## Setting up the ragdoll

1. Add `StickmanRigRagdoll` to the player root, next to the root `Rigidbody2D`. The reset values find the
   animators and the IK manager.
2. Check that the 20 bones are found: names contain `_Bone_`.
3. Optionally set `_ragdollLayer` to a layer that collides with the ground only.
4. Test a death facing both directions. Turn on `_unflipRootOnActivate` if left-facing deaths misbehave.

Players and bots that have the component skip the separate ragdoll object. The ones without it keep the old
ragdoll, so the two prefabs can be moved over one at a time.

## ArmPoseDriver.cs

**What it does:** Moves the two arm IK targets and the grenade shot point through poses that are listed in the inspector.
It replaces the `Arm_Holder` animator. `ArmAnimationController` keeps deciding which pose is wanted from the arm state and
the facing, and calls `PlayPose`. The driver blends to that pose and runs its keys. `ArmMovementController` still aims,
because it turns the Arms group, and `ArmAnimationController` still switches the elbow flip of the two solvers per state.
The arms stay in IK all the time. There is no IK and FK weight switching in the scripts.

Setup on `Stickman_Base`:

1. Add `ArmPoseDriver` to `IkSolvers/Arms`. Adding it fills the pose list with the old clip values and finds
   `RightArm_LimbSolver` and `LeftArm_LimbSolver` by name. Assign them by hand if they are named differently.
2. Assign `Grenade_Shotpoint` to `_grenadeShotPoint`. Assign the right fist bone to `_grenadeFollow`, or leave it empty to follow the right hand target.
3. `ArmAnimationController` finds the driver on its own object. The arm `Animator` is not needed. When a driver is present it is not used.
4. Assign `_armHandler` on `IAmPlayerServiceLocator` to the `ArmMove`. When it is empty the locator searches its children once.
5. If one elbow bends backwards, tick `_invertRightFlip` or `_invertLeftFlip` on `ArmAnimationController`. In play mode the change shows at once.

**Decisions:**
- One pose per state and facing, so a pose has a normal and a flipped version. The values were read from the old clips and are not mirrored by code. The flipped grenade poses mirror the Y axis, the flipped vertical melee poses are turned 180 degrees, and the flipped vertical melee throw copies its keys as they were.
- The old clips moved only the two solver objects, so a pose is a position and a Z rotation per hand. A hand that a clip did not key stays at its rest pose, as the animator did with write defaults on. Idle is the rest pose that the targets have when the scene loads.
- A pose holds its last key. Only the vertical melee hold loops.
- `_blendTime` blends between poses over 0.08 s. The old animator cut with no blend, so set it to 0 to get that back. `_easeKeys` eases between keys.
- `_reachScale` and `_positionOffset` fit every pose to the length and shoulder of the new arm without editing each key.
- The grenade shot point used to sit on the right fist, and `GrenadeHandler` reads it for the held grenade, the trajectory preview and the throw direction. The driver moves it to the hand and turns it to the aim angle plus the key's `grenadeAngle`. The defaults are the hand rotation plus the rotation the old clip gave the point, which assumes the solver turns the fist to the target rotation.
- The two horizontal melee clips are not ported, because no script plays them.
- The state table in `ArmAnimationController` gives both hands the same elbow flip, as it did when both arms were identical chains. The new Left arm art is a mirror copy of the Right, so the same flip value can bend the two elbows opposite ways. `_invertRightFlip` and `_invertLeftFlip` flip the value the table gives one hand without touching the table.
- The execution order is 200, so the shot point is set after the IK manager has solved.

## Arm clips and the old animator

The old arm clips key `RightArmLimbSolver` and `LeftArmLimbSolver` by path under the object that holds the arm `Animator`.
`ArmAnimationController` still plays them when it has an `Animator` and no `ArmPoseDriver`, so the old setup keeps working. It
needs the two solver objects named `RightArmLimbSolver` and `LeftArmLimbSolver`. The `Gun_Holder` and `GrenadeShotPoint` curves in four
clips do not bind in the new prefab.

## IK and FK

The 2D IK package blends per solver: each solver has a weight from 0 to 1, and the IK manager has a global
weight. At 0 the bones follow the animation clips (FK), at 1 the solver drives the limb to its target (IK).
A switch is therefore a weight change, ideally eased over a few frames to avoid a pop. A common split is IK
for planted feet and for aiming arms, and FK for swings, hit reactions and secondary motion. Keep the clips
authored for whichever mode each limb is in at that moment.

## Bot prefab

`BotPlayer.prefab` is still the old rig: 8 sprite renderers and none of the PSD scripts. It is referenced only by
`PlayerSpawner-Manager.prefab`. Bot loadouts carry the five part items now, so a bot shows its character as soon
as the bot prefab has the rig and the applier. Until then it keeps the old skin.

What the two prefabs hold (script lists compared):

| On `Stickman_Base` and not on the bot | What to do on the bot prefab |
|---|---|
| `PsdStickmanSkinApplier`, `StickmanRigRagdoll`, `PlayerDamageFlash`, `DissolveEffectManager` | Needed. The bot scripts never call them, the damage and death code finds them on the entity. |
| `PlayerMovementController`, `PlayerInputCommands`, `PlayerAnimationController`, `PlayerEffectsController`, `NetworkPredictionComponent`, `PlayerDirectionalIndicatorSystem` | Human only, leave them off. |
| `ArmsRecoilController`, `PlayerDamageParticles` | The bot never had them. Decide, nothing in the bot scripts needs them. |

| On the bot and not on `Stickman_Base` (the bot brain) | |
|---|---|
| `NetBotPlayer`, `BotAICommands`, `BotMovementController`, `BotAnimationController`, `BotEffectsController`, `BotPathfindingModule`, `Seeker` | Add them with the values of `BotPlayer.prefab`. |

The simplest route is a copy of `Stickman_Base.prefab` (the rig and the shared wiring exist), with the human scripts
removed, the bot brain added and the fields below re-pointed. Anything that points at a component on the root
resolves by itself when all components sit on the root. These are the fields that point at a child object
(81 internal references on the bot scripts, about a dozen of them children):

| Script | Field | Target |
|---|---|---|
| `IAmPlayerServiceLocator` | `_armHandler` | `Arm_Holder` `ArmMove` |
| `IAmPlayerServiceLocator` | `_playerRightFist`, `_playerLeftFist` | the two `Gun_Holder` transforms |
| `IAmPlayerServiceLocator` | `_jetpackHolder`, `_igniteHolder` | `JetPack_Holder`, `IgniteHolder` |
| `IAmPlayerServiceLocator` | `_botController` | the `NetBotPlayer` |
| `PlayerInitializer` | `m_PsdSkinApplier` | the `PsdStickmanSkinApplier` (the old renderer fields are not needed) |
| `NetBotPlayer` | `_currentShotPoint` | `FacePoint` |
| `NetBotPlayer` | `retreetPoint` | `RetreetPoint` (a bot-only object, add it) |
| `NetBotPlayer` | `botPlayerArms` | the `Arm_Holder` object |
| `NetBotPlayer` | `limitedRotator` | `ConstraintAimHandler` |
| `NetBotPlayer` | `m_RightHandLimbSolver`, `m_LeftHandLimbSolver` | the two arm limb solvers |
| `BotMovementController`, `BotEffectsController` | `_feetPosition` | `FeetPos` |
| `GrenadeHandler` | `_shotPoint` | `GrenadeShotPoint` |
| `PlayerScoreSummonHandler` | `_closeSummonLocation`, `_farSummonLocation` | the two summon locations |
| `ArmMove`, `ArmAnimationController`, `ArmMovementController` | as in the table for the player | already on `Stickman_Base` |

Root settings that differ between a bot and a human, and must stay the bot values on the copy: layer 10 and tag
`Player`, `ClientNetTransform` authority mode 1 (client, which is the server for a server-owned bot),
`TeamPlayer` defaults, and the `NetworkObject` settings. `BotAnimationController` takes the same context menu as
the player controller, "Use Stickman_Base state names", because the PSD rig uses `Stickman_Base.controller`.

Death: `NetworkServerManeger.SpawnRagDoll` already uses the rig ragdoll for any victim that has a
`StickmanRigRagdoll`, bots included, so a bot with the component dies like a player. Watch the bot death and
respawn once, because `NetBotPlayer` turns its own components off and on around it.
