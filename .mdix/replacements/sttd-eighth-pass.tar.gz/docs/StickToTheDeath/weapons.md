# StickToTheDeath: weapons and jetpack

## Modules

### `PlayerMovementController.cs` (glide)
**What it does:** Player movement, jetpack flight states and fuel. Lives in `AG_PlayerScripts/Player`. The glide is the `ArcDescending` flight state.

**Decisions:**
- Gliding costs no fuel, because fuel only drains while the jump button is held and a glide starts after the button is released. Before the change a glide lasted as long as the player held a direction and had fuel, ending only on landing or when the direction was released. After 2 s the descent speed stayed at 0.4 times the flight force, and the horizontal speed kept the flight multiplier, so a glide from a high jetpack climb covered a long distance.
- New serialized field `_maxGlideDuration`, default 1.5 s. When one glide reaches it, the state changes to `Falling` and normal gravity returns. Using thrust again starts a new glide.
- The descent curve, flight force and speed multiplier are unchanged.

### `JetpackScriptMain.cs`
- The flying, jump and boost sounds stay on the jetpack's two sources, which carry their own loop setup. They start through `SttdFxManager.PlayOnSource` and `PlayOneShotOnSource`, so mute and volume come from the `Jetpack` category.
**What it does:** Jetpack visuals and audio for one player: flame, steam puffs, boost particle, sounds and the parent constraint. Lives in `AO_JetpackScripts`.

**Decisions:**
- The two `Task.Delay` waits in the initialization are `MID_TickDelay.After` calls with stored handles: one second for late joiners before the loadout re-initialization, and 1.5 s before the visuals are built. `CancelPendingDelays` cancels them on despawn and on return to the pool, and the callbacks do nothing if the object is gone.
- A second `InitialzeJetpack` call for the same player while the first is waiting does nothing. Before, it started a second initialization.
- `InitialzeJetpack` keeps its name and signature, now returning `void` without `async`. `InitializeJetpackAsync` became the plain method `InitializeJetpackExtras`. The retry delay in its catch block is removed, because the retry call was already commented out.

### `JetpackExtraItems.cs`
**What it does:** Holds the jetpack effect objects (steam, flame, trails) and their lookup. Lives in `AO_JetpackScripts`. Only logging changed.

### `UnifiedProjectileManager.cs` and `GeneralGunHandler.cs` (pattern fire)
- Audio of the gun: the shot is one pooled sound through `SttdFxManager` (`GunShot`) with a random pitch. It plays locally on the owner and goes to the other machines with a `ClientRpc` of at most one per 0.1 s per weapon. The pooled prefab did not hold the package's `MID_SpawnableAudio`, so the old code left a pooled object behind on every shot and played nothing (see `audio.md`). The two sources of the gun stay for the reload sounds, which scrub and cross fade a clip, and their volume follows the `GunReload` category. The reload line plays on the dialogue source of the player (`Voice`). The bot check in front of it ran after the reference it guards, and now runs before.
**What it does:** Burst and shotgun weapons fire their whole pattern as one request. `UnifiedProjectileManager.FirePatternProjectiles` resolves the config and the firing system, picks a 16-bit fire seed with `ProjectileDirectionResolver.NewFireSeed`, expands the pattern with `ProjectileDirectionResolver`, and for server simulated projectiles makes a single `MID_MasterProjectileSystem.Fire` call. Only the pattern id, the spread, the aim direction and the fire seed travel over the network, and the server expands the same pattern. Raycast and physics projectiles still need one hit test or one object per pellet, so they are fired one by one from the same expanded list, and they ignore the pattern's burst timing.

**Decisions:**
- `GeneralGunHandler.TryFirePatternProjectiles` runs first in `FireBurstProjectiles` and `FireShotgunProjectiles`. A weapon without a pattern keeps the angle based burst and the random shotgun scatter.
- The pattern asset sets the projectile count. Ammo cost per trigger pull is `GeneralGunHandler.GetAmmoCostPerShot`, which reads `ProjectilePatternSO.GetFiredProjectileCount` when the weapon has a registered pattern and `NumberOfShots` otherwise. The reload time and shotgun reload audio math use the same cost, so a magazine holds the right number of pulls. `NumberOfShots` is not used while a pattern is set.
- `ValidateShotPattern` warns at weapon setup when the pattern is not listed in `ProjectilePatternRegistry` (id 0, the weapon falls back to the angle based shots) and when the pattern has burst timing but the weapon fires raycast or physics projectiles.
- The pattern expansion is a pure function of the pattern, the aim and the fire seed. Each shot gets a new seed, so a pattern shotgun scatters differently on every shot and every peer still rebuilds the same layout.
- Burst timing comes from the pattern asset (`Burst Interval`, `Burst Jitter`, `Burst Order`). The package holds the delayed projectiles and spawns each one when its time comes, see the package documentation for `DelayedSpawnQueue.cs`. A delayed projectile leaves from the muzzle position the shot had when it was fired. Muzzle flash, shell ejection and the fire sound play once per trigger pull. Double damage forces raycast mode, which ignores burst timing.
- The config lookup that `FireProjectileInternal` did inline is now `TryResolveConfig`, shared with the pattern path.
- `ResolvePatternDirections` in the gun handler is removed, because patterns no longer go through the per-direction path.
- Logging uses `MID_Logger`. The gun handler's `async` initialization chain is unchanged and listed under Open.

### `EquipableItemDataStructures.cs` (shot pattern tooltip)
- The tooltip of the shot pattern field describes the behavior: one request, the pattern sets the count, the layout and the burst timing, the ammo cost follows the pattern, and the pattern must be in the registry.

### `GrenadeHandler.cs`
**What it does:** Grenade holding, trajectory preview and throwing for players and bots. Lives in `AQ_WeaponScripts/Grenade`.

**Decisions:**
- All 11 `async` methods and 10 `Task.Delay` calls are coroutines with cached `WaitForSeconds` instances: spawn setup, initialization, the button click, the throw and the bot sequence.
- The click, throw and bot routines are stored and stopped by `ForceStopAllActivities`. `OnNetworkDespawn` stops every routine. Waits that were queued before a despawn no longer subscribe to HUD events afterwards.
- A second joystick release while a throw is running does nothing. Before, it started a second throw.
- The bot sequence resets the holding state and the weapon in a `finally` block, so an exception or a stopped routine does not leave a bot holding a grenade.
- `InitializeGrenadeAsync` is the plain method `InitializeGrenadeProperties`. Its retry path could not run, because the inner method already caught its own exceptions.
- `InitializeGrenade`, `ExecuteBotGrenadeSequence` and `SpawnAndThrowGrenadeForBots` keep their names and parameters and now return `void` without `async`.

### `ArmAnimationController.cs` and `ArmMove.cs`
- `SetArmAnimStateToTossingGrenade` is a coroutine (`IEnumerator`) now. `ArmMove.ThrowGrenade` starts it and `GrenadeHandler` waits for it. The 0.6 s wait uses a cached `WaitForSeconds`. The state change code moved into `TrySetTossAnimationState`, so the error handling stays outside the iterator. `OnDisable` clears the toss guard, because a disabled object stops its coroutines.
- `HandleArmAnimationStateChange` and `SafeWeaponOperation` were `async` without any real wait. They are plain methods.
- `ArmMove.QuickSwitchWeapon` is a coroutine with a cached 0.2 s wait.
- `ArmAnimationController` sends each arm state to `ArmPoseDriver.PlayPose` when the driver is on the same object. Without a driver it plays the old animator clips, and with neither it only records the state hash, so a prefab with no arm animation logs no errors.
- Logging in both files uses `MID_Logger`. In `ArmMove`, 14 `Debug.Log*` calls are converted and the `_enableDebugLogs` checks became level checks.

### Weapon initialization chain
**What it does:** A weapon that is parented to a player runs one setup coroutine in `WeaponPlayerRefrences`. It waits one second for the parent and the held flag to sync, gathers the player references, applies the parent constraint through `WeaponParentConstraintHandler`, then starts the initialization of the matching handler: `GeneralGunHandler.InitializeWeaponScript`, `MeleeWeaponHandler.InitializeMeleeWeapon` or `PowerWeaponHandler.InitializePowerWeapon`. Each of those is an `IEnumerator` that the setup coroutine waits for.

**Decisions:**
- The chain keeps its original waits as cached `WaitForSeconds` instances: 1 s and 0.1 s in the setup, 0.5 s in the constraint handler, 0.5 s, 0.1 s and 0.2 s in the gun handler, and 0.05 s in the melee and power handlers. The 10 ms wait in the gun handler is one frame.
- A `try` block cannot contain a `yield` in an iterator with a `catch`, so the guarded parts moved into `TryGatherPlayerRefs`, `TrySetupRotationAndConstraint`, `TryInitializeCore` and `TryFinishInitialization`. A failure logs the error and stops the chain at that step, as before.
- The gun handler's recovery after a failed initialization (wait 0.2 s, then `SetWeaponProperties`) is kept.
- `ReinitializeWithNewLoadout` is a plain method now. It does the stop, return and config swap steps at once, runs the full cleanup first when another player takes the weapon, and then starts a coroutine for the new initialization and the HUD refresh. The cleanup stops the handler's own coroutines, so it must not run inside the coroutine it would stop.
- `WeaponPlayerRefrences.ClearAllReferences` stops the setup coroutine. The "initialized for a different player" branch inside each handler runs the cleanup from inside that coroutine and therefore ends the setup. The branch is a safety net, because a pooled weapon is cleaned up on return and arrives uninitialized.
- `WeaponTypeManeger.InsertWeaponToNetCategorizer` only waits one second for power weapons, where it ends with a quick switch. Other weapon types did nothing after the old wait, so they return at once.
- `WeaponParentConstraintHandler.ApplyConstraintToPlayer` starts its 0.5 s wait as a coroutine, then constrains the weapon and registers it with the categorizer, whether or not the constraint step found a reason to stop. `ReleaseConstraint` stops a pending wait.
- Public methods that were `async void` (`GetAllComponentsAfterReParenting`, `ApplyConstraintToPlayer`, `InsertWeaponToNetCategorizer`, `ReinitializeWithNewLoadout`) keep their names and parameters and return `void`.

### `MeleeWeaponHandler.cs`
- The throw sound is a pooled one-shot (`MeleeThrow`). The handler no longer holds an audio source.
- The melee weapon is thrown only. Releasing the aim joystick calls `ThrowAttack`, which asks the server to spawn a `MeleeClone` with real physics. The held weapon no longer attacks on contact. The old contact attack ran `PerformRaycastAttack` every frame while the weapon was active (an `OverlapCircleAll` at the attack point) together with its damage fields, kill effect and critical hit roll, the contact point extra item and the gizmos. All of that is removed. Bots never use melee.
- `GetCloneSpawnPose` builds the clone's spawn pose. A flipped player mirrors the weapon with a half turn around Y, and the clone's physics body only follows the z part of a rotation, so a clone spawned with that rotation had its collider pointing somewhere other than its sprite. When the weapon's rotation is mirrored the pose is built from a z rotation and a negative x scale, which gives the same sprite and a collider that matches it. An unmirrored weapon keeps its rotation.
- The ally check on a hit asks `NetTeamRules.AreEnemies`, after the check that skips the wielder itself.
- `Update` was `async void` and awaited `StartVerticalMeleeHold` on every frame in which the aim joystick was pushed and no hold had started. The hold needs 0.2 s to start, so up to a dozen overlapping calls each sent the arm animation request. One guarded coroutine starts the hold now, and `OnDisable` and the pool cleanup clear the guard.
- The initialization and the helpers `InitializeDissolveSystem` and `InitializeExtraItemsFromPool` follow the chain notes above. The two helpers had no real waits and are plain methods.

### `PowerWeaponHandler.cs`
- The shot is a pooled one-shot through `SttdFxManager` (category `GunShot`). The charge and beam sounds stay on the weapon's source, which loops and fades, and their volume follows the `GunCharge` and `GunShot` categories.
- The two damage sites (the raycast hit and the laser) ask `NetTeamRules.AreEnemies`, so Free For All works and spectators are skipped. The bot fire loop in `NetBotPlayer` calls `BotShoot` and `StopBotShoot`. The bot tick on the weapon blueprint is `Tick_0_1`.
- `OnIsFiringPowerWeaponChanged` was `async void` and ran a loop that emitted a muzzle flash every 0.5 s while the weapon fired. Every change event with the flag set started another loop. One stored coroutine runs the loop now, it stops when firing stops, and both `StopAllCoroutines` sites reset it.
- The initialization and `SetEqItemConfigsAndMaterialProperties` follow the chain notes above.

### `GrenadeScriptMain.cs`
- The throw and explosion sounds are pooled one-shots through `SttdFxManager` (`GrenadeThrow`, `GrenadeExplosion`) at the grenade's position, so they outlive the grenade. The grenade no longer holds an audio source and no longer instantiates an audio object for its last sound.
- The proximity mine trigger asks `NetTeamRules.AreEnemies` for every collider in its radius. It never explodes on its owner, which matters in Free For All where every other entity is an enemy. The check runs on the 0.2 s dispatcher tick.
- The explosion is one overlap query into a reusable buffer, with a `ContactFilter2D` that includes triggers like the old call. Per candidate it takes the locator and the health handler from the entity, and measures the distance to the nearest point of the collider (`ClosestPoint`) instead of to its pivot, so a body that reaches into the radius takes damage by how close the body is. One hit per entity, also for an entity with two colliders on the player layers.
- Cover only blocks damage, it never scales it. A target is exposed when one of three rays from the grenade reaches it (body centre, feet, head) and the first clear ray decides, so a target in the open costs one ray. A collider that already contains the grenade centre does not count as cover, because queries start inside colliders and a grenade resting in the floor would shield every target from the floor.
- The proximity mine check uses the same buffer. The sat blocker check keeps `OverlapCircleAll`, because its query has no layer mask and a fixed buffer could fill with map colliders before it saw a grenade.
- Tests, not run in Unity: a grenade in the open does full falloff damage, one behind a wall does none, a target half behind a wall takes full damage when any of the three rays gets through, a grenade resting on the floor still damages a target next to it, and a target with two colliders is hit once.
- The grenade state handler was `async void`. The sparker's 5 s despawn wait and the 0.5 s explosion timer setup are coroutines now.

### `ConsolidatedProjectileDamageHandler.cs` and `MeleeClone.cs`
- The clone's hit sound is a pooled one-shot (`MeleeHit`) at the hit, so it outlives the clone. It plays on the server machine. The clone no longer holds an audio source.
- `ShouldDamageTarget` (projectiles) and `IsValidTarget` (thrown melee) ask `NetTeamRules.AreEnemies`. The rule lives in one place for the damage gate, every weapon and the bot target search, see `bots.md`, section `NetTeamRules.cs`. Thrown melee still skips its own wielder by id first.
- The clone ignores the colliders of its thrower (`IgnoreOwnerColliders`). The thrower never takes damage from its own clone, and a clone spawned next to the thrower's body used to collide with it and lose its throw.
- The spin is clockwise on screen for every throw. A mirrored clone (negative x scale) turns the other way round on the body, so the sign is reversed for it, which keeps the look the throw had before.
- The unused `_attackPoint` field is removed. The clone still uses its own `_whatToHit` mask for the boxing glove explosion.

## Audit

Counts come from a pattern scan, so commented code is included. The scan looked for `GetComponent`, `Find`, LINQ and string building inside `Update`, `FixedUpdate` and `LateUpdate`. None of the files in the table has one. The only hit is in `PysicsBasedProjectileSystem/ObjectNetSync.cs`.

| File | Lines | async | Task.Delay | Debug.Log |
|---|---|---|---|---|
| `AQ_WeaponScripts/Grenade/GrenadeHandler.cs` (converted) | 837 | 0 | 0 | 0 |
| `AN_GrenadeScripts/GrenadeScriptMain.cs` (converted) | 1344 | 0 | 0 | 0 |
| `AQ_WeaponScripts/Melee/MeleeWeaponHandler.cs` (converted) | 1120 | 0 | 0 | 0 |
| `AQ_WeaponScripts/Gun/GeneralGunHandler.cs` (converted) | 2045 | 0 | 0 | 0 |
| `AQ_WeaponScripts/PowerWeapon/PowerWeaponHandler.cs` (converted) | 1727 | 0 | 0 | 0 |
| `AQ_WeaponScripts/Shared/WeaponPlayerRefrences.cs` (converted) | 334 | 0 | 0 | 0 |
| `AQ_WeaponScripts/Shared/WeaponParentConstraintHandler.cs` (converted) | 274 | 0 | 0 | 0 |
| `AQ_WeaponScripts/Shared/WeaponTypeManeger.cs` (converted) | 259 | 0 | 0 | 0 |
| `AP_ProjectileScripts/Shared/ProjectileConfigManager.cs` | 348 | 0 | 0 | 13 |
| `AN_GrenadeScripts/GrenadeExtraItems.cs` | 241 | 0 | 0 | 6 |
| `AQ_WeaponScripts/PowerWeapon/PowerWeaponExtraItems.cs` | 762 | 0 | 0 | 6 |
| `AQ_WeaponScripts/Melee/MeleeWeaponExtraItems.cs` | 283 | 0 | 0 | 6 |
| `AQ_WeaponScripts/Shared/WeaponsExtraItems.cs` | 208 | 0 | 0 | 5 |

All the async calls in the table were non-network waits and are converted to coroutines or tick delays. No `async` and no `Task.Delay` remain in the grenade, jetpack, projectile and weapon script folders.

## Fixes and Problems

### Removed files
- `AQ_WeaponScripts/Melee/OldMeleeScript.cs` and `AQ_WeaponScripts/PowerWeapon/OldPowerweaponScript.cs`. Both files are entirely one block comment (3300 lines), define no live types and have no reference in any script, prefab or scene.

### `PlayerMovementController.cs`
- Glide lasted until landing and covered too much distance. Limited by `_maxGlideDuration`.

### `JetpackScriptMain.cs`
- One `async override void`, one `async void` and one `async Task` used real-time `Task.Delay` waits that kept running after the jetpack returned to the pool. They are cancellable tick delays now.

### `GrenadeHandler.cs`
- Ten real-time `Task.Delay` waits kept running after despawn and a second throw could start during the toss animation. Both are fixed, see the module notes.

### `UnifiedProjectileManager.cs`
- Burst and shotgun shots were sent as one fire request per projectile. A pattern now sends one request.
- A pattern shotgun fired the same layout on every shot. Each shot now carries a fire seed.

### `GeneralGunHandler.cs`
- A weapon with a pattern took its ammo cost from `NumberOfShots`, which could differ from the number of projectiles that flew. The cost, the reload time and the shotgun reload audio now follow the pattern's projectile count.
- Burst with a pattern did not release its projectiles over time. Burst and shotgun share one code path, so timing now comes from the pattern asset. A pattern that is missing from `ProjectilePatternRegistry` makes the weapon fall back to the angle based burst without a visible error. The setup warning covers that case. The fault was not reproduced in play, only traced in the code.

### Weapon initialization files
- `MeleeWeaponHandler.Update` could start many overlapping hold requests. One guarded coroutine starts the hold now.
- `PowerWeaponHandler` could start a second flame flash loop on every change of the firing flag. One stored coroutine runs it now.
- The initialization chain waited with real-time `Task.Delay` calls that kept running after a weapon returned to the pool. The waits are coroutines on the weapon object and stop with it.

### Melee
- The contact attack and everything that only served it are removed from `MeleeWeaponHandler`, see its module entry. The prefabs still carry serialized values for the removed fields, which Unity drops on the next save.
- Editor work left from the old design: the two nested prefab instances `MeleeAttackPath-Regular` and `MeleeAttackPathBomarang` inside `Stickman_Base.prefab` and `SuperiorPlayer.prefab`, and then the two prefabs and `MeleeAttackPoints.cs`. Nothing in code references them, but both player prefabs contain them, so they are deleted in the editor and not by script.
- The cause of the weak, downward throw while flipped was not confirmed by reading alone. The spawn pose and the self collision above are the two causes that fit it. Check a flipped throw first when Unity is available.
- `MeleeClone` has no transform sync component, so clients do not see it fly. It also receives its throw force and its sprite on the server only.
- The critical hit chance of a melee config is not applied to the clone's damage. The legendary kill effect of a melee config plays nowhere since the contact attack was removed.

### Team checks
- Every damage dealer compared the two teams on its own, and none had an exception for Free For All, where the lobby puts everyone on `_BlueTeam`. Nobody could be damaged in that mode. They ask `NetTeamRules` now.

### Open
- Grenades (`GrenadeHandler`, `GrenadeScriptMain`) and the melee weapons spawn their own objects and do not use `UnifiedProjectileManager`. Guns and the power weapon do. That stays so by decision.
- `GrenadeScriptMain.CheckForGrenadesInRange` (sat blocker) still allocates with `OverlapCircleAll` and has no layer mask. A mask that holds only the grenade layer would allow a buffer.
- Gun and power weapon shots still send one `ClientRpc` per shot (a gun at most one per 0.1 s), see `audio.md`.
- Weapon configs that should use a pattern need the pattern asset assigned. No weapon asset was changed.
- `WeaponStatCalculator` and `WeaponBalanceEditor` still read `NumberOfShots` for damage per shot, so their numbers are wrong for a weapon with a pattern whose count differs.
- Weapon configs have no switch for the burst timing of a weapon without a pattern. The `TimeBtwShots` and `TimeBtwBursts` fields are still not read at runtime.
- Async conversion left in the player scripts and the lobby: `PlayerHudManager`, `PlayerScoreSummonHandler`, `PlayerAnimationController`, `PlayerKillTypePopupHandler`, `PointsText`, `MultiplayerSpritePreloader`, `OfflineLobbyManager` and `OfflineGameRunner`.
- `ProjectilePatternRegistry` must list every pattern asset in each scene that fires it, in the same order on every peer. It is empty in `OfflineMultiplayerScene` and missing from the online scenes.
- Jetpack flame, steam and sounds still use their own particle and audio code, not `SttdFxManager`.
