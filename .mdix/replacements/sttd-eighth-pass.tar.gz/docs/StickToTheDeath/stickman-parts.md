# StickToTheDeath: Stickman Parts (PSD rig)

## Overview

The stickman is built from five loadout slots: Head, Hair, Body, Hands and Legs.
One Hands pick drives both hand sprites and one Legs pick drives both leg sprites,
so five slots drive the seven sprites of the PSD rig.

Three ideas make up the model:

- **Character**: a pack. Owning a character owns all five of its slots. A character
  always has art for every slot. Characters are listed in `Resources/StickmanCatalog.json`.
- **Slot selection**: what the loadout stores. Each slot holds a character id and an
  optional camo id, so any mix of characters is possible (Dave's head on Bushmaster's body).
  There is no stored "selected character". If all five slots come from one character the
  UI shows that name, otherwise it shows "Custom".
- **Camo**: owned by one character and valid only on that character's slots. A camo can
  cover all five slots or a subset. Slots it does not cover keep the base look.

Each slot is one loadout item with type index 10 (`EqLoadoutItemCategory.StickmanPart`)
and category string `StickmanPart_1` to `StickmanPart_5`. The existing Skin (9) and Hand
(8) categories are left in loadouts so the ragdoll, preview and online code keep working
until they move to the new model.

Sprite Library labels follow the PSD layer names. The base look of a rig part is
`{Prefix}_{CharacterLabel}` (for example `Head_Dave`, `Left_Hand_Dave`) and a camo adds
`_{CamoLabel}` (for example `Head_Bushmaster_Ivory`). `Head_Base` and the other `_Base`
layers of `Stickman_Base.psd` are the base character.

Ownership uses string keys in the existing unlocked-items set: `CHAR:{ID}` for a pack and
`CAMO:{CHARACTER}:{CAMO}` for a camo. Parts have no keys of their own.

### Catalog file

`Assets/Resources/StickmanCatalog.json`:

```json
{
  "DatabaseVersion": "1.0.0",
  "Characters": [
    {
      "NumericId": 7,
      "Id": "BUSHMASTER",
      "DisplayName": "Bushmaster",
      "LabelName": "Bushmaster",
      "IconItemId": "STICKMAN_BUSHMASTER",
      "Rarity": "Epic",
      "UnlockedByDefault": false,
      "OfflineAvailable": false,
      "Camos": [
        { "NumericId": 1, "Id": "IVORY", "DisplayName": "Ivory", "LabelName": "Ivory",
          "Rarity": "Rare", "Slots": ["Head", "Hands"] }
      ],
      "Extras": []
    }
  ]
}
```

- `NumericId` is sent over the network instead of the string id. Never reuse or change one
  once it has shipped. Camo numeric ids only need to be unique inside their character.
- The catalog holds all 31 characters of the Remote Config `ALL_EQUIPABLE_LOADOUT_ITEMS_CONFIG`, so
  numeric ids are the same everywhere: 1 basic, 8 rare, 14 epic, 6 legendary and 2 runic.
  Legendary and runic items are separate inventory items with their own packs, prices, attainment
  configs and atlases, so they are separate characters, not camos. A character id is the item id
  without `STICKMAN_`, for example `DAVE`, `1C_LUCIUS_D_KING` and `1B_LUCIUS_D_KING_KINGARMOR`.
- `OfflineAvailable` controls whether the offline lobby lists the character or camo. Offline currently
  offers the six characters the offline manager already offered (Base, Black, Dave, Emeka, Bobzy and
  Tyson) and no camos. Set a flag to true to offer more.
- Camos come from the camo config of the economy item. The first camo of each item is the character's
  base look and is not listed, since for some items its id is not the item id (`HANNAHGIPSON_WHITEGOLD`,
  `LUCIUS_D_KING_WHITEGOLD`, `MAN_MAN`). The camo id is the economy id without the item prefix, so
  `STICKMAN_BUSHMASTER_CHERRYBLOSOM` becomes `CHERRYBLOSOM` (the economy spelling is kept). Camos exist
  today only for Base (8 colors) and BushMaster (5 flowers).
- `IconItemId` is the item id of the character's skin in `OfflineItemMetadataDatabase.json`. It
  supplies the lobby icon and the lore text. Black's real id is `BLACKSTICKMAN`.
- `LabelName` is the in-game name with punctuation removed (`BushMaster`, `LuciusDKing`), which gives
  PSD layer names like `Head_BushMaster`.
- `Slots` on a camo lists slot names (`Head`, `Hair`, `Body`, `Hands`, `Legs`). Empty means
  all five.
- Adding a character or camo needs only this file and the matching Sprite Library labels.
  The generated `NetworkIdConverter` tables are not involved.

### Unity setup for the PSD rig

1. In the PSD Importer, turn on layer grouping so each part's variants sit in a layer group
   named like its category (`Head`, `Hair`, `Body`, `Left_Hand`, `Right_Hand`, `Left_Leg`,
   `Right_Leg`), with one layer per label.
2. Create the Sprite Library Asset from the PSD and put a `SpriteLibrary` on the rig root.
3. Add a `SpriteResolver` to each part's GameObject.
4. Add `PsdStickmanSkinApplier` to the player and run its "Auto Bind From Children" menu.
5. Assign it to `m_PsdSkinApplier` on `PlayerInitializer` and disable the old PNG renderers.
6. Optional, for the lobby: tick `_usePsdStickman` on the offline customization manager.

## Modules

### `StickmanPsdPart.cs`
**What it does:** Defines `StickmanPsdPart` (the seven rig sprites), `StickmanSlot` (the five
loadout slots) and the helpers that map between them, to loadout slot indexes (1 to 5) and to
category strings.

**Decisions:**
- `StickmanPsdPart` keeps the values it had when it was first added, because the applier
  serializes them in prefabs.
- Slot index is the enum value plus one so 0 still means "no slot", as for every other category.

### `StickmanCatalogData.cs`
**What it does:** Plain data classes for the catalog JSON: characters, camos and extras.
`CoversSlot` answers whether a camo has art for a slot. `GetIconItemId` gives the item whose
metadata entry supplies the lobby icon (default `STICKMAN_{Id}`).

**Decisions:**
- Extras are stored per slot in the data but nothing spawns them yet.

### `StickmanCatalog.cs`
**What it does:** Loads the catalog from Resources once, validates it and answers lookups by
string id (case-insensitive) or numeric id. Builds Sprite Library labels. Entries with an empty
or duplicate id, or a zero or duplicate numeric id, are skipped and logged as errors.

**Decisions:**
- The catalog is the config for stickman parts, so these items skip the config library lookup.
- A camo resolves only through its own character, so a camo can never apply to another character.

### `StickmanLook.cs`
**What it does:** `StickmanPartSelection` (character plus optional camo) and `StickmanLook` (five
selections). `TryGetUniformCharacter` derives the "selected character" instead of storing it.

### `StickmanOwnership.cs`
**What it does:** Builds and checks unlock keys. A character is owned if it is free or has a
`CHAR:` key. A camo is owned only when its character is owned and the camo is free or has a
`CAMO:` key.

### `StickmanLoadoutBridge.cs`
**What it does:** Converts between selections and `NetworkLoadoutItem` / `CompactNetworkLoadoutItem`,
reads and writes a loadout's item list, and `EnsureParts` adds default slots to loadouts saved
before this existed or whose character was removed from the catalog.

**Decisions:**
- On the wire a part carries the catalog's numeric character id in `ItemId` and the numeric camo id
  in `ItemSelectedCamoId`. Config ids are 0.
- An unknown numeric id decodes to an empty `ItemId`, which validation rejects and readers
  replace with the default character.

### `OfflineStickmanWardrobe.cs`
**What it does:** UI-free offline logic: equip a whole character, equip one slot, change a camo,
unlock a character or camo, and list the camos a slot can offer. Refuses locked characters, locked
camos, camos of another character and camos that do not cover the slot. Saves through callbacks
and raises `OnLookChanged` and `OnOwnershipChanged`.

**Decisions:**
- The look is stored per loadout, as the old skin and hand items were.
- Equipping a full character resets camos to the base look.

### `PsdStickmanSkinApplier.cs`
**What it does:** Holds one binding per rig part (category, fallback label, `SpriteResolver`) and
applies a `StickmanLook`. Falls back to the part's `_Base` label when a label is missing and logs
a warning. Exposes the part renderers for dissolve and material transitions.

**Decisions:**
- No networking. Loadouts are already replicated and every client applies them.

### `CompactNetworkLoadoutItem.cs`
**What it does:** Type index 10 is routed to `StickmanLoadoutBridge` in `FromFull` and `ToFull`.
The category string for index 10 carries the slot suffix like Summon does.

### `EqLoadoutItemCategory.cs`
**What it does:** Adds `StickmanPart = 10`.

### `OfflineServerLoadoutManager.cs`
**What it does:** Accepts the `stickmanpart` category with slots 1 to 5 and validates part items
against the catalog (character exists, camo exists on that character). Ownership is not checked
offline, as for every other item.

### `OfflineLobbyCustomizationManager.cs`
**What it does:** Always upgrades saved loadouts with default part items and creates the wardrobe.
With `_usePsdStickman` on, the Skin button becomes a Stickman button, the Hands button is hidden,
and the Stickman category is built from the catalog with six tabs: Full Set, Head, Hair, Body,
Hands, Legs. Each tab is a grid of cards (a character, then its camos). Unlocking, equipping,
selected state and the category icon all go through the wardrobe.

**Decisions:**
- The existing sub-category row is reused as the slot tabs, so no new prefabs are needed.
- A camo card for an unowned character says "Unlock {name} first!" instead of unlocking.
- Cards have no metadata entry of their own, so icons come from the character's `IconItemId`.

### `OfflineItemButton.cs`
**What it does:** When an item has no metadata entry, looks up the icon through `IconItemId`.

### `OfflineCategoryButton.cs`
**What it does:** Labels the `StickmanPart` category "Stickman".

### `PlayerHudManager.cs`
**What it does:** Skips stickman part categories when building HUD loadout slots.

### `PlayerInitializer.cs`
**What it does:** With a PSD applier assigned, `SetPlayerSkin` builds a look from the five
`StickmanPart_N` items (missing slots use the default character) and applies it. `SetPlayerHandSkin`
becomes a no-op because hands are part of the look. Material transitions and the dissolve manager
use every rig renderer. Logging goes through `MID_Logger`; the old `_enableLogs` toggle still
raises the level to Debug.

**Decisions:**
- The legacy skin item still supplies dissolve color, teleport effect and extra materials, so
  nothing changes there until a slot is chosen as the authority.
- With no applier assigned the old PNG path runs unchanged.
- The spawn chain (skin, hand skin, extra items, dissolve manager, then the spawn dissolve and effect) is one coroutine with the original timing of 0.1 s, 0.1 s and 0.5 s, on scaled time. A second config call restarts the chain, so only the newest config is applied. The chain stops on despawn and in `CleanupForMatchEnd`. If it is asked to start while the object is inactive, or a disable cuts it short, it starts (over) on the next `OnEnable`.
- Extra items taken from the pool are returned before a second init takes new ones.

### `PlayerDamageFlash.cs`
**What it does:** Flashes every renderer of the PSD rig when a `PsdStickmanSkinApplier` is found under
the player, and the old body and two arm renderers otherwise. Each renderer gets its own property block.
Logging goes through `MID_Logger`, and the old `_enableLogs` toggle still raises the level to Debug.

**Decisions:**
- The flash stays a per-frame coroutine that follows `_flashCurve`. A tick at the `Tick_0_1` minimum would give two or three steps over 0.25 s and lose the curve.
- The color and duration of a `TriggerDamageFlash` call apply for the whole flash.
- The renderer set follows `get_BodyRenderers` at trigger time, so it tracks the move from the old renderers to the PSD parts.
- The flash reads and writes each renderer's property block every frame, because `DissolveEffectManager` owns the same blocks.
- `OnDisable` stops a running flash and clears the tint.

### `StickmanRigRagdoll.cs`
**What it does:** Death-only limp ragdoll on the PSD rig. `Activate(impulse)` stops the animators and the
IK manager, gives every bone a dynamic `Rigidbody2D`, a horizontal capsule and a `HingeJoint2D` to its
parent bone, passes on the player's velocity and shares the impulse across the bones by mass.
`Deactivate()` removes the joints, switches the bodies off, restores the bind pose and re-enables what it
disabled. It does nothing when not active, so it is safe to call on every respawn.

**Decisions:**
- Bones are found by name (`_Bone_` by default), so the 20 PSD bones are picked up without a list. Hair
  bones get a light body and no collider, so they flop without blocking anything.
- Physics values mirror the old `PlayerRagDoll` prefab: mass 1, gravity 1, hinge limits of 50 degrees,
  automatic anchors, no collision between connected bones.
- Bodies and capsules are built once on the first death. Joints are rebuilt on every death, so their
  limits are centered on the pose at death. Limits are symmetric, which avoids sign problems when the
  player faces left.
- A death plays out as ragdoll, then dissolve, then respawn. The body lies there for `_dissolveAfterSeconds`
  (3 s), then `PlayerInitializer.DissolveOut` dissolves it away and the renderers are hidden when the
  dissolve is done. At the default change rate of 0.1 the dissolve takes about 2 s, so the body is gone at
  about 5 s and the respawn delay is 6 s. `_lingerSeconds` only applies when no dissolve is available (the
  manager is not ready, or `_dissolveAfterSeconds` is 0). The respawn enables the renderers again.
- The component is local. The existing death RPCs call it on every client.

### `NetDamageHandler.cs`
**What it does:** Adds `StartRigRagdollClientRpc`, which starts the ragdoll on every client.
`DisablePlayerComponentsClientRpc` keeps the renderers on when the rig ragdoll is active, and
`EnablePlayerComponentsClientRpc` ends the ragdoll before the rig is shown again, and calls
`ZeroOutAndUnDissolve` for a player whose ragdoll was active, so the dissolved body materializes at the
spawn point like a first spawn.

### `NetworkServerManeger.cs`
**What it does:** `SpawnRagDoll` sends `StartRigRagdollClientRpc` and returns, instead of spawning the
separate networked ragdoll, when the victim has a `StickmanRigRagdoll`. Players and bots without one
keep the old behavior.

### `PlayerAnimationController.cs` and `BotAnimationController.cs`
**What they do:** The animator state names are now serialized fields, with the names from
`SuperiorPlayer.controller` as defaults. The context menu "Use Stickman_Base state names" fills in the
names from `Stickman_Base.controller`. A state that does not exist is logged once and skipped, because
`Animator.Play` on a missing state does nothing.

**Decisions:**
- `Stickman_Base.controller` has no slide state, so its slide name is blank and sliding plays no clip.

### `NetcodeWeaponCatigorizer.cs`
**What it does:** `SetWeaponConfigs` skips stickman part items, so they do not send weapon spawn RPCs. The component also selects the weapon of a player or bot, runs the melee and power weapon timers and keeps the weapon actions of the HUD.

**Decisions:**

- A weapon swap plays `_weaponSwapSound` (`AudioId.WeaponSwap2` by default, `WeaponSwitch1` is the other clip in the repo) as a pooled one-shot of category `GunOther` through `SttdFxManager`. It plays on the machine of the human who swaps, from `OnWeaponChanged`. A change to or from "no weapon" is the quick switch after a respawn or a loadout reload and stays silent. Bots and other players' swaps are silent, because the sounds are 2D and have no distance falloff. `_weaponSwapVolume` scales it. Like every catalog sound it needs a `MID_AudioManager` with the catalogs in the scene, see `audio.md`.
- A bot is told from a human by the bot controller on its prefab, set in `Awake`. The bot flags are only set by the server after the spawn, so the old check treated every bot as a real player while it spawned. The death handler (weapons off, ammo reset) stays subscribed for every owner, humans and bots, because nothing else resets the ammo of a bot. The HUD parts are for real players.
- The camera and weapon actions of the HUD are subscribed once per spawn through two helpers. The loadout is applied more than once and added the handlers again each time.
- `OnNetworkSpawn` and `OnPlayerHealthChanged` are no longer `async`, they only waited for nothing. The quick switch is a coroutine with a cached 0.15 s wait (it sends at once when the component is inactive), and the one second timers use a cached `WaitForSeconds`.
- Logging uses `MID_Logger` with `_logLevel`, default Error, and interpolated debug strings are guarded.

**Not changed:** `SetWeaponConfigs` is still `async Task`, because `PlayerLoadoutHandlerAndLateJoiningSupport` awaits it in two places and its one second wait is for the pooled weapons. Each swap still looks up the weapon components with `GetComponent` and `TryGetComponent` (a few per swap, not per frame). Caching them per slot is possible when the weapon list is filled.

**Tests:** Not run in Unity. Swap between the primary and secondary weapon: one short sound each time, none after a respawn, none for a bot.

### `PlayerLoadoutHandlerAndLateJoiningSupport.cs`
**What it does:** `GetLoadoutVisualDataAsync` skips stickman part items, which have no config and no HUD
icon, and `GetBaseCategoryName` knows type 10.

### `BaseBotLoadoutGenerator.cs`
**What it does:** Builds the two random loadout classes of a bot (offline and online generators share it). Each class now also holds the five `StickmanPart_N` items of the PSD rig, so a bot prefab that has the PSD applier shows its character.

**Decisions:**
- The character of the parts is the character of the skin the bot rolled (`StickmanDave` is `DAVE`, matched ignoring underscores, so `StickmanLuciusDKing` is `LUCIUS_D_KING`). The old skin item and the parts agree, and the offline pool stays the six offline-available characters. An unknown skin gets the default character of the catalog.
- All five slots hold the same character, the hands included. The old hand item is still rolled on its own and is only used by the old PNG path.
- The parts go through the existing conversion to the compact form, so nothing else changed on the wire.
- The catalog is initialized on first use. A bot prefab without the PSD applier ignores the parts and keeps the old skin, so this changes nothing visible until the bot prefab has the rig.

**Tests:** Not run in Unity. Spawn an offline bot and look at its loadout in the log: five `StickmanPart_N` items with the character of its skin.

## CI and Workflows

None. Files are delivered through `.mdix/replacements` and applied by `apply-replacements.yml`.

## Fixes and Problems

### `PlayerInitializer.cs`
- `ReInitializePlayerArmAndSkin` passed the skin item to `SetMyPlayerHandConfig` where the hand
  item belongs. Fixed.
- The spawn chain was `async void` with `Task.Delay`. The delays ran in real time and kept running after a despawn, a second config call started a second chain that took a second set of extra items from the pool, and a null config would have retried every 100 ms with no end. It is one coroutine now, see Decisions.
- Open: `SwitchToMaterial` and `TransitionToNewMatSmoothly` have no callers outside this file and read `Renderer.material`, which creates a material instance per renderer.
- Open: `Awake` calls `Shader.Find` when `_defaultMaterial` is empty.

### `PlayerDamageFlash.cs`
- The color and duration overloads of `TriggerDamageFlash` restored the old value right after starting the coroutine, so a custom value lasted one frame. Fixed.
- Disabling the player during a flash left the flash amount on the property blocks, so the tint stayed on respawn. `OnDisable` clears it.
- The renderer set was read once in `Start`, so it stayed on the old renderers if the PSD parts became available later. It follows `get_BodyRenderers` now.
- The missing material warning repeated on every hit. It is logged once.
- Open: `EnableDissolveMode` and `DisableDissolveMode` end in `PlayerInitializer.DisableDamageFlashMode` and `EnableDamageFlashMode`, whose calls into the dissolve manager are commented out, so both do nothing.
- Open: a player whose config has no dissolve material never flashes. The warning only shows at log level `Info`.

### `StickmanRigRagdoll.cs`
- The death had no dissolve. Nothing called `PlayerInitializer.OnPlayerDeath`, and `StartDissolve` is a pulse (dissolve, then un-dissolve) and not a fade-out. The ragdoll now calls the one-way `DissolveOut`, and the respawn calls `ZeroOutAndUnDissolve`.
- Open: `PlayerInitializer.OnPlayerDeath` and `OnPlayerRespawn` still have no callers. `OnPlayerDeath` calls `StartDissolve`, which would dissolve the body and bring it back, so use `DissolveOut` if it is ever wired.
- Open: weapons have their own `DissolveEffectManager`. This does not drive them, so a held weapon is hidden with the other renderers instead of dissolving.
- Open: bots use the old networked ragdoll prefab, so this sequence does not apply to them yet.

### `OfflineItemMetadataDatabase.json` (not edited)
- The file is regenerated from the economy data (version 2.0, extracted 2025-12-29), so a hand edit
  would be lost on the next extraction. It is read only by the offline lobby UI for icons, rotation
  data and descriptions, and nothing else in the game reads it.
- It lists 23 `StickmanSkin` and 23 `StickmanHand` items. The stickman part cards need no entries:
  they take their icon and lore from the character's skin item through `IconItemId`. The hand
  entries are no longer used by the PSD lobby.
- To give a card its own icon later, the entry must carry the card id (`PART:{Slot}:{CHARACTER}`,
  `PART:{Slot}:{CHARACTER}:{CAMO}` or `SET:{CHARACTER}`) with `ItemAtlasId` and `ItemAtlasSpriteName`,
  and has to come from the extraction source or be re-added after each extraction.

### `StickmanCatalog.json`
- The first catalog listed six characters with `IconItemId` set to `STICKMAN_BLACK` for Black, which
  does not exist. Black's metadata id is `BLACKSTICKMAN`. Fixed, and the catalog was rebuilt from
  the metadata with all 23 characters. Numeric ids 1 to 6 are unchanged.

### Data notes from the economy and Remote Config
- Skin and hand items have separate camo lists with separate ids (`STICKMAN_BLUE` and
  `STICKMAN_HAND_BLUE`). A camo now belongs to the character and covers all five slots, so a player's
  skin and hand camos have to be merged into one list per character when the online path moves over.
- The hand attainment configs were copied from the skin ones: `ALL_STICKMAN_HAND_EQ_AND_CAMO_ATTAINMENT_CONFIGS`
  has the id and camo config of the skin ones, `ALL_LEGENDARY_STICKMAN_HAND_EQ_AND_CAMO_ATTAINMENT_CONFIGS`
  has the id of the runic skin one and lists `1C_STICKMAN_HAND_JASMINEBADEM` twice, and
  `ALL_RUNIC_STICKMAN_HAND_EQ_AND_CAMO_ATTAINMENT_CONFIGS` lists `1B_STICKMAN_HAND_JINESMERALDA_GOLDHALO`,
  which is not an item. Merging hands into characters removes the need for these configs.
- Every camo has `CamoRarity` set to `Basic`, and almost every skin camo uses `Ashy_Icon(Clone)` as its
  icon, so camo icons need real entries before a camo grid can be shown.
- The legendary and runic characters are not in `OfflineItemMetadataDatabase.json`, so they have no lobby
  icon yet. They are not offered offline, so nothing is missing today.
- Runic characters have an atlas each and the other tiers share one atlas per tier, which fits one
  Sprite Library per character.

### Known gaps
- The ragdoll layer is not set. Bone colliders keep each bone's own layer. Set `_ragdollLayer` if the
  bones should only collide with the ground. The layer settings were not readable because
  `ProjectSettings/*.asset` is stored in Git LFS.
- Left-facing deaths are untested. If they misbehave, turn on `_unflipRootOnActivate`.
- `RagDollHandler` is still used for any player or bot without a `StickmanRigRagdoll`.
- `OfflineCharacterPreview` and the online loadout path of players still use the old Skin and Hand items.
  Online players show the default character in PSD mode. Bot loadouts carry the part items now, but
  `BotPlayer.prefab` is still the old rig without the applier, see the bot prefab section of the rig migration.
- Extras are in the catalog data but are not spawned yet.
- `PlayerLoadoutHandlerAndLateJoiningSupport.cs` was not available for review. The new code calls
  its `TryGetLoadoutItem` the same way the existing skin code does.
- Per-slot camo materials (moving camos) are not supported yet. `DissolveEffectManager` still takes
  one camo material for all renderers.
