# StickToTheDeath: offline lobby

## Modules

### `OfflineLobbyManager.cs`
**What it does:** LAN lobby for the offline mode: discovery over UDP, hosting, joining, ready states, bots and team assignment, and starting the match. Lives in `AH_LobbyScripts/Offline/Core`.

**Decisions:**
- The custom match intro screen is gone. `StartGame` sends one `StartGameTransitionClientRpc` and every peer shows the scene transition of `MID_TheSceneManager`. The host calls `LoadScene` with the transition, and clients call the new `ShowTransitionForRemoteLoad` and wait for the host's load.
- `PrepareIntroData`, the intro RPC and `_pendingGameplayScene` are removed.
- `StartHostingLobby` and `JoinLobby` keep their signatures and return `void`. Their waits are coroutines: 0.1 s after the host starts, a 0.1 s poll for up to 10 s while a client connects, and 0.2 s and 0.5 s inside the network cleanup. Failure handling moved into `FailHosting` and `FailJoin`, so no `yield` sits inside a `try` with a `catch`.
- The UDP discovery and broadcast loops stay `async`, because they wait on socket input and output.
- All 104 `MID_HelperFunctions.DebugOnlyInEditor` and `LogDebug` calls use `MID_Logger` with a serialized `_logLevel`.
- Parity with the package `LocalLobbyManager` (`MidManStudio.Netcode.LocalMultiplayer`) was checked. The game keeps its own manager. The package manager is the generic version of the same design: it has no game modes, maps, game-specific bots, scene start or popups, and its member names differ from the game's almost everywhere. A subclass would need about ten new virtual hooks in the package and a game class of roughly the same size as today. Swapping the component would also reset the serialized fields on the lobby prefab. The package fixes were ported into the game file instead.
- Shutdown: stopping play mode or quitting makes `NetworkManager` shut itself down while messages are still handled, which throws inside Netcode. `ShutdownNetworkImmediate` shuts down first, in the same frame, from the editor play mode exit hook and from `OnApplicationQuit`. Every `Shutdown` call passes `discardMessageQueue: true`. `OnDestroy` shuts down synchronously when the object is inactive, because `StartCoroutine` throws there.
- Discovery receive loops wait 250 ms after a failure and stop after 5 failures in a row. The send loops wait one discovery interval after a failure.
- A client sends its name once the manager has spawned, with a 5 s limit, instead of after a fixed 0.2 s.

### `MobileNetworkStatusMonitor.cs`
**What it does:** Reports the network state of the device (`WIFI_CONNECTED`, `HOTSPOT`, `MOBILE_DATA`, `NO_NETWORK`) and whether it can host or join. Lives in `AH_LobbyScripts/Offline/Core`.

**Decisions:**
- On Android the status comes from `WifiManager.isWifiApEnabled` for the hotspot and from `ConnectivityManager` network capabilities for WiFi and mobile data. This is the logic of the package `MobileNetworkStatusMonitor`. If a native call fails, and always on iOS, the interface address check runs. It now reads every active non-loopback interface, not only WiFi ones, and also knows the Windows hotspot subnet `192.168.137.x`.
- The public methods and the forward to `OfflineLobbyManager.OnNetworkStatusChanged` are unchanged, so `MobileNetworkUIHandler` needs no change. `CheckHostingRequirements` and `CheckJoiningRequirements` stay in the game class only.
- The serialized `enableDebugLogging` flag is replaced by `_logLevel`, default Error. The old field value in the scene is dropped. `checkInterval` keeps its name.
- Not tested on a device. The Android calls are the ones the package uses.

### `OfflineMapModeHandler.cs`, `MapCard.cs` and `GameModeCard.cs`
**What it does:** The popup that opens from the single map and mode button in the create area. It has a mode tab and a map tab, each with a list of cards. `MapCard.cs` holds `OfflineMapCard` and `GameModeCard.cs` holds `OfflineGameModeCard`. Lives in `AH_LobbyScripts/Offline/Ui`.

**Decisions:**
- Picking a card no longer closes the popup, so a mode and a map can be picked one after the other. The close button closes it.
- The handler holds the current mode and map. `SetSelection` sets them without raising the selected events, and `OfflineLobbyUIManager` calls it when the popup is connected.
- The header shows the current choice (`Select Game Mode: Team Death Match`, `Select Map: Grassy Land`). The selected card is lightened, and an optional `selectedMarker` object on the card is shown while it is selected. The marker has to be assigned in the card prefab. Without it only the lightening shows.
- The selected events and the lobby UI texts behind the popup update on every pick.

### `OfflineLobbyUIManager.cs`
- `detailedLogging` and the `Debug.Log` helpers are replaced by `MID_Logger` with a serialized `_logLevel`, default Error.
- `SetupUnifiedPopupSystem` pushes the initial mode and map into the popup handler.

### `OfflineGameRunner.cs`
**What it does:** Runs the offline match on the server: teams, spawning, timer and match end. Lives in `AH_LobbyScripts/Offline/Core`.

**Decisions:**
- The runner no longer shows an intro. On spawn every peer switches the lobby components off, and the host registers with the setup coordinator at once.
- `HandleMatchEnd` starts one coroutine, `MatchEndSequence`: disable the HUD, show the outro and wait for it (15 s limit), unload the gameplay scene, fade back to the lobby. The fade is still a `Task` owned by `IntroOutroManager`, so `WaitForTask` waits for it.
- The outro screen stays. It shows the match results and is not a loading screen.

### `MID_TheSceneManager.cs`
- New `ShowTransitionForRemoteLoad(scene)` for clients. It runs the same transition without starting a load, ends when the network scene load completes, and fails the transition after 30 s.
- The two log bools are one `MID_LogLevel`.

### `OfflineIntroOutroProvider.cs`
- `PrepareIntroData` is removed. `PrepareOutroData` stays.

## Fixes and Problems

### `OfflineGameRunner.cs`
- `ForceEndMatch` set `_matchEnded` before calling `HandleMatchEnd`, which returns at once when the flag is set, so a forced end never ran the end sequence. `HandleMatchEnd` sets the flag itself now.
- The final fade was waited for with `yield return` on a `Task`, which does not wait. The active path waits for it correctly now.
- Removed code that nothing called: `EndGameSequence`, `OnOutroCompleted`, `CleanupAndReturnToLobby`, `DespawnAllEntities`, `UnloadAllPools` and the private `ShowMatchOutro`. The match end does not despawn entities or unload pools. `onGameEnd` was only raised from that removed code and is still never raised.

### `OfflineLobbyManager.cs`
- Clients showed a black cover and waited for the host's load with a 30 s timeout inside `IntroOutroManager`. The scene transition does the same now.
- Closing the game or stopping play mode could throw a null reference inside Netcode while the message queue was handled. Fixed by the synchronous shutdown described above.
- A discovery socket that kept failing looped without a pause and flooded the log. The receive and send loops now wait after a failure, and the receive loops give up after 5 in a row.
- A client could call the name ServerRpc before the manager had spawned. It waits for the spawn now.

### `OfflineMapModeHandler.cs`
- The popup closed on every selection, so changing both mode and map meant opening it twice. It stays open now.

### Open
- The package `LocalLobbyManager` has the same missing pause after a failed broadcast send as the game manager had. It was not changed in this update.
- The mode list in `OfflineMapModeHandler` still has placeholder names and descriptions (for example the display name of the ignite mode and the descriptions of Hardpoint and Objectives).
- The `supportedModes` text on the map cards is only shown in the info popup. Picking a map does not check it against the selected mode.
- `IntroOutroManager` is shared with the online match flow and still has about 23 `async` methods. Only its outro and fade are used by the offline mode.
- The online runner and lobby still use the old intro screen.
- `GameManager.JoinLobby` is the online lobby service call, not the offline one.

### Review: Skin and Hand to stickman parts (nothing changed yet)
State of the offline customization, read at `a901424`. The menu already has a parts mode (`_usePsdStickman` on `OfflineLobbyCustomizationManager`, default off, plus `OfflineStickmanWardrobe`, the catalog and the server validation), so the work is a cutover and not a new feature. What blocks it:

- **Saved choices are lost.** `StickmanLoadoutBridge.EnsureParts` fills missing slots with the default character and never reads the old Skin item, so a loadout with Dave equipped becomes the base character on the first parts load.
- **Saved unlocks are lost.** The old menu saves item ids (`STICKMAN_DAVE`, `STICKMAN_HAND_DAVE`) in `OfflinePlayerUnlockedItems`. The wardrobe checks `CHAR:DAVE` keys, so every unlocked character shows as locked again. Only Base is unlocked by default in both systems.
- **The Skin item cannot be dropped.** `PlayerInitializer.SetPlayerSkin` still takes the skin config (moving camo material, dissolve material, teleport effect) from the Skin item, which reaches the player through `NetEqItemSpawner.RecivePlayerConfigsRetrival...`. Without a Skin item that config never arrives. The Hand item is not needed by the rig (`SetPlayerHandSkin` is a no-op with the applier), but its config path still runs. The wardrobe writes only part items, so in parts mode the Skin item keeps whatever it held. The offline server validation also checks the Skin and Hand items against the old config libraries.
- **The preview shows nothing in parts mode.** `OfflineCharacterPreview.PreviewItem` has cases for Skin, Hand, jetpack and weapons and none for `StickmanPart`. A real preview needs the rig (a prefab with the applier), which is editor work.
- **Two category lists exist.** `InitializeAvailableItems` still builds the hard-coded Skin and Hand lists (six characters). Their metadata and icon atlases are still needed, because the part cards take their icon from the character's `IconItemId`, which is the Skin item id.
- **Bots** now get part items in their loadout (`BaseBotLoadoutGenerator`), derived from the skin they roll, so a bot keeps its Skin item for the same reason.

Proposed order: migrate saved loadouts and unlock keys on load, keep the Skin and Hand items in sync with the look (Skin from the Body slot, Hand from the Hands slot, using the old item tables as a hidden config table), give the preview a parts case, then turn the mode on by default and remove the old lists and the switch after the player prefab was checked in Unity.
