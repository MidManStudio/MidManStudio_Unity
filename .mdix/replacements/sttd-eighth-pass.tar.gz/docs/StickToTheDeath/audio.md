# StickToTheDeath: audio

## Overview
Every clip in `Assets/AQ_AudioFiles` has an entry in the audio id provider and a row in one of six audio catalogs. The id
provider becomes the generated `AudioId` enum, the category provider becomes `AudioCategory`, and each catalog maps an id
and category to its clip. The playback side is the `MID_AudioManager` of the `com.midmanstudio.audio` package. See that
package's `README.md` for the API.

Gameplay scripts do not talk to the pool or to audio sources directly. They play every sound through `SttdFxManager`, see
"Gameplay playback" below.

155 clips are tracked. Ids run from 1000 to 1154 inside the block 1000 to 1999. Game categories run from 100 to 112 inside the
block 100 to 199. The package keeps 0 to 999 for ids and 0 to 99 for categories.

## Modules

### Providers
**What it does:** `AudioIdProvider_Sttd.asset` lists one entry per clip. `AudioCategoryProvider_Sttd.asset` lists the 13 game
categories. Both use the package id `com.midmanstudio.sttd` and priority 100. They live in
`Assets/AQ_AudioFiles/AudioSo/EnumProviders`.

**Decisions:**
- An entry name is the file name in PascalCase with spaces, hyphens and underscores removed, for example `A60-GunShot.wav` becomes
  `A60GunShot`. Typos in file names carry over, so a clip is easy to find from its file name.
- The entry comment is the path of the file below `AQ_AudioFiles`.
- Numbers are not pinned. The lock file keeps them stable. To rename an entry without changing its number, set its explicit
  offset to the current value minus 1000 first.
- `Vol8Raiz-Reloading.wav` and `Vol8RaizReloading.wav` give the same name, so the second one is `Vol8RaizReloading2`.

### Catalogs
**What it does:** Six `MID_AudioCatalogSO` assets in `Assets/AQ_AudioFiles/AudioSo/Catalogs`: `Guns`, `Grenades`, `Melee`, `Player`,
`Ui` and `World`. Each has one clip row per sound (volume 1) and one settings row per category it uses.

| Category | Value | Catalog | Mixer group | Clips |
|---|---|---|---|---|
| `GunShot` | 100 | `Sttd_AudioCatalog_Guns` | `WeaponSounds` | 40 |
| `GunReload` | 101 | `Sttd_AudioCatalog_Guns` | `WeaponSounds` | 33 |
| `GunEmpty` | 102 | `Sttd_AudioCatalog_Guns` | `WeaponSounds` | 11 |
| `GunCharge` | 103 | `Sttd_AudioCatalog_Guns` | `WeaponSounds` | 2 |
| `GunOther` | 104 | `Sttd_AudioCatalog_Guns` | `WeaponSounds` | 3 |
| `GrenadeExplosion` | 105 | `Sttd_AudioCatalog_Grenades` | `GrenadeSounds` | 11 |
| `GrenadeThrow` | 106 | `Sttd_AudioCatalog_Grenades` | `GrenadeSounds` | 2 |
| `GrenadeOther` | 107 | `Sttd_AudioCatalog_Grenades` | `GrenadeSounds` | 1 |
| `MeleeHit` | 108 | `Sttd_AudioCatalog_Melee` | none | 3 |
| `MeleeThrow` | 109 | `Sttd_AudioCatalog_Melee` | none | 6 |
| `Voice` | 5 | `Sttd_AudioCatalog_Player` | `PlayerDialog` | 14 |
| `PlayerMovement` | 110 | `Sttd_AudioCatalog_Player` | none | 4 |
| `PlayerOther` | 111 | `Sttd_AudioCatalog_Player` | none | 2 |
| `Jetpack` | 112 | `Sttd_AudioCatalog_Player` | `JetpackSounds` | 1 |
| `Ui` | 3 | `Sttd_AudioCatalog_Ui` | none | 13 |
| `Music` | 1 | `Sttd_AudioCatalog_World` | `Music` | 8 |
| `Ambience` | 4 | `Sttd_AudioCatalog_World` | none | 1 |

**Decisions:**
- A category sits in exactly one catalog, so no category has two settings rows.
- Only categories with an obvious group in `MainMixer` have one. The others use the default group of `MID_AudioManager`.
- `Music`, `Ui`, `Ambience` and `Voice` are the package categories. The package already provides them.
- The one loose file in `AQ_AudioFiles`, the BandLab bass loop, is filed under `Music`.

### Gameplay playback
`SttdFxManager` is the single gateway for game sounds. A call names the `AudioCategory` of the sound, and the category decides
whether it plays and how loud.

- `PlaySound(clip or AudioId, category, position, volume, pitch)` is a one-shot. It plays through a pooled `MID_SpawnableAudio`,
  with a budget of 12 sounds per frame, and falls back to `MID_AudioManager.PlayClipDirect` when the pool is not ready. Nothing
  plays on a machine without rendering (a dedicated server).
- `CategoryGain(category)` is 0 when the category is muted, otherwise the master volume times the runtime volume of the category
  (`SetCategoryVolume`). It is 1 when the scene has no `MID_AudioManager`, so a scene without one plays as before.
- `PlayOnSource` and `PlayOneShotOnSource` play on a source that belongs to an entity, for a voice that has to be interrupted,
  faded or looped. The volume comes from the category, the loop setting of the source is left alone.

Which sound uses which path:

| Sound | Category | Path |
|---|---|---|
| Gun shot | `GunShot` | pooled one-shot, one `ClientRpc` per shot to the other machines, at most one per 0.1 s per weapon |
| Gun reload | `GunReload` | two sources on the gun that scrub and cross fade the clip, volume from the category |
| Reload line, hit grunt, death line | `Voice` | the dialogue source of the player, one voice at a time |
| Power weapon shot | `GunShot` | pooled one-shot |
| Power weapon charge and beam | `GunCharge`, `GunShot` | the weapon's source, which loops and fades, volume from the category |
| Projectile impact | `GunOther` | pooled one-shot through `UnifiedInGameAudioManager`, which keeps the clips and the throttling |
| Explosion | `GrenadeExplosion` | pooled one-shot through `UnifiedInGameAudioManager` |
| Grenade throw and explosion | `GrenadeThrow`, `GrenadeExplosion` | pooled one-shot |
| Weapon swap | `GunOther` | catalog id `WeaponSwap2` (serialized on `NetcodeWeaponCatigorizer`, `WeaponSwitch1` is the other clip), pooled one-shot on the machine of the human who swaps, silent for the quick switch after a respawn |
| Melee throw | `MeleeThrow` | pooled one-shot, plays on the machine of the thrower |
| Melee hit | `MeleeHit` | pooled one-shot, plays on the server machine where the hit is decided |
| Footstep and slide of players and bots | `PlayerMovement` | catalog ids, pooled one-shot, bots send one `ClientRpc` per step |
| Jetpack flying, jump and boost | `Jetpack` | the two sources on the jetpack, volume from the category |
| Map interactables | `Sfx` | pooled one-shot |

The pooled prefab (`SpawnableExtraAudio.prefab`) holds `MID_SpawnableAudio`. It held the older `SpawnableAudioManager` of the game,
so the package component was never found on it: the gun left a pooled object behind on every shot and played nothing, and the other
pooled sounds fell back to a flat 2D clip. The sounds are 2D (`spatialBlend` 0), the position is only where the sound starts.

### `UnifiedInGameAudioManager.cs`
Holds the impact and explosion clips and the throttling (per impact type, per explosion) and plays them through `SttdFxManager`. The
flight and sequential audio API, which no script called, is removed together with its pooled bookkeeping. The serialized clips and
volumes in the scenes are unchanged, the unused flight volume field is dropped. Logging uses `MID_Logger` with `_logLevel`.

### Generated files
`AudioId.cs`, `AudioCategory.cs` and `AudioTypeLock.json` in `Assets/MidManStudio/Generated/Audio` were extended with the new blocks.
Run `MidManStudio > Audio > Audio Type Generator` and `Generate Now` to confirm. It should report no changes. If it reports any,
commit what it writes.

### Adding a sound
1. Add the file to `AQ_AudioFiles` and let Unity import it.
2. Add an entry to `AudioIdProvider_Sttd` and run `Generate Now`.
3. Add a row to the catalog that fits, with the new id, the category and the clip.
4. Play it with `MID_AudioManager.Instance.PlaySFX(AudioId.Name)` or, at a position, `SttdFxManager.PlaySound(AudioId.Name, position)`.

## Fixes and Problems
- Open: the six catalogs are not in the `Catalogs` list of any `MID_AudioManager`, and no scene or prefab in the repo holds a
  `MID_AudioManager`. Until one exists with the catalogs added, `SttdFxManager.PlaySound(AudioId, ...)` plays nothing and logs one
  warning.
- Open: `MeleeHit`, `MeleeThrow`, `PlayerMovement`, `PlayerOther`, `Ui` and `Ambience` have no mixer group. `MainMixer` has both
  `PlayerSoundEffects` and `PlayerSounds`, and no group for melee, UI or ambience that clearly fits.
- Weapons, grenades, melee, dialogue, the jetpack and the bot movement now play through `SttdFxManager` with a category, see
  "Gameplay playback". The weapon, grenade and melee configs still hold plain clips, so those sounds are not catalog ids yet. A
  config can later hold an `AudioId` next to its clip.
- Open: the pooled path applies the muting and the runtime volume of a category, and not the base volume or the mixer group that the
  catalog stores for it. `MID_AudioManager` keeps both private. A public `TryGetPlayback(id, out clip, out gain, out group)` in the
  package, with `Configure` taking a mixer group, would close it. Until then set the output group of the audio source on
  `SpawnableExtraAudio.prefab` in the editor.
- Open: gun and power weapon shots send one `ClientRpc` per shot (a gun at most one per 0.1 s). Unreliable delivery for it would cost
  less, and needs a test.
- Open: the sounds are 2D and have no distance falloff, so a far shot is as loud as a near one.
- Open: the melee hit sound plays on the server machine only. The clone has no transform sync, so clients do not see it either.
- Editor work: delete `SpawnableAudioManager.cs` and `SoundEffectManager.cs` (nothing references them now), remove the unused
  `AudioSource` from the grenade, melee clone and bot prefabs, and put a `MID_AudioManager` with the six catalogs into the scenes
  (a scene without one plays clips at full category volume, and catalog sounds by id stay silent).
- `BotEffectsController` plays its footstep and slide from the catalogs like the player (`StickmanOneFootStep`, `PlayerSlide1` and `PlayerSlide2`). The server sends one `ClientRpc` per step, carrying the dust particle and the footstep together, and one per slide, so every machine plays them and the host plays them once. Before, the sound played through an `AudioSource` on the server machine only. The `AudioSource` field is removed, the component stays on the bot prefab until it is deleted in the editor.
- Open: `AudioSo/Player/Player_Audio_Catalogue.asset` was not read, because it is stored in Git LFS, and was not changed.
- Open: nothing here has been opened in Unity. The new assets were written by script from the `.meta` files, so check the catalogs
  for missing clips and mixer groups after the first import.
