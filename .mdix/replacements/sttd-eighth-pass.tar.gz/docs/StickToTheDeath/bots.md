# Bots

Audit of the bot system: AI scripts, the spawn handler, the server damage and respawn files that bots go through, and the lobby side bot files. Static read of the scripts at commit 57edd61, followed by a first batch of fixes: the player list that replaces the scene scans, the stuck detection fix, the async methods of the bot, bot handler, respawn and bot animation files, and the logging of the files that were touched. Each file section lists what was fixed and what is still open. A second pass then traced the whole call tree from spawn to team assignment, layers, damage, points and respawn, read the prefabs, and fixed the findings that matter for offline play. The online runner and the online lobby team data are still open, see "Open after the second pass". The client side layering and the spawn sequence of `TeamPlayer` were fixed afterwards, see its section.

## Files

| File | Lines | async methods before batch 1 | Logging before batch 1 |
|---|---|---|---|
| `AI_AiScripts/BotPlayer/NetBotPlayer.cs` | 1962 | 8 (`InitializeBot`, `WaitForLoadout`, `AttemptToFindPlayerTarget`, `SetupInitialWeapon`, `MoveBackALittle`, `OnBotUniqueBehaviourChanged`, `OnIsStuckValueChanged`, `OnBotHealthStateChanged`) | `RunLog` helpers over `MID_HelperFunctions`, 7 `Debug.Log` in context menus |
| `AI_AiScripts/Handler/NetBotPlayerHandler.cs` | 1077 | 8 (`OnAllPlayersSpawned`, `OnReadyToStartMatch`, `OnTimerStateChanged`, `SpawnBotsBasedOnMode`, `SpawnBots`, `ConfigureBotAfterSpawn`, `InitializeBotLoadouts`, `ManualSpawnBots`) | helpers over `MID_HelperFunctions`, enabled by default |
| `AG_PlayerScripts/Player/IAmPlayerServiceLocator.cs` | 252 | 0 | 13 `MID_HelperFunctions` calls, a per frame `Update` with a test key |
| `AI_AiScripts/BotPlayer/BotMovementController.cs` | 596 | 0 | `MID_HelperFunctions` |
| `AI_AiScripts/BotPlayer/BotAICommands.cs` | 264 | 0 | none |
| `AI_AiScripts/BotPlayer/BotPathfindingModule.cs` | 282 | 0 | 1 `Debug.LogError` |
| `AI_AiScripts/BotPlayer/BotAnimationController.cs` | 255 | 1 (`HandleAnimationStateChange`) | `MID_HelperFunctions` |
| `AI_AiScripts/BotPlayer/BotEffectsController.cs` | 369 | 0 | `MID_HelperFunctions`, 1 `Debug.Log` |
| `AJ_ExtraNetcodeScripts/NetDamageHandler.cs` | 746 | 0 | `RunLog` helpers |
| `AJ_ExtraNetcodeScripts/NetRespawnHandler.cs` | 647 | 5 | `RunLog` helpers |
| `AI_AiScripts/Shared/INetworkDamagable.cs` | 82 | 0 | none |
| `AH_LobbyScripts/Online/Bots/BotLobbyManager.cs` | 634 | 3 | 9 `Debug.Log` |
| `AH_LobbyScripts/Online/Bots/UI/InLobbyBotUI.cs` | 505 | 0 | 19 `Debug.Log` |
| `AH_LobbyScripts/Online/Bots/BotNamePool.cs` | 727 | 0 | 13 `Debug.Log` |
| `AH_LobbyScripts/Online/Bots/BotNameGenerator.cs` | 1014 | 0 | 18 `MID_HelperFunctions` |

## Summary

Priority is by effect on play and on frame time. Every item is explained in the file sections below.

| # | Finding | Where | Effect | Status |
|---|---|---|---|---|
| 1 | Stuck check compares the bot position with itself, so it is always stuck while chasing | `NetBotPlayer` | A chasing bot jumps and backs up about once a second | Fixed |
| 2 | `FindObjectsByType` scene scans per bot, about 6 per bot per second | `NetBotPlayer` | Frame time and GC allocation grow with bot count | Fixed |
| 3 | `[ServerRpc]` with default ownership on the damage entry point | `NetworkServerManeger` | Melee and power weapon hits sent by a non-host client are rejected by Netcode. Bot hits pass. Needs a test with a client | Fixed: open to every client with a sender check on the server |
| 4 | No team check on the server for grenade explosions and particle damagers, and none in `NetDamageHandler` | `GrenadeScriptMain`, `ParticleDamager`, `TrigerStayDamager`, `NetDamageHandler` | Grenades and particle damage can hit teammates, including grenades thrown by bots | Fixed: team gate on the server |
| 5 | Async continuations run after the bot died, respawned or despawned | `NetBotPlayer`, `NetBotPlayerHandler`, `NetRespawnHandler`, `BotAnimationController` | AI switched on for a dead bot, null references after match end | Fixed |
| 6 | Per frame work in `Update` on every bot, and a command object allocated every frame | `NetBotPlayer`, `BotAICommands` | Frame time and GC allocation | Fixed in the bot scripts. The jetpack fuel `NetworkVariable` is open |
| 7 | Logging: interpolated strings built while logging is off, handler logs on by default, handler errors silenced when logs are off | `NetBotPlayer`, `NetBotPlayerHandler` | Allocation and log noise | Fixed in the files touched by batch 1 |
| 8 | Bot ids recognised by the number range 100 to 999 | `NetDamageHandler`, `NetRespawnHandler`, `NetPointsHandler` | A client id of 100 or more is treated as a bot | Fixed in the damage, respawn and points files. Four other files keep their own range check |
| 9 | Bot logic bugs: secondary weapon stored in the primary slot, difficulty `basic` never configured, patrol points only for Blue and Red | `NetBotPlayer` | Wrong weapon use, missing behaviours, patrol loop in other team setups | The weapon slot and the `basic` configuration are fixed, patrol points for other teams are open |
| 10 | Nothing requests a respawn, and `RespawnSequence` aborts after the countdown because it checks for a dead entity while the entity is in the spawning state | `NetRespawnHandler`, `NetHealthComponent` | After a death nobody comes back, bots included | Fixed: the health component raises a server event for every death, the respawn handler listens to it |
| 11 | Team Deathmatch adds no team point on a kill | `NetDamageHandler`, `NetPointsHandler` | The match can only end by timer, the team score stays at 0 | Fixed: one point per kill |
| 12 | Free For All puts everyone on `_BlueTeam` while every damage and target check requires different teams | all damage dealers, `NetBotPlayer` | Nobody can damage anybody in Free For All, bots never find a target | Fixed: `NetTeamRules` |
| 13 | Survival enemy and summon receivers were looked up as players or bots first and dropped | `NetDamageHandler` | Damage to survival enemies did not reach its handler | Fixed: routed before the player lookup |
| 14 | Serialized tick rates on the bot prefab override the code defaults, aiming ran at `Tick_0_02` | `NetBotPlayer` | 50 aiming callbacks per second per bot, below the dispatcher floor | Fixed: rates are constants in code |
| 15 | The bot weapon loop is a coroutine that polls every 0.01 to 0.2 s, and the power weapon is never told to stop | `NetBotPlayer` | Polling below the floor, a power weapon that keeps firing after the target is gone | Fixed: `Tick_0_05` subscription, stop on every fire stop |
| 16 | Difficulty probability lists add up to more than 10000 or are longer than the behaviour list, `goToMapPoint` is unreachable for the top two tiers | `NetBotPlayer` | The top tiers never go to map points | Fixed: relative weights |
| 17 | The line of sight mask of the master and elite tiers misses layers 3 and 9, where the local human places players | `NetBotPlayer` | Those tiers may never fire at a human | Fixed: both layers added |
| 18 | The multikill window is reset by each owner's client, so it never resets for bots and for remote clients | `NetPointsHandler` | Bots collect multikill bonuses for their first seven kills and then none, remote clients never reset | Fixed: one server side window of 20 s for every entity |
| 19 | Team points RPC counts every team except Blue as Red, and three RPCs accept any client | `NetPointsHandler`, `NetworkServerManeger` | A client can move the score, black and white points land on Red | Fixed |
| 20 | Damage over time from status effects called `ApplyDamage` directly | `NetStatusEffectComponent`, `NetDamageHandler` | A burn death gave no kill credit, no ragdoll and no death count | Fixed: the tick goes through the damage handler and credits the entity that applied the effect |
| 21 | The death boundary called `ApplyDamage` on every machine | `DeathBoundry`, `NetDamageHandler` | A fall gave no ragdoll and no death count, clients logged an error on every contact | Fixed: environmental damage on the server, credits nobody |
| 22 | `FreeForAllHandler` was an empty placeholder | `FreeForAllHandler`, `NetPointsHandler` | Free For All had no end condition | Fixed: kill limit of 30, the first entity that reaches it ends the match |
| 23 | Summons compared teams on their own and searched the scene with `FindObjectsByType` | `HunterBehavior`, `TurretBehavior` | No targets in Free For All | Fixed: `NetTeamRules` and the entity list |
| 24 | Bot footsteps and slides played through an `AudioSource` on the server machine only | `BotEffectsController` | Other machines never heard a bot walk | Fixed: catalog sounds and a `ClientRpc` per step |
| 25 | `TeamPlayer` asked for its team 200 ms after the spawn. The team handler initializes with the match timers, about 0.2 s after the last player spawned, so the request raced the initialization. The spawn sequence also had no failure path, and every bot ran the human path first | `TeamPlayer`, `NetTeamHandler` | The team request can be dropped and the player waits 5 s, the position sync stays off after an exception or a despawn, bots ask for a team for id 0 | Fixed: one coroutine that waits for the handler, a `finally` that restores the authority, bots recognised by their prefab |
| 26 | `TeamPlayer` read the match mode from the coordinator cast to `IGameManager`, and the coordinator is not one, so the result was always null | `TeamPlayer` | The layer pass always used the Team Deathmatch rule, so Free For All put every entity on the teammate layer (everyone is on `_BlueTeam` there), and the Survival timer was never hidden | Fixed: `NetTeamRules` for the layers, the game manager is read from the coordinator |
| 27 | Layers were refreshed only when the local player's own team changed, `SetIsBotServerRpc` accepted any client, the HUD was pushed every 0.2 s and started from fixed values | `TeamPlayer`, `NetPointsHandler` | On a remote client a bot or player that spawns later keeps the prefab layer, a client could mark any entity as a bot, the team score bars started at a wrong threshold | Fixed: a static event re-layers the local human, the RPC accepts only the server, the HUD pushes on change, the start values come from the points handler |
| 28 | The indicator system scanned the scene with `FindObjectsByType<TeamPlayer>`, called `GetComponent` per player and built two collections on every tick, stored serialized tick rates (`SuperiorPlayer`: `Tick_0_02`), never showed a hidden indicator again and used plain team equality | `PlayerDirectionalIndicatorSystem` | Clairvoyance would cost a scene scan at 50 per second, indicators vanish after the first hide, everyone looks like a teammate in Free For All | Fixed: entity list, fixed `Tick_0_1`, reused collections, indicators shown again, `NetTeamRules` |
| 29 | The clairvoyance behaviours scanned the scene twice, compared teams by equality and logged through `MID_HelperFunctions` | `ClairvoyanceBehavior`, `CounterClairvoyanceBehavior` | In Free For All Clairvoyance reached everyone | Fixed: entity list, `NetTeamRules`, `MID_Logger` |
| 30 | Clairvoyance never reached a player: the `ClientRpc` methods were on a `MonoBehaviour` and carried the summon object, nothing called `PlayerDirectionalIndicatorSystem.Initialize`, the arrow turned around Y (edge-on in a 2D view) and Counter-Clairvoyance only made the arrows spin | `ClairvoyanceBehavior`, `CounterClairvoyanceBehavior`, `PlayerDirectionalIndicatorSystem`, `NetworkServerManeger` | The summons had no effect | Fixed: counted buffs sent to the affected clients through the server manager, lazy initialization, arrow around Z, Counter-Clairvoyance switches the enemy clairvoyance off |
| 31 | `NetcodeWeaponCatigorizer` decided bot or human while it spawned, from a flag that is set after the spawn, so bots took the human path (a HUD subscription that never ended on despawn) | `NetcodeWeaponCatigorizer` | A leaked event handler per bot | Fixed: bot detection by the prefab, the death handler stays on for every owner because nothing else resets bot ammo |
| 32 | The minions of the Hunter and the Swarm (`NetAiSummon`) were never activated, searched for the tag `MainCharacter`, accepted a target only when its health handler was disabled, sent the `NetworkObjectId` as the victim and went back to the wrong pool when they died | `NetAiSummon`, `HunterBehavior`, `SwarmBehavior` | The minions stood still and never hurt anyone | Fixed: self activation, entity list and `NetTeamRules`, owner id from the locator, pool type set |
| 33 | The Hunter explosion sent `OwnerClientId` as the victim | `HunterBehavior` | A bot in the blast was not damaged and the host was hit instead | Fixed: the id of the entity and `GetRegularDamageType` |
| 34 | A bot had a patrol point only in Blue against Red | `NetBotPlayer` | Every other team, Free For All and Survival fell back to searching | Fixed: the spawn points of the real enemies, see `NetBotPlayer.cs` |
| 35 | The projectiles of the Turret and the Bomber were spawned without velocity, config or owner (`ObjectNetSync` is on no prefab, the ownership lines were commented out) | `TurretBehavior`, `BomberBehavior`, `SummonProjectiles` | The turret and the bomber never hurt anyone | Fixed: they fire through `UnifiedProjectileManager` with the owner of the summon |
| 36 | A bot behaviour that was rolled twice in a row did not run the second time, because it ran in the change callback of a `NetworkVariable` | `NetBotPlayer` | Repeated crouch, slide, grenade and summon were lost | Fixed: the behaviour runs at the roll |

## Server ownership and team damage

### What holds

- All AI runs on the server only. Every tick callback, `Update`, `FixedUpdate`, the fire coroutine and the pathfinding loop are guarded by `IsServer`. The decision state (`n_BotState`, difficulty, selected weapon, fire flag, stuck flag) is a server written `NetworkVariable`.
- Bots are spawned by `NetBotPlayerHandler` on the server, with the team taken from `NetTeamHandler` pre-assignments before the object is created and the bot id and bot flag set right after the spawn.
- A bot hit goes to `NetworkServerManeger.DoDamageRequestServerRpc` and then `NetDamageHandler.ProcessDamageRequest`, the same path as for players. The damage type is derived from the bot flag of attacker and victim (`Player_Damage_Bot`, `Bot_Damage_Player`, `Bot_Damage_Bot`), and all four regular types go through `HandleRegularMatchDamage`.
- Respawn of a bot goes through `NetRespawnHandler` like a player, with its own delay (3 s for bots, 6 s for players). Every death starts it through `NetHealthComponent.OnAnyEntityDiedServer`.
- Who is an enemy is decided in one place, `NetTeamRules.AreEnemies`. In team modes different teams are enemies. In Free For All every other entity is an enemy. In Survival players and bots are one side. Spectators (`_Observer`) are never enemies. A bot can therefore target and hit a human of an enemy team and the other way round, the host player included, because bots are server owned objects with their own id and are never confused with client id 0.
- Kills, points and streaks are keyed by the damage sender id, which is the bot id for a bot. Registering client id 0 from a bot's `TeamPlayer` is harmless, because `AddEntityToAllDictionaries` skips ids that exist.

### Damage sources and where the team is checked

| Source | Runs on | Team check |
|---|---|---|
| Projectiles (server sim) | server | `ConsolidatedProjectileDamageHandler.ShouldDamageTarget`, which asks `NetTeamRules` |
| Melee swing | owner, the server for bots | `NetTeamRules` in `MeleeWeaponHandler` |
| Thrown melee | server, per the file comments | `NetTeamRules` in `MeleeClone` |
| Power weapon raycast and laser | owner, the server for bots | `NetTeamRules` in `PowerWeaponHandler` |
| Summons | server | `HunterBehavior` and the other behaviours |
| Grenade explosion | server | none in `ProcessExplosionDamage`, the proximity mine trigger asks `NetTeamRules` and never fires on its owner. Covered by the server gate |
| Particle damagers | not read | none seen in `ParticleDamager` and `TrigerStayDamager`. Covered by the server gate |
| `NetDamageHandler` | server | team gate for the four regular damage types, for every source |

### What the server checks now

- `DoDamageRequestServerRpc` is open to every client. A remote client may only report damage its own player dealt: the sender id has to be its client id, and the type has to be `Player_Damage_Player`, `Player_Damage_Bot`, `Player_Damage_SurvivalEnemy`, or `SelfHarm` on itself. Anything else is rejected with a warning that is always logged. Server code (projectiles, grenades, bots, the host player) calls the RPC locally and is trusted. Before this change Netcode rejected every call from a non-host client because the RPC required ownership of a server object, so melee and power weapon hits of client players did not arrive. This needs a test with a real client.
- `HandleRegularMatchDamage` is the team gate for all sources, through `NetTeamRules`. Players and bots on the same team do not damage each other in team modes, in Free For All everyone else can be damaged, and spectators (`_Observer`) neither deal nor take damage. Damage from an entity to itself is not a team question and passes.
- `IncrementTeamPointsServerRpc` and the registration RPC accept a remote client only for what that client may do: team points only from server code, registration only for the client's own id.
- A respawn request from a remote client is accepted only for its own player, never for a bot or another player.
- Bots are recognised by `NetBotPlayerHandler.IsSpawnedBot`, which asks the spawned bots, instead of a number range.

### What is open

- The damage amount comes from the reporting client. The server has no weapon data to check it against, and a distance check was left out because the weapon ranges are not known to the server. The sound fix is to compute melee and power weapon damage on the server.
- `NetEqItemSpawner` (range 100 to 999) and `NetTeamHandler`, `OfflineTeamManagementSystem`, `OfflineGameRunner` (range 100 to 109) have their own copy of the number range check. They move to `IsSpawnedBot`, or to a bot id check that works before the bots exist, when those files are touched.

## `NetBotPlayer.cs`

**What it does:** The bot brain. A server side state machine (`Initializing`, `SearchingForTarget`, `ChasingPlayer`, `PatrollingMap`, `GoingToMapPoint`, `Retreating`) with four tick subscriptions (target search 0.2 s, decision 0.1 s, unique behaviour 2 s, stuck check 1 s), a weapon tick (0.05 s, only while the bot fires), a per frame `FixedUpdate` for path following and the difficulty table.

### Fixes

- **Stuck detection.** `OnStuckCheckTick` stored the integer x and then compared it with the current x in the same call, so a bot with a target reported stuck on every check. The check now samples the position and counts a strike when the bot moved less than 0.5 units since the last check while it should be following a path and is farther from the target than `minFireDistance`. Two strikes in a row set `isStuck`. A bot inside its fire range is allowed to stand still. The recovery (jump, then `MoveBackALittle`) cannot overlap with itself, and `ResetBotState` stops it.
- **Player list.** `TryFindPlayerTarget`, the chase branch of `OnTargetSearchTick` and `CheckBotProximity` read `IAmPlayerServiceLocator.All` instead of calling `FindObjectsByType`. The proximity check also no longer needs a scan of the bots, it uses the bot flag of the locator. Nothing is allocated by these checks now.
- **Async methods.** All eight are gone. Single step waits use `MID_TickDelay` with a delegate created once in `Awake`: the 2 s crouch and the 1 s wait before the AI is enabled after a respawn. `MID_TickDelay` costs no coroutine object, a handle cancels it, and its minimum step of 0.1 s is fine for these waits. Multi step sequences are coroutines, because they keep state between steps: the initialization pipeline (`InitializeBotRoutine`, loadout wait, weapon setup, target search), the stuck recovery and the retreat.
- **Cancellation.** The wait before the AI is enabled is cancelled by the `Spawning` and `Dead` states, so a bot that died again no longer gets its AI switched on. The stuck recovery and the crouch are cancelled by `ResetBotState`. Despawn stops everything. A second call of `InitializeBot` while the first one runs is ignored.
- **Weapon slot.** `SetupInitialWeapon` stored a secondary weapon in `_primaryGunScript`. It stores it in `_secondaryGunScript` now.
- **Per frame work.** `Update` is gone. `OnDecisionTick` runs the distance update, the state machine, the shot point assignment and the weapon switch check on `Tick_0_1`, one subscription instead of the old distance tick plus a per frame call. The state machine, the fire check (a raycast for the top difficulties) and the jetpack flame run 10 times per second instead of every frame. The map point timer uses the tick interval instead of `Time.deltaTime`. The `StopAllMovement` call every frame while the AI is off is gone, the health callbacks already stop the bot once. `FixedUpdate` stays: path following moves waypoint by waypoint and sets the move input, and the waypoint advance needs the physics step.
- **Logging.** `_enableLogs` and `_enableDetailedLogs` are replaced by `_logLevel`, default Error. `RunLog`, `RunLogWarning` and `RunLogError` call `MID_Logger`. Debug messages that build an interpolated string are guarded by `DebugOn`, so the string is not built while logging is below Debug. The two toggle context menus are gone, the state and target menus print through `MID_Logger`.

- **Tick rates.** The five rates are `const` values in the script. They were serialized fields, and the bot prefab stored its own values for them: aiming at `Tick_0_02` (50 callbacks per second per bot, below the dispatcher floor), target search at 0.1 s, unique behaviour at 1 s and stuck check at 0.5 s. A serialized value on a prefab can no longer lower a rate.
- **Aiming.** There is no aiming tick. `SetTarget` hands the target transform to the arm controller, which follows its position on its own, so `OnTargetSearchTick` only re-asserts it every 0.2 s.
- **Weapon loop.** The fire coroutine is a `Tick_0_05` subscription that exists only while `fireWeapon` is true (`StartFireTick`, `StopFireTick`, `OnFireTick`). A shot is tried every `botFireRate` seconds rounded up to a whole tick, so the tiers at 0.05 s and 0.01 s both shoot once per tick. The gun's own cooldown limits the real rate, `ShootForBots` checks it. `StopFireTick` also calls `StopBotShoot` on the power weapon, which nothing called before, so a bot's power weapon stopped firing only when it timed out.
- **Difficulty.** `SetBotDifficulty` picks from fixed weights (basic 40, advanced 40, master 10, omoThisNaMaye 6, shegeaDanIska 4 percent) and no longer reads lists from the prefab. A roll equal to the current value (`basic` is the default) raises no change event, so `ConfigureDifficultySettings` is called directly in that case. The behaviour roll uses the sum of its list as the range, so every entry can be reached whatever the lists add up to. The top two tiers added up to 10100 and could never roll `goToMapPoint`.
- **Targets.** `IsValidTarget` asks `NetTeamRules`, so spectators are no targets, Free For All makes everyone else one, and Survival makes none.
- **Line of sight.** The master and elite checks use the prefab mask plus layers 3 and 9. The local human re-layers every entity from their own view (main 3, teammate 9, enemy 10, see `TeamPlayer`), and the prefab mask covers only 7 and 10 to 12, so a human on layer 3 or 9 could not be seen.
- **Patrol points.** A bot patrols toward where its enemies spawn, for every team. `GetRandomEnemySpawnPoint` takes the teams of the enemies that are in the match (`NetTeamRules.AreEnemies` against the bot), asks `NetworkServerManeger.GetTeamSpawnPoints` for the points of each team, and picks one point of the union. Blue still goes to Red and Red to Blue. Free For All and every team that has no points of its own (they spawn on the free-for-all points) use the free-for-all points, Survival uses the survival ground spawns. With no enemy in the match yet, or no points for them, it falls back to every player spawn point of the map. The candidate lists are reused, nothing is allocated per call.
- **Unique behaviour.** The behaviour is rolled every 2 s (`Tick_2`) from the weights of the difficulty and now runs at the roll, on the server. It used to run in the change callback of `n_CurrentBotSpecialBehaviour`, which raises nothing when the same value is rolled twice, so a repeated crouch, slide, grenade or summon was lost. The variable stays as a record of the last roll, the callback is gone. The callback was only subscribed on the server, so nothing on a client depended on it. Bots now act as often as the weights say, a little more often than before.

### Problems

- **Retreat.** `MoveBackALittle` still moves the bot with a tween on the transform, which ignores physics.
- **Survival.** Bots do not target survival enemies. They only look for players and bots.

## `NetBotPlayerHandler.cs`

**What it does:** Server side spawner. After all players have spawned it decides the bot count (offline: `OfflineLobbyManager`, online: `LocalLobby`), instantiates each bot at a team spawn point, spawns the network object, sets id and bot flag, registers it in the server manager, and starts the loadout requests with random delays.

### Fixes

- The spawn sequence is coroutines now: waiting for the libraries, the trigger delays (0.5 s, 1 s), the 0.05 s and 0.1 s steps between bots, the 0.5 s wait before the loadouts, the wait for a bot id and the random delays between loadout requests. The waits use real time like the old `Task.Delay` calls, so a paused time scale does not stall the spawn. `OnNetworkDespawn` stops all of them.
- A coroutine cannot yield inside a try block with a catch. The per bot work is split into `TrySpawnBot` (instantiate, scene move, network spawn), `FinishBotSpawn` (id, tracking, registration, team request) and `TryRequestBotLoadout`, each with its own try block, and the waits sit between them.
- The four line banner per bot is a single log line. `_enableLogs` (on by default) is replaced by `_logLevel`, default Error, and the helpers call `MID_Logger`. Errors are no longer hidden when the old flag was off. The info context menus print through `MID_Logger`.
- The B key spawn test exists only in the editor and in development builds. `ManualSpawnBots` is a normal method that starts the coroutine.
- `IsSpawnedBot(id)` is the one place that answers whether an id is a spawned bot. The damage, respawn and points files use it.
- `SpawnBotsBasedOnMode` ignores a second call while a spawn is running (`_botSpawnInProgress`). The all-players event and the ready backup can both start one, and a spawn takes several frames, so `currentBots` alone did not stop a second spawn of the same ids when the libraries finished late.

### Problems

- `ClearAllBots` destroys the game objects without despawning the network objects first.
- `IsPlayerABot` scans all spawned bots. The bot flag on `TeamPlayer` answers the same question without a scan.

## `IAmPlayerServiceLocator.cs`

**What it does:** The per player and per bot service locator on the player prefab. It holds the references to the player parts, the owner id and the bot flag.

### Fixes

- `All` is a read only list of every enabled player and bot in the process. The locator adds itself in `OnEnable` and removes itself in `OnDisable`, and the list is cleared when play mode starts so a disabled domain reload does not leave stale entries. `PlayerRegistry` was not used for this because nothing registers into it.
- The per frame `Update` with the P key test that called a client RPC is removed.
- The 13 editor-only helper logs became `MID_Logger` calls with a serialized `_logLevel`, default Error. The kill popup RPC reaches every client, so the early returns of the non-owners no longer log.
- `get_BodyRenderers` replaces the three renderer getters. It returns the PSD part renderers when the applier has resolvers and the old body and two arm renderers otherwise, without nulls. The old prefabs keep working because they have the three renderers set.
- `get_PlayerArmHandler` searches the children once for an `ArmMove` when `_armHandler` is empty. `PlayerMovementController.IsFacingRight` depends on it: without the arm handler it reads `localScale.x`, which never changes with the euler flip, so the camera saw the player as always facing right.

## `BotAICommands.cs`

**What it does:** Holds what the AI wants (move input, jump, crouch, slide) and applies each wish to `BotMovementController` at its decision interval: move every 0.1 s, jump every 0.5 s, crouch every 1 s, slide every 2 s.

### Fixes

- The command classes (`IBotCommand` and five command types) were created with `new` on every frame for the jetpack and on every decision. Nothing else used them. They are deleted and the controller is called directly.
- The per frame `Update` is replaced by one `MID_TickDispatcher` subscription on `Tick_0_1`, made in `OnNetworkSpawn` on the server and removed in `OnNetworkDespawn`. The decision timers count down by the tick interval and fire at a small epsilon, so a timer that lands on zero by float error does not skip a whole tick. The shortest decision interval is 0.1 s, so no faster rate is needed. The dispatcher guide forbids `Tick_0_02` and `Tick_0_01` for gameplay logic, and nothing in the bot code goes below `Tick_0_05`.
- Jetpack fuel was processed twice: once here on every frame and once in the `FixedUpdate` of `BotMovementController`. The fuel burned about twice as fast as the 3 s the controller allows, and the call here is removed. Bots now fly for the full fuel time. Balance should be checked in play.

## `BotMovementController.cs`

**What it does:** Server authoritative bot movement: ground check, jump and jetpack, slide, animation state and the tunneling check.

### Fixes

- The tunneling check subscribed to the 0.05 s tick in `Awake` on every peer, and only the server unsubscribed. The subscription is made in `OnNetworkSpawn` on the server and removed through a guarded helper. The tunneling warning uses `MID_Logger`.
- `FixedUpdate` stays as it is. The ground overlap, the fuel step, the slide update and the animation state belong to the physics step.

### Problems

- `jumpTimeCounter` is a `NetworkVariable` with read permission for everyone and is written on every fixed step while the bot flies, and every frame in `QuickRefreshJetpack`. Clients have no use for the fuel of a bot. It is left alone because the thrust depends on it: `HandleJumpTimeCounterChange` applies the upward velocity each time the value changes, and `BotEffectsController`, `BotPathfindingModule` and `NetBotPlayer` read it. Moving it to a plain field means moving the thrust into `FixedUpdate` and removing the observer registrations, which is a separate change.
- Movement writes `Rigidbody2D.velocity` on the server only. Whether clients see the result through a server authoritative `NetworkTransform` is a prefab check.
- `MoveBackALittle` moves the bot with a tween on the transform, which ignores physics. The ground check before it only looks 2 units behind.

## `BotPathfindingModule.cs`

- `StopPathfinding` calls `StopAllCoroutines`, which also stops any other coroutine on that behaviour. The module has one, so this is safe today.
- Path recalculation runs every 0.3 to 0.7 s per bot depending on difficulty and skips the request when the target moved less than 1 unit. That part is fine.
- `ExecutePathFollowing` runs from the `FixedUpdate` of `NetBotPlayer`. It advances one waypoint per call, so moving it to a slower tick risks skipping nodes. It stays.
- `StartPathfinding` has no guard, so a second `InitializeBot` call starts a second path loop.

## `BotAnimationController.cs` and `BotEffectsController.cs`

### Fixes

- `HandleAnimationStateChange` waited 500 ms after a jump state with `Task.Delay` and then played the animation it had captured, even if the state changed again in between. The wait is a `MID_TickDelay` now, only the newest requested state is applied, and a later state change cancels the pending one. Despawn cancels it.
- The logging of `BotAnimationController` uses `MID_Logger` with a serialized `_logLevel`, default Error.
- `BotEffectsController.Update` ran a state check on every bot every frame. The check runs on `Tick_0_2` now (`_effectStateTickRate`), subscribed in `OnNetworkSpawn` and removed in `OnNetworkDespawn`. The effects spawn at 0.3 s at the fastest, so five decisions per second are enough. The logging uses `MID_Logger` with a serialized `_logLevel`, default Error, and the stale performance comment at the end of the file is removed.

- The footstep and the slide play from the audio catalogs like the player's (`StickmanOneFootStep`, `PlayerSlide1`, `PlayerSlide2` through `SttdFxManager.PlaySound`). One `ClientRpc` per step carries the dust particle and the footstep, so every machine plays both and the host plays them once. The `AudioSource` and the movement audio config are no longer used. The interpolated debug strings are guarded by `DebugOn`.

### Problems

- Both controllers subscribe to the animation and ground callbacks on the server only. Where the client side animator is driven from is a prefab check.
- `BotEffectsController` sends one `ClientRpc` per footstep, at most every 0.3 s per running bot. The effect can be derived on clients from the replicated animation state instead.

## `NetDamageHandler.cs`

**What it does:** Server side damage processing. Looks up sender and receiver, routes by damage type (regular match, self harm, survival, summons, environment), applies the damage through `NetHealthComponent`, and handles the kill.

### Fixes

- Team gate in `HandleRegularMatchDamage`, see "What the server checks now". It closes the grenade and particle gap and covers every source with one rule.
- Bots are looked up through `NetBotPlayerHandler.IsSpawnedBot`. The old number range 100 to 999 could take a human client id for a bot. `GetPlayerOrBotObject` no longer reads the handler singleton without a null check, `IsSpawnedBot` returns false when it is missing.
- Logging uses `MID_Logger` with a serialized `_logLevel`, default Error. Before, errors were hidden when `_enableLogs` was off. Debug messages that build a string are guarded by `DebugOn`, which matters here because the first message runs on every hit.
- The team gate calls `NetTeamRules`, see its section.
- An entity that kills itself with a regular damage type (its own grenade, for example) is a suicide through `HandleSelfKill`. Before, it was credited with a kill, a streak and the points of a kill, and since Team Deathmatch scores a team point per kill it would also have scored one for its team.
- Survival enemy and summon receivers are routed before the player and bot lookup. They are NetworkObjects of their own, and the lookup dropped them with "Receiver not found". The sender registration check stays for the survival enemy types.
- A kill adds one team point through `NetPointsHandler.AwardKillTeamPoint`, which counts only in Team Deathmatch.
- `ApplyStatusEffectDamage(ownerId, victimId, amount)` is one damage tick of a status effect, built as a normal damage request from the entity that applied the effect, so a burn death counts like any other kill for that entity. An entity that burns itself dies as a suicide (`SelfHarm`). When the entity that applied the effect is gone, the tick is environmental and credits nobody.
- `ApplyEnvironmentalDamage(victimId, amount)` is damage from the map. A death from it counts for the victim, spawns the ragdoll and credits nobody. The death boundary uses it.
- The receiver and its health component are resolved once in `ProcessDamageRequest` and handed to `HandleRegularMatchDamage`. The handler resolved both a second time on every hit.

- **Damage type helper.** `GetRegularDamageType(senderId, victimId)` returns the regular damage type from the bot flag of each entity (`IsSpawnedBot`). The status effect damage uses it, and so do the summons, which send their damage in the name of their owner.

### Problems

- The damage amount is trusted, see "What is open". Damage is an integer by design, so a hit below 1 does no damage.
- The kill feed has no value for status effect deaths. They use the grenade icon.

## `NetworkServerManeger.cs`

**What it does:** Server manager that holds the team, damage, points and respawn handlers and exposes their RPC entry points.

### Fixes

- `DoDamageRequestServerRpc` is open to every client and checks remote callers with `IsDamageRequestAllowed`, see "What the server checks now".
- `RequestRespawnServerRpc` checks that a remote client asks only for its own player, then calls `NetRespawnHandler.ProcessRespawnRequest`.
- Logging uses `MID_Logger` with a serialized `_logLevel`, default Error. Rejected requests are logged as warnings that do not depend on the level, so a forged request always shows up.
- `IncrementTeamPointsServerRpc` accepts only server code. `AddPlayerToKillPointsAndDeathDictionaryServerRpc` accepts a remote client only for its own id.
- Respawn spawn point: Free For All uses the free-for-all points when the map has them, the lists are reloaded only when all three are empty (before, every respawn reloaded them on a map without red or blue points), and the enemies near a spawn point are counted from the entity list (`CollectLivingEnemyPositions`, once per choice, living enemies only, squared distance) instead of an `OverlapCircleAll` and a `GetComponent` per collider. The old query only found colliders on the player root and counted none when the collider sat on a child.
- `CalculateSpawnPosition` offsets x only. It added the random value to z, which does nothing in a 2D game and moves the object off the plane.
- The `playerLayer` field is no longer read and stays so the scene keeps its serialized value.
- The clairvoyance RPCs live here: `SetClairvoyanceForClients` and `SetCounterClairvoyanceForClients` (server only, reusable target list, clients that left are dropped) and two `ClientRpc` methods that act on the local human of each target. A bot owned by the host also reports `IsOwner`, so bots are skipped when the local player is looked up.

- **Team spawn points.** `GetTeamSpawnPoints(team)` returns the points a team spawns on (Blue and Red have their own, Free For All and every other team use the free-for-all points) and `CollectPlayerSpawnPoints` adds every player spawn point of the map to a list. The entity spawn selection and the bot patrol selection both use them.

### Problems

- `NativeLeakDetection.Mode` is set to `EnabledWithStackTrace` in `Awake` for every build. Stack traces on every native allocation cost frame time outside the editor. Flagged, not changed.
- `ForceEndMatch` calls `ResetForNextMatch` and does not move the timer to `MatchEnded`. The offline runner does not use it. The online runner calls it, see "Open after the second pass".

## `NetRespawnHandler.cs`

### Fixes

- The five async methods are coroutines. The three respawn types share one `RespawnSequence` (spawning state and respawn UI, countdown, check that the player is still dead, respawn, HUD update), and each type keeps only its own checks and its own HUD update. The countdown, the teleport effect and the wait before the alive state use scaled time, so a paused game does not respawn bots.
- The sequence checks for a despawned player or bot after every wait. Before, a continuation after despawn threw inside the old try block or past it.
- The logging uses `MID_Logger` with a serialized `_logLevel`, default Error.
- The respawn request is a plain method (`ProcessRespawnRequest`) and no longer an RPC. The only caller is `NetworkServerManeger`, which checks who is asking. Before, any client could call the handler's RPC directly and request the respawn of any id. Bots are recognised with `IsSpawnedBot`.
- Nothing started a respawn after a death. No script, prefab or scene called `RequestRespawnServerRpc` or `ProcessRespawnRequest`. The handler now listens to `NetHealthComponent.OnAnyEntityDiedServer` (`OnEntityDied`), which covers every death source. It waits one frame so the damage handler finishes the death (ragdoll, points), picks the respawn type from the match mode (Weekend Brawl is limited, the rest infinite), and does nothing in Survival, where the survival player manager downs and revives players.
- `RespawnSequence` began in the spawning state and then aborted after the countdown because it checked that the entity is still dead. The check cancels only when the entity became alive by another route now.

### Problems

- The countdown still writes the respawn timer as a `NetworkVariable` ten times per second per dead entity. One end time on the health component, and a local countdown on clients, replaces the writes.
- `GetRespawnPosition` moves the object to the new spawn point, reads the position and moves it back. The object is moved twice per respawn.

## `NetTeamRules.cs`

**What it does:** One static helper that decides who counts as an enemy, so the server damage gate, every weapon and the bot target search agree. `AreEnemies(teamA, teamB)` is for callers that hold only teams, `AreEnemies(a, b)` takes two players or bots. The match mode is read from the game manager once per frame.

**Decisions:**

- Team modes: different teams are enemies. Spectators (`_Observer`) are never enemies.
- Free For All: every other entity is an enemy. The lobby puts everyone on `_BlueTeam` in that mode, so a team compare can never work there. The same entity is never its own enemy.
- Survival: players and bots are one side. The survival enemies and summons use their own damage types and never reach this check.
- The result is cached per frame (`Time.frameCount`), because bots and projectiles ask many times in one frame. The cache and the mode reset on `SubsystemRegistration`, so entering play mode without a domain reload starts clean.
- Callers decide on their own whether damage an entity deals to itself passes. `NetDamageHandler` lets it pass, the proximity mine never explodes on its owner.

**Tests:** Not run in Unity. Case table by reading: team mode same team false, different teams true, observer false; Free For All different entities true, same entity false; Survival false.

## `NetPointsHandler.cs`

**What it does:** Server side score keeping: kills, deaths, streaks, personal and summon points, team points and the match win threshold. Entities are keyed by id, which is the client id for a player and the bot id for a bot.

**Decisions:**

- `AwardKillTeamPoint(team)` adds one team point per kill in Team Deathmatch and does nothing in other modes. The other modes score through their own handlers.
- `AddTeamPoint` is the single place that changes the two team scores. A team other than blue or red is ignored with a warning. Before, every team except Blue counted for Red.
- `IncrementTeamPointsServerRpc` accepts only server code. A remote client call is ignored with a warning that is always logged.
- The multikill window (20 s) is tracked on the server per entity (`ExpireMultiKillWindow`, called before the bonus is computed). The owner client used to reset it through an RPC that Netcode rejects for non-host clients, and nothing reset it for bots.
- Bots are recognised with `NetBotPlayerHandler.IsSpawnedBot`. The range 100 to 999 could take a client id for a bot.
- `OnKillCountChanged(entityId, kills)` is a server event raised after a kill is counted. `FreeForAllHandler` uses it for the kill limit.
- `RefreshTeamPointsHud()` pushes the current team scores and the mode threshold to the local HUD. The client change callback and the local `TeamPlayer` share it, so the score bars start from the real values instead of a fixed target of 40.
- Logging uses `MID_Logger` with `_logLevel`, default Error. Interpolated debug strings are guarded by `DebugOn`, warnings are not.

**Tests:** Not run in Unity.

## `NetTeamHandler.cs`

**What it does:** Holds the team of every player and bot in a network dictionary. The game manager initializes it with the match mode and hands it the lobby team data (`SetPreAssignedTeams`). A player requests its team with `RequestTeamAssignmentServerRpc(id)`, the handler takes the pre-assigned team (or a balanced fallback for the mode), stores it and writes it to the entity's `m_PlayerTeam`. Bots are assigned the same way by `NetBotPlayerHandler`.

**Decisions:**

- `IsInitialized` is public. A request that arrives before the initialization is dropped with an error, and the handler initializes together with the match timers, about 0.2 s after the last player spawned. `TeamPlayer` waits for it instead of sleeping for a fixed time.
- Not changed: logging is still on `MID_HelperFunctions` behind `_enableLogs`, the bot id range check `100 to 109` in `IsBotId`, and the fallback team in Free For All and Survival (`_BlueTeam`, which `NetTeamRules` accounts for).

**Tests:** Not run in Unity.

## `NetHealthComponent.cs`

**What it does:** Server authoritative health and the health state (`Spawning`, `Alive`, `Dead`). Applies damage, heals, and raises `OnDeath` for its own entity.

**Decisions:**

- `OnAnyEntityDiedServer` is a static server event raised once per death, after `OnDeath`, whichever script applied the damage. The respawn handler listens to it. Damage over time and the death boundary reach `ApplyDamage` without the damage handler, so the respawn cannot depend on the damage handler. The event resets on `SubsystemRegistration`.
- The heal delay is counted by the existing 0.2 s heal tick (`TickHeal`) instead of a per frame `Update`. A hit restarts the delay and makes sure the tick runs, healing starts when the delay has passed and the tick stops when the health is full or the entity is not alive. The dispatcher passes the fixed tick interval, so the delay is exact to one tick.
- Logging uses `MID_Logger` with `_logLevel`, default Error, and guards interpolated debug strings, which matters because the damage message runs on every hit.

**Tests:** Not run in Unity.

## `NetStatusEffectComponent.cs`

**What it does:** Tracks the status effects on one player or bot and runs their damage over time on a server tick (0.2 s). Each effect remembers who applied it (`senderId`).

**Decisions:**

- The damage tick calls `NetDamageHandler.ApplyStatusEffectDamage` with the effect's `senderId`, so the entity that applied the effect gets the kill credit, a burn death spawns the ragdoll and counts as a death, and the respawn event fires through the normal path. Without a damage handler the tick falls back to `ApplyDamage`.
- After the tick the effects are cleared when the entity is no longer alive. That covers a death and the spawning state.
- The list of effects to remove is a field that is reused, the tick used to allocate a list every 0.2 s per entity.
- Logging uses `MID_Logger` with `_logLevel`, default Error, and the interpolated debug strings are guarded by `DebugOn`.

**Tests:** Not run in Unity.

## `DeathBoundry.cs`

**What it does:** Kills a player or bot that touches the boundary.

**Decisions:**

- Only the server acts. It used to call `ApplyDamage` on every machine, which logged an error on each client.
- The kill goes through `NetDamageHandler.ApplyEnvironmentalDamage`, so it counts as a death for the victim, spawns the ragdoll, fires the respawn event, and credits nobody.
- Only a living entity is killed, so a respawning entity is not hit again.

**Tests:** Not run in Unity.

## `FreeForAllHandler.cs`

**What it does:** The mode handler of Free For All. Every player and bot fights everyone else, and the first entity that reaches the kill limit ends the match.

**Decisions:**

- The kill limit is `_killLimit`, 30 by default, serialized on the handler in `FreeForAll.prefab`. A prefab that does not have the field yet uses the default.
- The handler subscribes to `NetPointsHandler.OnKillCountChanged` when the match starts and ends the match through the game manager's `ForceEndMatch`. Bots count like players, and they can win.
- There are no team points in this mode. The results screen ranks the players by their stats and names an MVP, and has no winning team.
- `OnMatchEnd` is not called by the coordinator for this mode, so the handler also unsubscribes in `Cleanup` and on despawn.
- Logging uses `MID_Logger` with `_logLevel`, default Error. The base class still logs through its own wrappers.

**Tests:** Not run in Unity. Play a short match with a kill limit of 3 on the prefab and watch the match end at the third kill.

## Summons

`HunterBehavior.cs`, `TurretBehavior.cs`, `BomberBehavior.cs`, `SwarmBehavior.cs`, `ClairvoyanceBehavior.cs`, `CounterClairvoyanceBehavior.cs` and `SummonProjectiles.cs`, in `AR_ScoreSummonsScripts`.

**Decisions:**

- Both ask `NetTeamRules.AreEnemies` against their owner, so in Free For All they attack everything that is not the owner, and in team modes they behave as before. A summon never attacks its owner.
- The hunter's contact check, its target search and its explosion use the rule. The target search and the owner lookup read `IAmPlayerServiceLocator.All` instead of `FindObjectsByType`.
- The turret takes the nearest living enemy inside its targeting radius from the entity list. It used a physics query and picked the first collider it found.
- `ClairvoyanceBehavior` and `CounterClairvoyanceBehavior` find the owner and the affected players in `IAmPlayerServiceLocator.All`, with no scene scan, and send the effect to exactly those human clients through `NetworkServerManeger.SetClairvoyanceForClients` and `SetCounterClairvoyanceForClients`. The same client ids are used again when the summon ends, and a client that left is dropped. Clairvoyance reaches the humans on the owner's side, the owner included: in a team mode the team, in Free For All only the owner, in Survival every player. Counter-Clairvoyance switches off the clairvoyance of the humans against the owner: in a team mode the other teams (teammates are not touched), in Free For All everyone except the owner, in Survival nobody. Before, a plain team comparison gave Clairvoyance to everyone in Free For All.
- The behaviours could not reach a player before. Their `[ClientRpc]` methods sat on a plain `MonoBehaviour` (`SummonBlueprint` adds the behaviour with `AddComponent`), so a call was an ordinary local call on the server, and the argument was `_owner.NetworkObject`, which is the summon object and has no `IAmPlayerServiceLocator`. The two `ClientRpc` methods are on `NetworkServerManeger` now, which is always spawned and reaches only the targeted clients. The unused stub `ActivateClairvoyanceServerRpc` is gone.
- A player who joins while a clairvoyance summon is alive gets the effect too. Each behaviour listens to `TeamPlayer.OnHumanTeamKnownServer` while its summon is alive and applies the same rule as at the start to the newcomer. A player who respawns keeps the buffs, the player object stays.
- The Hunter's explosion sent `OwnerClientId` of the victim, which is 0 for every bot, so a bot in the blast was not damaged and the host was hit instead. It sends the id of the entity now, and the damage type from `NetDamageHandler.GetRegularDamageType`. Its target is kept with its locator, so the per frame validity check costs no component lookup, a search without a valid target runs every 0.2 s instead of every frame, and the repeating timer that called an empty method is gone.
- `SwarmBehavior` and the Hunter hand the owner's locator to their minions (`SetOwnerRefs`). `SwarmBehavior` reads the entity list instead of `FindObjectsByType`, caches its wait object and logs through `MID_Logger`. The minions are described in the section `NetAiSummon.cs`.
- The Turret and the Bomber fire through `UnifiedProjectileManager.FireProjectile`, like the guns, with the owner of the summon as the owner of the projectile (its entity id, the summon as the shooter, the bot flag from `IsSpawnedBot`). Their own firing code spawned a pooled projectile and set it up with `ObjectNetSync`, which no prefab or scene carries, so the projectile had no velocity, no config and no owner: it was spawned and stayed where it was. The ownership lines were commented out with the old field names. The small helper `SummonProjectiles` does the call for both and maps the summon config name (`MID_AllProjectileNames`) to the generated `ProjectileConfigType`: the names match except five that are spelled differently (`BlackPhoenix`, `Poper`, `ApexMagnum`, `ApexMagnum_Raiz` and `none`, which fires nothing). `BomberBehavior` logs through `MID_Logger` and caches its wait object.
- Logging uses `MID_Logger` with `_logLevel`, default Error.

**Not changed:**

- Bots get neither clairvoyance effect, they have no indicators.
- Not verified: a bomb leaves in the direction of the shot point, which is the flight direction of the bomber (the shot point is never rotated). The projectile config decides the rest (speed, gravity), and the configs are assets that cannot be read here. If bombs should fall, the call in `DropBomb` takes `Vector2.down`.

## `PlayerDirectionalIndicatorSystem.cs`

**What it does:** World space arrows around the local player that point at the other players and bots while clairvoyance is active. One pooled indicator per entity, with a teammate prefab and an enemy prefab. It sits on `SuperiorPlayer.prefab` and `Stickman_Base.prefab`, in `AG_PlayerScripts/Player`.

**Decisions:**

- One dispatcher subscription at `Tick_0_1`, a constant in code, only while clairvoyance is active. The component stored two tick rates on the prefabs, and `SuperiorPlayer` stored `Tick_0_02` (50 per second) as the clairvoyance rate, which no code default could correct. The old default was `Tick_0_05`, which the dispatcher keeps for weapon and projectile checks. The "normal" rate was never subscribed and is gone.
- Each tick walks `IAmPlayerServiceLocator.All`. There is no scene scan and no `GetComponent` per entity, the two collections are reused, and ranges are compared as squared distances.
- Teammate or enemy comes from `NetTeamRules.AreEnemies` against the live team of the local player. It used plain team equality against a team that was read once at initialization.
- A hidden indicator (dead, out of range, clairvoyance switched off) is shown again when its entity is back in range. It stayed hidden for good before.
- The tick subscription is restored on enable.
- Clairvoyance and counter-clairvoyance are counted on the player (`ActivateClairvoyance`, `DeactivateClairvoyance`, `ActivateCounterClairvoyance`, `DeactivateCounterClairvoyance` add and remove one). The arrows show while at least one clairvoyance is on and no counter-clairvoyance is on, so two summons stack, the first one to end does not switch the other off, and a clairvoyance that is still on comes back when the counter ends. The tick is only subscribed while the arrows show.
- Counter-clairvoyance switches the arrows off. It used to make them spin and point in random directions, that code is gone together with its serialized fields.
- The system initializes on first use. The server manager calls `EnsureInitialized` on the local human before it passes the first activation, so the pools are only built for the player who can see arrows. Nothing called `Initialize` before, so the system never showed anything.
- The arrow turns around Z toward the target in the XY plane, with `_spriteAngleOffset` (degrees) for a sprite that does not point right. It used a look rotation with y set to 0, which turns a 2D sprite edge-on when the target is left or right and cannot point up or down.
- Logging uses `MID_Logger` with `_logLevel`, default Error. The serialized `_enableLogs` and the two tick rate fields are gone, Unity drops the prefab values.

**Not changed:**

- The rotation smoothing uses the tick delta. At 0.1 s the factor `_rotationSpeed * deltaTime` reaches 1, so an arrow turns to its target in one step per tick. Per frame smoothing for the few visible arrows would cost an `Update`.
- The pools hold 10 arrows per type, an entity beyond that gets no arrow.

**Tests:** Not run in Unity. The arrow sprite was not seen, so check the orientation and set `_spriteAngleOffset` on the player prefab if it points the wrong way.

## `NetAiSummon.cs`

**What it does:** The AI of the minions of a player summon: the Hunter's minions and the flies of the Swarm (prefabs `NetAiBluePrint` and `Swarm_Fly_Ai`, pooled as `SummonMinion_Blueprint`). It sits on `NetAiBase`, in `BC_TestEnemyScripts`, and runs on the server. A minion attacks the enemies of its owner and follows the owner when there is none.

**Decisions:**

- The minions never ran. `NetAiBase` only updates while `_isActive` is true, and `ActivateAI` was only called by the survival spawn manager for survival enemies, so a minion stood still from its spawn to its despawn. `NetAiSummon` activates itself when it spawns on the server, and resets the state of its previous life, because the minions come from a pool.
- It could not have found a target either. It searched the scene for the tag `MainCharacter`, which no object in the project carries (players are tagged `Player`), and a tag that is not defined throws. Targets come from `IAmPlayerServiceLocator.All` now. An enemy is whatever `NetTeamRules.AreEnemies` says against the owner: the other teams, everyone but the owner in Free For All, nobody in Survival. The old team check was a plain comparison.
- A target is valid while its `NetHealthComponent` is neither dead nor spawning. The old check accepted a player only when its health handler was disabled.
- The melee attack hits every living enemy within `attackRange` of the minion, from the entity list. The old overlap query used the `enemyLayer` of the prefabs, which is layer 9, the teammate layer from the view of the local human, so no layer mask can express enemies. The `enemyLayer` field is gone.
- The damage request is sent in the name of the owner: sender is the owner, the victim is the id of the entity (it was the `NetworkObjectId`, which is not an entity id), the damage type comes from the bot flags, the kill is credited as `Killer` with 100 points like the Hunter, and the weapon is `ScoreSummon`. The server team gate applies as for any other damage.
- `SetOwner` is called before the spawn, where `IsServer` is not valid yet, so the write can be skipped. The owner id is taken from the locator of the owner when the minion spawns. `SetOwnerRefs` hands the locator over, `SetOwnerTransform` stays for old callers.
- The health handler returns a dead minion to the pool named by `SetPoolType`, and nobody set it for minions, so it went back to the pool of the default type. `NetAiSummon` sets `SummonMinion_Blueprint`. A minion whose lifetime ran out returns to the pool and despawns the same way, it called `Despawn(true)` before.
- A minion that follows its owner looks for enemies again every `targetSearchInterval`. Before, an owner target counted as valid and the search never ran again until the minion was close to the owner.

**Not changed:**

- `NetAiBase` runs `UpdateAI` in `FixedUpdate`, 50 times per second per entity, and its logging is on `MID_HelperFunctions` behind `_enableLogs`, which both minion prefabs store as true, so every attack is logged. It is shared with the survival enemies and is left for the survival enemy and boss pass.
- The projectile attack (`usesProjectiles`) instantiates a plain object that is not networked and carries no damage. Both minion prefabs use melee.
- `Utility` and `Defensive` minions only follow the owner. No prefab uses them.

**Tests:** Not run in Unity. Summon a Hunter and let it hit an enemy: the minions spawn, walk to the nearest enemy, hit it, the enemy loses health and the owner gets the kill. Swarm flies do the same. In Free For All they attack everyone but the owner, in Survival nobody. With no enemy they follow the owner. A dead minion and a minion whose lifetime ran out go back to the pool and can be summoned again.

## `INetworkDamagable.cs`

### Fixes

- The `get_DamagableState` getter returned itself, which recurses until the stack overflows if anything reads it. It reads and writes `n_DamagableState` now.

### Problems

- `TakeDamageServerRpc` takes the sender id and the bot flag from the caller and truncates the damage to an integer. It requires ownership, and the destructibles are server owned, so only server code (the projectile damage handler) reaches it.

## Bot lobby files

- `BotLobbyManager`: three async methods with `Task.Delay` (1.5 s and 2 s) in the fake lobby join, 9 `Debug.Log` calls, and an `Update` that drives fake lobby generation.
- `InLobbyBotUI` has 19 `Debug.Log` calls, most of them reference checks that run on every setup.
- `BotNamePool` has 13 `Debug.Log` calls. `BotNameGenerator` creates 38 lists and arrays and logs through `MID_HelperFunctions`.

## Prefab checks

Read in the second pass from `BotPlayer.prefab` and `Stickman_Base.prefab`:

- Bot root: layer 10, tag `Player`. `ClientNetTransform.authorityMode` is 1 (client, which for a server owned bot means the server). `TeamPlayer.m_PlayerTeam` defaults to 1 (`_BlueTeam`) and `TeamPlayer.n_IsBotPlayer` defaults to 0 until `SetIsBotServerRpc(true)` arrives. `TeamPlayer` now tells a bot from a human at spawn by the bot controller reference on the locator, which only the bot prefab has.
- The player prefab that the network manager and the spawner prefabs reference is `SuperiorPlayer.prefab`. `Stickman_Base.prefab` is referenced by nothing. `SuperiorPlayer` stores `m_PlayerTeam` 3 (`_BlackTeam`), `Stickman_Base` stores 0. Both store client authority with position sync on for `ClientNetTransform`.
- Layers: both human prefabs use 3 (main), 9 (teammate) and 10 (enemy). The bot prefab stores 10, 11 and 12 and a `_rayCastLayers` mask of 7, 10, 11 and 12.
- Tick rates: the serialized values on the bot prefab overrode the code, see `NetBotPlayer.cs`. `BotEffectsController` stores `Tick_2` and `Tick_0_1`, the power weapon blueprint stores `Tick_0_1`. Both are at or above the floor.
- The bot prefab has none of the PSD era components: `StickmanRigRagdoll`, `PlayerDamageFlash`, `DissolveEffectManager`, `PsdStickmanSkinApplier`. Bots keep the legacy skin path and the old networked ragdoll.
- Not read: the layer names (the project settings file did not parse), and whether an animator drives bot animation on clients.

## Open after the second pass

- Online only, waits until offline is done: `OnlineInGameRunner.ForceEndMatch` sets `_matchEnded` before `HandleMatchEnd`, which then returns at once (the offline runner already has the fix). The online team data (`TeamManagementSystem`) does not know bots, so online bots spawn at the Blue spawn first and take a balanced team afterwards. `AutoAssignBots` runs before any bot exists. Weekend Brawl (online, last team standing) uses limited respawns and no kill points by design.
- `TeamPlayer`: fixed, see its section. Open there: remote human players are never relocated by the server (the online items).
- Clairvoyance and Counter-Clairvoyance are wired and untested. The arrow orientation depends on the arrow sprite (`_spriteAngleOffset`).
- Scoring by design: Team Deathmatch scores one point per kill. Ignite Subjugation is capture the flag and scores through its objective. Weekend Brawl scores no kill points. Free For All ends at 30 kills.
- The initial spawn of players and bots (`DirectPlayerSpawner`, `TrySpawnBot`) uses the team spawn points, so Free For All starts on the Blue points. Respawns use the free-for-all points.
- Grenades and melee stay out of the projectile manager by decision. Bots never use melee.
- Audio: all game sounds go through `SttdFxManager` with a category, see `audio.md`. Open there: the catalog base volume and mixer group on the pooled path, a cheaper delivery for the per-shot `ClientRpc`, distance falloff, and the editor work.
- Bots move to the PSD parts after the loadout accepts the PSD part setup, see "Prefab checks".
- Logging still on `MID_HelperFunctions` behind `_enableLogs`: `NetTeamHandler`, `BaseGameModeHandler` (and with it `SurvivalModeHandler`), `PlayerRegistry`, the bot lobby files and the weapon extras.
- `NetPointsHandler.InitializeSummonPoints` replaces a `NetworkVariable` after `Awake`. If the replacement is created after Netcode collected the variables, summon points do not replicate. Needs a test with a client.
- The grenade explosion and the proximity mine use a reusable buffer and a three ray cover check, see `weapons.md`. The sat blocker query has no layer mask and still allocates.
- `NetAiBase`, `NetAiEnemy`, `NetAiHealthHandler` and the pathfinding module: logging on `MID_HelperFunctions` and the whole AI in `FixedUpdate`. Left for the survival enemy and boss pass, see `NetAiSummon.cs`. The projectile attack of `NetAiSummon` (`usesProjectiles`) is still a plain instance, no minion prefab uses it.

## `TeamPlayer.cs`

**What it does:** Team and match state of one player or bot, in `AC_AllScenes/NetCodeScenes/NetCodeScriptas/TeamPicker`. For a human, the server waits for the team handler, asks it for the team and registers the player for points. The local human then places itself (server only), starts the camera move from the match state, keeps the layers of all entities in line with its own view and keeps the HUD in sync. A bot has nothing to do at spawn, `NetBotPlayerHandler` sets its id, the bot flag and its team. Every entity, bot or human, tells the local human to re-layer when it spawns or changes team.

**Decisions:**

- A bot is told from a human at spawn by the bot controller reference on the locator, because only the bot prefab has one. `n_IsBotPlayer` and the bot id are set by the server after the spawn, so neither can be used at spawn. The prefab needs no change. A bot never runs the spawn sequence, so it no longer asks for a team for id 0 and no longer switches its position sync.
- One spawn coroutine for a human, on the server copy and on the owner copy. A pure observer of another human does nothing. Server: wait until `NetTeamHandler.IsInitialized` (30 s limit), send the team request once, register the player. Owner: wait until the team is known (5 s limit, logged as an error when it runs out), place the player (server only, because the spawn point depends on the team), find the camera, subscribe, start the match state handling and the HUD. The waits are per frame checks on a bool, no timers and no `Task`.
- The authority window (server authority, position sync off) opens at the start of the sequence and closes in a `finally`, on despawn and on disable. Server and owner copies keep the window. A pure observer used to flip it and flip it back in the same frame. The prefabs store client authority with position sync on, which is what the window restores.
- "Team known" means a change event arrived or `NetTeamHandler.HasTeamAssignment` says so. The team value alone cannot tell assigned from default: `SuperiorPlayer` stores team 3 (Black), and a change event does not fire when the assigned team equals the stored value.
- Layers: every `TeamPlayer` raises a static event on spawn and on each team change. The local human subscribes once its team is known and re-layers every entity of `IAmPlayerServiceLocator.All` on each event (a few comparisons, a layer is written only when it differs). The rule is `NetTeamRules.AreEnemies`: enemy layer for enemies, teammate layer for everyone else, main layer for itself. Free For All puts every other entity on the enemy layer, Survival puts all of them on the teammate layer, which matches the damage rules.
- The camera reference `m_PlayerFinder` is resolved at spawn for the owner and again in the sequence, because the weapon changer scales the camera through it as soon as a weapon is equipped. `CameraMove` is requested once per spawn.
- HUD: a `Tick_0_2` subscription of the local human. Kills, deaths and the displayed timer second are pushed only when they change. The start values of the team score bars come from `NetPointsHandler.RefreshTeamPointsHud`, once, in modes that use team points. The timer is hidden when the game manager says the timer is overridden. That is the original intent, it never worked because the game manager lookup returned null, so the Survival timer is hidden now.
- `SetIsBotServerRpc` accepts only the server. Its only caller is `NetBotPlayerHandler.ConfigureBotAfterSpawn`.
- Logging uses `MID_Logger` with `_logLevel`, default Error. The serialized `_enableLogs` and the unused `_isOnlineMode` are gone from the component, Unity drops the prefab values.
- Subscriptions live between spawn and despawn. Disabling the component stops coroutines without running them to the end, so enabling it again resumes a spawn sequence that did not finish.
- Removed: `ResetTeamPointsBasedOnGameMode` and its static flag (it reset nothing and failed without a `PlayerHudManager`), `UpdateTeamScores` (read and discarded), `InitalizeBotPlayerNetDictionaries`, `WaitForBotIdReady` and `RequestBotTeamAssignment` (never reached), the second registration call of the owner client (the server copy registers every human).

- `OnHumanTeamKnownServer` is a static event, raised on the server once a human has its team (the server copy waits for it, up to 5 s). The clairvoyance summons listen to it while they are alive, so a player who joins during a match gets the buff that applies to them.


**Fixed from the audit:** the authority mode that stayed switched after an exception, a despawn or a missing coordinator; the five `Task.Delay` waits; the dead bot branch; the layers of bots and players that spawn after the local player; `FindObjectsByType<TeamPlayer>`; `SetIsBotServerRpc` for any client; the HUD pushes that ran whether or not a value changed; the subscriptions that were not added again; the hidden errors.

**Tests:** Not run in Unity. Checked by reading: every external member against the source, and a syntax parse. Case table by reading: host in Team Deathmatch (request after the handler initializes, team known, placement, camera, layers, HUD), remote owner (waits for the replicated team), bot (event only), a team equal to the prefab default (known through `HasTeamAssignment`).

## Order of work

1. Done: player list kept by `IAmPlayerServiceLocator`, read by `NetBotPlayer`.
2. Done: stuck detection fix with a guard against overlapping recoveries.
3. Done: the async methods of `NetBotPlayer`, `NetBotPlayerHandler`, `NetRespawnHandler` and `BotAnimationController` as coroutines and tick delays.
4. Done: per frame work of `NetBotPlayer`, `BotAICommands` without allocations, the tunneling subscription and the effects state check. Open: the jetpack fuel `NetworkVariable` (`jumpTimeCounter`).
5. Done: logging in `NetDamageHandler`, `NetPointsHandler`, `NetHealthComponent`. Open: `BotMovementController`, `BotEffectsController` and the bot lobby files.
6. Done: the ownership decision for `DoDamageRequestServerRpc`, the server side team gate, bot recognition through `IsSpawnedBot` in the damage, respawn and points files, respawn request validation. Open: server computed melee and power weapon damage, the remaining number range copies.
7. Done (second pass): respawn trigger, team rules for Free For All and Survival, one point per kill, bot ticks and weapon loop, difficulty setup, line of sight, multikill window, RPC checks.
8. Done (third pass): all game audio through `SttdFxManager` with categories (guns, grenades, melee, dialogue, jetpack, bot movement), status effect deaths credit the owner, the boundary credits nobody, the Free For All handler with its kill limit, summons for Free For All, bot footsteps and slides on the audio catalogs, the old melee contact attack removed, the melee clone spawn pose and self collision.
9. Done (fourth pass): the `TeamPlayer` rewrite with `IsInitialized` on `NetTeamHandler` and `RefreshTeamPointsHud` on `NetPointsHandler`, the entity list in the indicator system and the clairvoyance behaviours, the Clairvoyance wiring with Counter-Clairvoyance, the grenade explosion refinement and the weapon swap sound.
10. Done (fifth pass): bot patrol points for every team, the repaired `NetAiSummon` with the Hunter and Swarm fixes, late join for the clairvoyance summons.
11. Done (sixth pass): the Turret and Bomber projectiles through `UnifiedProjectileManager`, the bot unique behaviour trigger.
12. Open: survival enemies and bosses, the online items above, bots on the PSD parts.

## Tests

Nothing from the second pass has been run in Unity. Checked outside Unity: a syntax parse of every changed file and a scan for duplicate members. These checks need a play session:

1. Kill a bot and a player in Team Deathmatch. Both come back after 3 s and 6 s, the team score goes up by one per kill.
2. Start Free For All. Players and bots damage each other, bots chase and shoot a human.
3. Start Survival. Players and bots do not damage each other, enemies take damage, nobody respawns through the handler.
4. Watch a bot of each difficulty. The top two tiers shoot a human who stands on layer 3.
5. Fall into a death boundary. The entity respawns, the death counts, nobody gets a kill.
6. Burn a bot with a grenade that leaves a burning effect. The thrower gets the kill when it dies.
7. Free For All with `_killLimit` 3: three kills by any player or bot end the match. A hunter and a turret attack everything except their owner.
8. Throw melee while flipped and while not flipped. Compare distance and direction. Walk bots past another machine and listen for footsteps.
9. Start any offline mode: the player gets its team, is placed on the spawn point of that team, the camera moves, and kills, deaths and the timer show on the HUD. In Survival the timer is hidden.
10. Free For All: bots and the human stand on the enemy layer from the first frame. Team Deathmatch: teammates on layer 9, enemies on layer 10. The team score bars start at the mode threshold.
11. Position sync after the spawn: the player moves normally once the match starts, also after a scene restart in the same session.
12. Clairvoyance summon: the arrows show for the owner and the team, teammates and enemies use their own prefab, the arrows point at the target in the 2D view (set `_spriteAngleOffset` on the player prefab if not), two summons keep the arrows on until the second ends, and they hide when the last ends.
13. Counter-Clairvoyance: in a team mode the enemy team loses its arrows while the summon lives and the owner's team keeps them. In Free For All every player except the owner loses them. They come back when the summon ends. In Survival nothing changes.
14. Late join: a second player who joins during a match while a Clairvoyance summon is alive sees the arrows, and a Counter-Clairvoyance that is alive switches off the arrows of an enemy who joins.
15. Patrol points: in Team Deathmatch a Blue bot goes to the Red spawns and a Red bot to the Blue spawns. In Free For All bots walk to the free-for-all points. In Survival they walk to the survival ground spawns. A bot of the Black team (online) walks to the points of the other teams in the match.
16. Hunter: hit a bot with the Hunter and let it explode. The bot is damaged and the host is not. Summon Swarm flies and Hunter minions, see the tests in `NetAiSummon.cs`.
17. Turret and Bomber: summon a turret, it shoots the nearest enemy and the owner gets the kill. Summon a bomber, it flies in a straight line and its bombs damage enemies, not the owner or the team. Check the direction of the bombs.
18. Bots: watch a master bot for a few minutes, it crouches, slides and throws grenades repeatedly and not only when the roll changes.
