// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/StickToTheDeath/stickman-parts.md, section "NetcodeWeaponCatigorizer.cs"
// ============================================================================
using System.Collections.Generic;
using UnityEngine;
using Unity.Netcode;
using System.Threading.Tasks;
using MidManStudio.Sttd.InGame.GameItemData;
using MidManStudio.Sttd.InGame.InGamePlayerDataStructures;
using System.Collections;
using MidManStudio.Core.Audio;
using MidManStudio.Core.Logging;
using MidManStudio.Sttd.InGame.StickmanParts;
using MidManStudio.Sttd.Vfx;

public class NetcodeWeaponCatigorizer : NetworkBehaviour
{
    #region Enums
    public enum WeaponSelected
    {
        primary,
        secondary,
        melee,
        powerWeapon,
        nullWeapon
    }
    #endregion

    #region Serialized Fields
    [Header("Individual Weapons")]
    [SerializeField] internal NetworkObject currentSelectedWeapon;
    [SerializeField] MID_WeaponSkins _currentSelectedWeaponsVisual;
    public NetworkObject primaryWeapon;
    public NetworkObject secondaryWeapon;
    public NetworkObject meleeWeapon;
    public NetworkObject powerWeapon;

    [Header("References")]
    [SerializeField] private IAmPlayerServiceLocator m_PlayerStuffRefrences;

    [Header("Events")]
    [SerializeField] private GameEvent onWeaponSwithed;

    [Header("Cooldown Settings")]
    [SerializeField] private float _meleeCooldownTime = 12f;

    [Header("Melee Settings")]
    [SerializeField] private float _meleeMaxCooldownTime = 12f;

    [Header("Power Weapon Settings")]
    [SerializeField] private int _powerWeaponMaxTimeBeforeCanUse = 30;
    [SerializeField] private int _powerWeaponTotalActiveTime = 10;

    [Header("Audio")]
    [SerializeField] private AudioId _weaponSwapSound = AudioId.WeaponSwap2;
    [SerializeField] private float _weaponSwapVolume = 1f;

    [Header("Debug Settings")]
    [SerializeField] private MID_LogLevel _logLevel = MID_LogLevel.Error;
    #endregion

    #region Network Variables
    [SerializeField] private NetworkVariable<WeaponSelected> n_WeaponTypeSelected = new NetworkVariable<WeaponSelected>(WeaponSelected.nullWeapon, NetworkVariableReadPermission.Everyone, NetworkVariableWritePermission.Server);
    [SerializeField] internal NetworkList<NetworkObjectReference> nl_AllWeaponsList;
    [SerializeField] private NetworkVariable<bool> n_MeleeOnCooldown = new NetworkVariable<bool>(false);
    [SerializeField] private NetworkVariable<int> n_PowerWeaponTimeBeforeCanUse = new NetworkVariable<int>(0);
    [SerializeField] private NetworkVariable<int> n_PowerWeaponActiveTime = new NetworkVariable<int>(0);
    [SerializeField] private NetworkVariable<bool> n_CanUsePowerWeapon = new NetworkVariable<bool>(true);
    [SerializeField] private NetworkVariable<bool> n_IsUsingPowerWeapon = new NetworkVariable<bool>(false);
    [SerializeField] private NetworkVariable<float> n_MeleeCooldownTime = new NetworkVariable<float>(0);
    #endregion

    #region Runtime State
    private static readonly WaitForSeconds OneSecond = new WaitForSeconds(1f);
    private static readonly WaitForSeconds QuickSwitchDelay = new WaitForSeconds(0.15f);

    private bool _isBotPrefab;
    private bool _cameraActionSubscribed;
    private bool _weaponActionsSubscribed;

    // A bot is told from a human by the bot controller on its prefab. The bot flags are only set by
    // the server after the spawn, so they cannot be used while the component spawns.
    private bool IsBotEntity => _isBotPrefab;
    private bool DebugOn => _logLevel >= MID_LogLevel.Debug;
    #endregion

    #region Properties
    internal MID_WeaponSkins get_CurrentSelectedWeaponsSkin
    {
        get { return _currentSelectedWeaponsVisual; }
        private set { _currentSelectedWeaponsVisual = value; }
    }
    internal WeaponSelected get_CurrentSelectedWeapon
    {
        get { return n_WeaponTypeSelected.Value; }
        private set { n_WeaponTypeSelected.Value = value; }
    }
    internal bool get_CanUsePowerWeapon
    {
        get { return n_CanUsePowerWeapon.Value; }
        private set { n_CanUsePowerWeapon.Value = value; }
    }
    internal bool get_CanUseMeleeWeapon
    {
        get { return !n_MeleeOnCooldown.Value; }
        private set { n_MeleeOnCooldown.Value = value; }
    }
    internal int get_PowerWeaponMaxTimeBeforeCanUse
    {
        get { return _powerWeaponMaxTimeBeforeCanUse; }
        set { _powerWeaponMaxTimeBeforeCanUse = value; }
    }

    internal int get_PowerWeaponTotalActiveTime
    {
        get { return _powerWeaponTotalActiveTime; }
        set { _powerWeaponTotalActiveTime = value; }
    }

    internal float get_MeleeMaxCooldownTime
    {
        get { return _meleeMaxCooldownTime; }
        set { _meleeMaxCooldownTime = value; }
    }
    #endregion

    #region Unity Lifecycle
    private void Awake()
    {
        nl_AllWeaponsList = new NetworkList<NetworkObjectReference>();
        if (m_PlayerStuffRefrences == null)
        {
            m_PlayerStuffRefrences = GetComponent<IAmPlayerServiceLocator>();
        }
        _isBotPrefab = m_PlayerStuffRefrences != null && m_PlayerStuffRefrences.get_NetworkBotPlayerHandler != null;
        _meleeCooldownTime = _meleeMaxCooldownTime;
    }

    public override void OnNetworkSpawn()
    {
        _cameraActionSubscribed = false;
        _weaponActionsSubscribed = false;
        nl_AllWeaponsList.ResetDirty();
        n_WeaponTypeSelected.OnValueChanged += OnWeaponChanged;

        // CRITICAL FIX: Only subscribe to HUD events if this is a REAL PLAYER (not a bot) AND we own it
        bool isRealPlayer = !IsBotEntity;
        bool weOwnThis = IsOwner;

        // Humans and bots: when the owner dies the weapons are turned off and the ammo is reset.
        // Nothing else resets the ammo of a bot.
        if (weOwnThis && m_PlayerStuffRefrences.get_PlayerHealthScript != null)
        {
            m_PlayerStuffRefrences.get_PlayerHealthScript.GetHealthComponent().OnHealthChanged += OnPlayerHealthChanged;
        }

        if (isRealPlayer && weOwnThis)
        {
            SubscribeCameraAction();

            n_CanUsePowerWeapon.OnValueChanged += OnCanUsePowerWeaponChanged;
            n_PowerWeaponActiveTime.OnValueChanged += OnPowerWeaponActiveTimeChanged;
            n_PowerWeaponTimeBeforeCanUse.OnValueChanged += OnPowerWeaponTimeBeforeCanUseChanged;
            n_MeleeCooldownTime.OnValueChanged += OnMeleeCooldownTimeChanged;
        }

        if (IsServer)
        {
            n_MeleeOnCooldown.Value = false;
            n_CanUsePowerWeapon.Value = true;
            n_PowerWeaponTimeBeforeCanUse.Value = get_PowerWeaponMaxTimeBeforeCanUse;
            n_PowerWeaponActiveTime.Value = _powerWeaponTotalActiveTime;
        }
        else if (isRealPlayer && weOwnThis)
        {
            ChangePowerWeaponTimeBeforeCanUseServerRpc(get_PowerWeaponMaxTimeBeforeCanUse);
            ChangePowerWeaponActiveTimeServerRpc(get_PowerWeaponTotalActiveTime);
        }
    }

    public override void OnNetworkDespawn()
    {
        n_WeaponTypeSelected.OnValueChanged -= OnWeaponChanged;

        bool isRealPlayer = !IsBotEntity;
        bool weOwnThis = IsOwner;

        if (weOwnThis && m_PlayerStuffRefrences.get_PlayerHealthScript != null)
        {
            m_PlayerStuffRefrences.get_PlayerHealthScript.GetHealthComponent().OnHealthChanged -= OnPlayerHealthChanged;
        }

        if (isRealPlayer && weOwnThis)
        {
            UnsubscribeHudActions();

            n_MeleeCooldownTime.OnValueChanged -= OnMeleeCooldownTimeChanged;
            n_CanUsePowerWeapon.OnValueChanged -= OnCanUsePowerWeaponChanged;
            n_PowerWeaponActiveTime.OnValueChanged -= OnPowerWeaponActiveTimeChanged;
            n_PowerWeaponTimeBeforeCanUse.OnValueChanged -= OnPowerWeaponTimeBeforeCanUseChanged;
        }
    }
    #endregion

    #region Network Value Changed Events

    /// <summary>
    /// CRITICAL FIX: On death, ONLY reset stats - DON'T return to pool
    /// Weapons only return to pool on match end/disconnect
    /// </summary>
    void OnPlayerHealthChanged(int oldValue, int newValue)
    {
        if (m_PlayerStuffRefrences.get_PlayerHealthScript.GetHealthComponent().GetCurrentHealth() <= 0)
        {
            TunOffAllWeapons();
            ResetWeaponStats(); // ONLY reset stats - no pool return

            if (IsOwner)
            {
                RequstDummyWeaponSpawn();
            }
        }
    }

    void OnWeaponChanged(WeaponSelected oldWeapon, WeaponSelected newWeapon)
    {
        UnDissolveCurrentWeapon();

        // Only do arm animation for real players who own this
        bool isRealPlayer = !IsBotEntity;
        bool weOwnThis = IsOwner;

        if (isRealPlayer && weOwnThis)
        {
            m_PlayerStuffRefrences.get_PlayerArmHandler.QuickSwitchWeapon();
            PlayWeaponSwapSound(oldWeapon, newWeapon);
        }

        SwitchToNewWeapon();
    }

    // Heard by the player who swaps. A change to or from "no weapon" is the quick switch after a respawn
    // or a loadout reload, it stays silent.
    private void PlayWeaponSwapSound(WeaponSelected oldWeapon, WeaponSelected newWeapon)
    {
        if (oldWeapon == WeaponSelected.nullWeapon || newWeapon == WeaponSelected.nullWeapon) return;

        SttdFxManager.PlaySound(_weaponSwapSound, AudioCategory.GunOther, transform.position, _weaponSwapVolume);
    }

    void OnCanUsePowerWeaponChanged(bool oldValue, bool newValue)
    {
        if (DebugOn) RunLog($"On Can use power weapon invoked with val {n_CanUsePowerWeapon.Value}", nameof(OnCanUsePowerWeaponChanged));

        // Only subscribe/unsubscribe for real players
        if (IsBotEntity) return;
        if (!IsOwner) return;

        if (n_CanUsePowerWeapon.Value == true)
        {
            if (PlayerHudManager.HasInstance && PlayerHudManager.Instance.isInitialized)
                PlayerHudManager.Instance.OnPowerWeaponAction += SwitchToPowerWeapon;
        }
        else
        {
            if (PlayerHudManager.HasInstance && PlayerHudManager.Instance.isInitialized)
                PlayerHudManager.Instance.OnPowerWeaponAction -= SwitchToPowerWeapon;
            StartCoroutine(CountUpToPowerWeaponReady());
        }
    }

    private void OnPowerWeaponActiveTimeChanged(int oldValue, int newValue)
    {
        if (powerWeapon == null) return;

        powerWeapon.TryGetComponent(out PowerWeaponHandler pwHandler);
        if (pwHandler == null) return;

        if (n_IsUsingPowerWeapon.Value && n_WeaponTypeSelected.Value == WeaponSelected.powerWeapon)
        {
            SetPowerWeaponTimerSlider(_powerWeaponTotalActiveTime, newValue);
            float normalizedValue = (float)newValue / _powerWeaponTotalActiveTime;
            SetPowerWeaponFxHolder(Quaternion.Euler(new Vector3(0f, 0f, -normalizedValue * 360f)));
        }
    }

    private void OnPowerWeaponTimeBeforeCanUseChanged(int oldValue, int newValue)
    {
        if (powerWeapon == null) return;

        powerWeapon.TryGetComponent(out PowerWeaponHandler pwHandler);
        if (pwHandler == null) return;

        if (!n_IsUsingPowerWeapon.Value)
        {
            SetPowerWeaponTimerSlider(_powerWeaponMaxTimeBeforeCanUse, newValue);
            float normalizedValue = (float)newValue / _powerWeaponMaxTimeBeforeCanUse;
            SetPowerWeaponFxHolder(Quaternion.Euler(new Vector3(0f, 0f, -normalizedValue * 360f)));
        }
    }

    void OnMeleeCooldownTimeChanged(float oldValue, float newValue)
    {
        if (!IsOwner) return;
        SetMeleeWeaponCooldownSlider(_meleeMaxCooldownTime, newValue);
    }
    #endregion

    #region Initialization
    internal async Task SetWeaponConfigs(List<CompactNetworkLoadoutItem> currentLoadoutItems)
    {
        if (!IsOwner) { return; }

        bool isBot = IsBotEntity;

        if (!isBot)
        {
            foreach (var item in currentLoadoutItems)
            {
                // Stickman parts are appearance only, there is no weapon to spawn for them
                if (item.ItemClassTypeIndex == StickmanLoadoutBridge.PART_TYPE_INDEX) continue;

                NetworkServerManeger.networkServerSingleton._eqItemSpawner.ReciveWeaponBluePrintSpawnRequestServerRpc(item.ItemClassTypeIndex, item);
            }
        }
        else
        {
            foreach (var item in currentLoadoutItems)
            {
                if (item.ItemClassTypeIndex == StickmanLoadoutBridge.PART_TYPE_INDEX) continue;

                NetworkServerManeger.networkServerSingleton._eqItemSpawner.ReciveBotWeaponBluePrintSpawnRequestServerRpc(item, m_PlayerStuffRefrences.NetworkObjectId, item.ItemClassTypeIndex);
            }
        }

        // Wait for weapons to spawn from pool
        await Task.Delay(1000);

        // Subscribe to HUD weapon switch events for REAL PLAYERS
        if (!isBot)
        {
            SubscribeWeaponActions();
            SubscribeCameraAction();
        }
    }

    internal void CallReInitializeAllWeapons()
    {
        ReInitializeAllWeapons();
    }

    void ReInitializeAllWeapons()
    {
        foreach (NetworkObjectReference Obj in nl_AllWeaponsList)
        {
            Obj.TryGet(out NetworkObject NetObj);
            NetObj.TryGetComponent(out WeaponTypeManeger weaponTypeManeger);

            switch (weaponTypeManeger.m_WeaponType)
            {
                case WeaponTypeManeger.WeaponType.PrimaryWeapon:
                case WeaponTypeManeger.WeaponType.SecondaryWeapon:
                    NetObj.TryGetComponent(out GeneralGunHandler generalGunScript);
                    if (generalGunScript == null) { return; }
                    generalGunScript.CallReInitializeWeaponScript();
                    break;

                case WeaponTypeManeger.WeaponType.MeleeWeapon:
                    NetObj.TryGetComponent(out MeleeWeaponHandler playerMeleeCombat);
                    if (playerMeleeCombat == null) { return; }
                    playerMeleeCombat.CallReInitializeWeaponScript();
                    break;

                case WeaponTypeManeger.WeaponType.PowerWeapon:
                    NetObj.TryGetComponent(out PowerWeaponHandler powerWeaponScript);
                    if (powerWeaponScript == null) { return; }
                    powerWeaponScript.CallReInitializeWeaponScript();
                    break;
            }
        }
    }

    public void InitializeAllWeaponRotations()
    {
        if (nl_AllWeaponsList == null || nl_AllWeaponsList.Count == 0) return;

        foreach (NetworkObjectReference weaponRef in nl_AllWeaponsList)
        {
            if (weaponRef.TryGet(out NetworkObject weaponObj))
            {
                if (weaponObj.TryGetComponent(out WeaponRotationAndFlipHandler rotationHandler))
                {
                    rotationHandler.InitializeWeaponRotation();
                    if (DebugOn) RunLog($"Initialized weapon rotation for: {weaponObj.name}", nameof(InitializeAllWeaponRotations));
                }
            }
        }
    }
    #endregion

    #region Weapon Switching
    private void SwitchToPrimaryWeapon()
    {
        // CRITICAL: Bots should never respond to HUD events
        if (IsBotEntity) return;

        if (n_WeaponTypeSelected.Value != WeaponSelected.primary && IsOwner && IsSpawned)
        {
            SendWeaponSwapRequestToServerRpc(0);
        }
    }

    private void SwitchToSecondaryWeapon()
    {
        // CRITICAL: Bots should never respond to HUD events
        if (IsBotEntity) return;

        if (n_WeaponTypeSelected.Value != WeaponSelected.secondary && IsOwner && IsSpawned)
        {
            SendWeaponSwapRequestToServerRpc(1);
        }
    }

    private void SwitchToMeleeWeapon()
    {
        // CRITICAL: Bots should never respond to HUD events
        if (IsBotEntity) return;

        if (n_WeaponTypeSelected.Value != WeaponSelected.melee && IsOwner && IsSpawned)
        {
            SendWeaponSwapRequestToServerRpc(2);
        }
    }

    private void SwitchToPowerWeapon()
    {
        // CRITICAL: Bots should never respond to HUD events
        if (IsBotEntity) return;

        if (n_WeaponTypeSelected.Value != WeaponSelected.powerWeapon && IsOwner && IsSpawned)
        {
            nl_AllWeaponsList[3].TryGet(out NetworkObject weapon3);
            currentSelectedWeapon = weapon3;

            weapon3.TryGetComponent(out PowerWeaponHandler powerWeaponScript);

            SendWeaponSwapRequestToServerRpc(3);
            StartCoroutine(CountDownActiveTime());
            if (powerWeaponScript == null) { return; }
            powerWeaponScript.TurnOnPowerWeaponFromCategorizer();

            if (PlayerHudManager.HasInstance && PlayerHudManager.Instance.isInitialized)
                PlayerHudManager.Instance.OnPowerWeaponAction -= SwitchToPowerWeapon;
        }
    }

    [ServerRpc]
    public void SendWeaponSwapRequestToServerRpc(int index)
    {
        switch (index)
        {
            case 0:
                n_WeaponTypeSelected.Value = WeaponSelected.primary;
                break;
            case 1:
                n_WeaponTypeSelected.Value = WeaponSelected.secondary;
                break;
            case 2:
                n_WeaponTypeSelected.Value = WeaponSelected.melee;
                break;
            case 3:
                n_WeaponTypeSelected.Value = WeaponSelected.powerWeapon;
                break;
            case 4:
                n_WeaponTypeSelected.Value = WeaponSelected.nullWeapon;
                break;
        }
    }

    public void SwitchToNewWeapon()
    {
        if (nl_AllWeaponsList.Count > 0)
        {
            TunOffAllWeapons();

            switch (n_WeaponTypeSelected.Value)
            {
                case WeaponSelected.nullWeapon:
                    TunOffAllWeapons();
                    if (!IsOwner || IsBotEntity) return;
                    if (PlayerHudManager.HasInstance)
                    {
                        PlayerHudManager.Instance.get_AimJoystick.SetAimThreshold(0.5f);
                    }
                    break;

                case WeaponSelected.primary:
                    HandlePrimaryWeaponSwitch();
                    if (!IsOwner || IsBotEntity) return;
                    if (PlayerHudManager.HasInstance)
                    {
                        PlayerHudManager.Instance.get_AimJoystick.SetAimThreshold(0.1f);
                    }
                    break;

                case WeaponSelected.secondary:
                    HandleSecondaryWeaponSwitch();
                    if (!IsOwner || IsBotEntity) return;
                    if (PlayerHudManager.HasInstance)
                    {
                        PlayerHudManager.Instance.get_AimJoystick.SetAimThreshold(0.1f);
                    }
                    break;

                case WeaponSelected.melee:
                    HandleMeleeWeaponSwitch();
                    if (!IsOwner || IsBotEntity) return;
                    if (PlayerHudManager.HasInstance)
                    {
                        PlayerHudManager.Instance.get_AimJoystick.SetAimThreshold(0.8f);
                    }
                    break;

                case WeaponSelected.powerWeapon:
                    HandlePowerWeaponSwitch();
                    if (!IsOwner || IsBotEntity) return;
                    if (PlayerHudManager.HasInstance)
                    {
                        PlayerHudManager.Instance.get_AimJoystick.SetAimThreshold(0.1f);
                    }
                    break;
            }
        }
    }

    private void HandlePrimaryWeaponSwitch()
    {
        nl_AllWeaponsList[0].TryGet(out NetworkObject weapon);
        currentSelectedWeapon = weapon;

        if (nl_AllWeaponsList.Contains(weapon))
        {
            var primaryWeaponRefrences = weapon.GetComponent<IAmWeaponRefs>();
            primaryWeaponRefrences.SpriteRenderer.enabled = true;
            if (primaryWeaponRefrences.ExtraComponents != null)
            {
                primaryWeaponRefrences.ExtraComponents.SetActive(true);
            }
            primaryWeaponRefrences.EnableWeapon();
        }

        weapon.TryGetComponent(out WeaponRotationAndFlipHandler weaponRotation);
        weapon.TryGetComponent(out GeneralGunHandler baseWeaponScript);
        weapon.TryGetComponent(out WeaponSwapHandler baseWeaponTPD);

        if (baseWeaponScript == null) { return; }
        _currentSelectedWeaponsVisual = baseWeaponScript.get_WeaponConfigSo.get_WeaponVisuals[0];
        baseWeaponScript.ZeroOutAndUnDissolve();
        baseWeaponScript.ForceSetActive();
        // Only update HUD/Camera for real players
        if (IsOwner && !IsBotEntity)
        {
            if (PlayerHudManager.Instance != null && PlayerHudManager.Instance.isInitialized)
            {
                PlayerHudManager.Instance.UpdateOrtoScale(baseWeaponScript.currentOrtoScale);
            }
            m_PlayerStuffRefrences.get_PlayerTeamHandler.m_PlayerFinder.ChangeOrtoScale(baseWeaponScript.currentOrtoScale);
            m_PlayerStuffRefrences.get_PlayerController.SetPlayerMass(baseWeaponScript.get_WeaponConfigSo.get_EqItemWaight);

            baseWeaponScript.UpdateAmmoUIImmediate();
            baseWeaponScript.UpdateReloadButtonImmediate();
        }
    }

    private void HandleSecondaryWeaponSwitch()
    {
        nl_AllWeaponsList[1].TryGet(out NetworkObject weapon1);
        currentSelectedWeapon = weapon1;

        if (nl_AllWeaponsList.Contains(weapon1))
        {
            var secondaryWeaponRefrences = weapon1.GetComponent<IAmWeaponRefs>();
            secondaryWeaponRefrences.SpriteRenderer.enabled = true;
            if (secondaryWeaponRefrences.ExtraComponents != null)
            {
                secondaryWeaponRefrences.ExtraComponents.SetActive(true);
            }
            secondaryWeaponRefrences.EnableWeapon();
        }

        weapon1.TryGetComponent(out WeaponRotationAndFlipHandler weaponRotation);
        weapon1.TryGetComponent(out GeneralGunHandler secondaryWeaponScript);
        weapon1.TryGetComponent(out WeaponSwapHandler secondaryWeaponTPD);

        if (secondaryWeaponScript == null) { return; }
        _currentSelectedWeaponsVisual = secondaryWeaponScript.get_WeaponConfigSo.get_WeaponVisuals[0];
        secondaryWeaponScript.ZeroOutAndUnDissolve();
        secondaryWeaponScript.ForceSetActive();
        if (IsOwner && !IsBotEntity)
        {
            if (PlayerHudManager.Instance != null && PlayerHudManager.Instance.isInitialized)
            {
                PlayerHudManager.Instance.UpdateOrtoScale(secondaryWeaponScript.currentOrtoScale);
            }
            m_PlayerStuffRefrences.get_PlayerTeamHandler.m_PlayerFinder.ChangeOrtoScale(secondaryWeaponScript.currentOrtoScale);
            m_PlayerStuffRefrences.get_PlayerController.SetPlayerMass(secondaryWeaponScript.get_WeaponConfigSo.get_EqItemWaight);

            secondaryWeaponScript.UpdateAmmoUIImmediate();
            secondaryWeaponScript.UpdateReloadButtonImmediate();
        }
    }

    private void HandleMeleeWeaponSwitch()
    {
        nl_AllWeaponsList[2].TryGet(out NetworkObject weapon2);
        currentSelectedWeapon = weapon2;

        if (nl_AllWeaponsList.Contains(weapon2))
        {
            var meleeWeaponRefrences = weapon2.GetComponent<IAmWeaponRefs>();
            meleeWeaponRefrences.SpriteRenderer.enabled = true;
            if (meleeWeaponRefrences.ExtraComponents != null)
            {
                meleeWeaponRefrences.ExtraComponents.SetActive(true);
            }
            meleeWeaponRefrences.EnableWeapon();
        }

        weapon2.TryGetComponent(out WeaponRotationAndFlipHandler weaponRotation);
        weapon2.TryGetComponent(out MeleeWeaponHandler meleeWeaponScript);
        weapon2.TryGetComponent(out WeaponSwapHandler meleeWeaponTPD);

        if (meleeWeaponScript == null) { return; }
        _currentSelectedWeaponsVisual = meleeWeaponScript.get_WeaponConfigSo.get_WeaponVisuals[0];
        meleeWeaponScript.ZeroOutAndUnDissolve();
        meleeWeaponScript.ForceSetActive();
        if (IsOwner && !IsBotEntity)
        {
            if (PlayerHudManager.Instance != null && PlayerHudManager.Instance.isInitialized)
            {
                PlayerHudManager.Instance.UpdateOrtoScale(meleeWeaponScript.currentOrtoScale);
            }
            m_PlayerStuffRefrences.get_PlayerTeamHandler.m_PlayerFinder.ChangeOrtoScale(meleeWeaponScript.currentOrtoScale);
            m_PlayerStuffRefrences.get_PlayerController.SetPlayerMass(meleeWeaponScript.get_WeaponConfigSo.get_EqItemWaight);
            meleeWeaponScript.UpdateAmmoUIImmediate();
        }
    }

    private void HandlePowerWeaponSwitch()
    {
        nl_AllWeaponsList[3].TryGet(out NetworkObject weapon3);
        currentSelectedWeapon = weapon3;

        if (nl_AllWeaponsList.Contains(weapon3))
        {
            var powerWeaponRefrences = weapon3.GetComponent<IAmWeaponRefs>();
            powerWeaponRefrences.SpriteRenderer.enabled = true;
            if (powerWeaponRefrences.ExtraComponents != null)
            {
                powerWeaponRefrences.ExtraComponents.SetActive(true);
            }
            powerWeaponRefrences.EnableWeapon();
        }

        weapon3.TryGetComponent(out WeaponRotationAndFlipHandler weaponRotation);
        weapon3.TryGetComponent(out PowerWeaponHandler powerWeaponScript);
        weapon3.TryGetComponent(out WeaponSwapHandler powerWeaponTPD);

        if (powerWeaponScript == null) { return; }
        _currentSelectedWeaponsVisual = powerWeaponScript.get_WeaponConfigSo.get_WeaponVisuals[0];
        powerWeaponScript.ZeroOutAndUnDissolve();

        if (IsOwner && !IsBotEntity)
        {
            if (PlayerHudManager.Instance != null && PlayerHudManager.Instance.isInitialized)
            {
                PlayerHudManager.Instance.UpdateOrtoScale(powerWeaponScript.currentOrtoScale);
            }
            m_PlayerStuffRefrences.get_PlayerTeamHandler.m_PlayerFinder.ChangeOrtoScale(powerWeaponScript.currentOrtoScale);
            m_PlayerStuffRefrences.get_PlayerController.SetPlayerMass(powerWeaponScript.get_WeaponConfigSo.get_EqItemWaight);
            powerWeaponScript.UpdateAmmoUIImmediate();
        }

        if (!powerWeaponTPD) { return; }
    }

    public void TunOffAllWeapons()
    {
        foreach (NetworkObjectReference reference in nl_AllWeaponsList)
        {
            reference.TryGet(out NetworkObject weapon);
            var WeaponRefrences = weapon.GetComponent<IAmWeaponRefs>();
            WeaponRefrences.SpriteRenderer.enabled = false;
            if (WeaponRefrences.ExtraComponents != null)
            {
                WeaponRefrences.ExtraComponents.SetActive(false);
            }
            WeaponRefrences.DisableWeapon();
        }
    }

    void UnDissolveCurrentWeapon()
    {
        if (nl_AllWeaponsList.Count > 0)
        {
            switch (n_WeaponTypeSelected.Value)
            {
                case WeaponSelected.nullWeapon:
                    break;

                case WeaponSelected.primary:
                    nl_AllWeaponsList[0].TryGet(out NetworkObject weapon);
                    weapon.TryGetComponent(out GeneralGunHandler baseWeaponScript);
                    if (!baseWeaponScript) { return; }
                    baseWeaponScript.SwitchToDissolve();
                    baseWeaponScript.ZeroOutAndUnDissolve();
                    break;

                case WeaponSelected.secondary:
                    nl_AllWeaponsList[1].TryGet(out NetworkObject weapon1);
                    weapon1.TryGetComponent(out GeneralGunHandler secondaryWeaponScript);
                    if (!secondaryWeaponScript) { return; }
                    secondaryWeaponScript.SwitchToDissolve();
                    secondaryWeaponScript.ZeroOutAndUnDissolve();
                    break;

                case WeaponSelected.melee:
                    nl_AllWeaponsList[2].TryGet(out NetworkObject weapon2);
                    weapon2.TryGetComponent(out MeleeWeaponHandler meleeWeaponScript);
                    if (!meleeWeaponScript) { return; }
                    meleeWeaponScript.ZeroOutAndUnDissolve();
                    break;

                case WeaponSelected.powerWeapon:
                    nl_AllWeaponsList[3].TryGet(out NetworkObject weapon3);
                    weapon3.TryGetComponent(out PowerWeaponHandler powerWeaponScript);
                    powerWeaponScript.ZeroOutAndUnDissolve();
                    break;
            }
        }
    }

    public void CallQuickSwitch()
    {
        if (!IsOwner) { return; }

        // A coroutine cannot start on an inactive object, send at once then
        if (!isActiveAndEnabled)
        {
            SendWeaponSwapRequestToServerRpc(4);
            SendWeaponSwapRequestToServerRpc(0);
            return;
        }

        StartCoroutine(QuickSwitchWeapons());
    }

    IEnumerator QuickSwitchWeapons()
    {
        yield return QuickSwitchDelay;
        SendWeaponSwapRequestToServerRpc(4);
        SendWeaponSwapRequestToServerRpc(0);
    }

    public void ReEnableCurrentWeapon()
    {
        TunOffAllWeapons();
        SwitchToNewWeapon();
    }
    #endregion

    #region HUD Subscriptions
    // The HUD actions are subscribed once per spawn, the loadout is applied more than once.
    private void SubscribeCameraAction()
    {
        if (_cameraActionSubscribed) return;
        if (!PlayerHudManager.HasInstance || !PlayerHudManager.Instance.isInitialized) return;

        PlayerHudManager.Instance.OnCameraOrtoAction += ChangeOrtoScale;
        _cameraActionSubscribed = true;
    }

    private void SubscribeWeaponActions()
    {
        if (_weaponActionsSubscribed) return;
        if (!PlayerHudManager.HasInstance || !PlayerHudManager.Instance.isInitialized) return;

        PlayerHudManager.Instance.OnPrimaryWeaponAction += SwitchToPrimaryWeapon;
        PlayerHudManager.Instance.OnSecondaryWeaponAction += SwitchToSecondaryWeapon;
        PlayerHudManager.Instance.OnMeleeWeaponAction += SwitchToMeleeWeapon;
        _weaponActionsSubscribed = true;
    }

    private void UnsubscribeHudActions()
    {
        if (!PlayerHudManager.HasInstance) return;

        if (_cameraActionSubscribed)
        {
            PlayerHudManager.Instance.OnCameraOrtoAction -= ChangeOrtoScale;
            _cameraActionSubscribed = false;
        }

        if (_weaponActionsSubscribed)
        {
            PlayerHudManager.Instance.OnPrimaryWeaponAction -= SwitchToPrimaryWeapon;
            PlayerHudManager.Instance.OnSecondaryWeaponAction -= SwitchToSecondaryWeapon;
            PlayerHudManager.Instance.OnMeleeWeaponAction -= SwitchToMeleeWeapon;
            _weaponActionsSubscribed = false;
        }
    }
    #endregion

    #region Weapon Utility Functions
    void RequstDummyWeaponSpawn()
    {
        // Implementation
    }

    void ChangeOrtoScale()
    {
        // CRITICAL: Bots have no HUD, this should never be called for them
        if (IsBotEntity) { return; }

        currentSelectedWeapon.TryGetComponent(out WeaponTypeManeger weaponType);

        switch (weaponType.m_WeaponType)
        {
            case WeaponTypeManeger.WeaponType.PrimaryWeapon or WeaponTypeManeger.WeaponType.SecondaryWeapon:
                currentSelectedWeapon.TryGetComponent(out GeneralGunHandler weaponScript);
                weaponScript.ortoScaleIndex = (byte)(weaponScript.ortoScaleIndex + 1);
                if (weaponScript.ortoScaleIndex >= weaponScript.get_WeaponConfigSo.get_EqItemOrtoScales.Count)
                {
                    weaponScript.ortoScaleIndex = 0;
                }
                weaponScript.currentOrtoScale = weaponScript.get_WeaponConfigSo.get_EqItemOrtoScales[weaponScript.ortoScaleIndex];
                if (PlayerHudManager.Instance != null && PlayerHudManager.Instance.isInitialized)
                {
                    PlayerHudManager.Instance.UpdateOrtoScale(weaponScript.currentOrtoScale);
                }
                m_PlayerStuffRefrences.get_PlayerTeamHandler.m_PlayerFinder.ChangeOrtoScale(weaponScript.currentOrtoScale);
                break;

            case WeaponTypeManeger.WeaponType.MeleeWeapon:
                currentSelectedWeapon.TryGetComponent(out MeleeWeaponHandler meleeScript);
                meleeScript.ortoScaleIndex = (byte)(meleeScript.ortoScaleIndex + 1);
                if (meleeScript.ortoScaleIndex >= meleeScript.get_WeaponConfigSo.get_EqItemOrtoScales.Count)
                {
                    meleeScript.ortoScaleIndex = 0;
                }
                meleeScript.currentOrtoScale = meleeScript.get_WeaponConfigSo.get_EqItemOrtoScales[meleeScript.ortoScaleIndex];
                if (PlayerHudManager.Instance != null && PlayerHudManager.Instance.isInitialized)
                {
                    PlayerHudManager.Instance.UpdateOrtoScale(meleeScript.currentOrtoScale);
                }
                m_PlayerStuffRefrences.get_PlayerTeamHandler.m_PlayerFinder.ChangeOrtoScale(meleeScript.currentOrtoScale);
                break;

            case WeaponTypeManeger.WeaponType.PowerWeapon:
                currentSelectedWeapon.TryGetComponent(out PowerWeaponHandler powerWeaponScript);
                powerWeaponScript.ortoScaleIndex = (byte)(powerWeaponScript.ortoScaleIndex + 1);
                if (powerWeaponScript.ortoScaleIndex >= powerWeaponScript.get_WeaponConfigSo.get_EqItemOrtoScales.Count)
                {
                    powerWeaponScript.ortoScaleIndex = 0;
                }
                powerWeaponScript.currentOrtoScale = powerWeaponScript.get_WeaponConfigSo.get_EqItemOrtoScales[powerWeaponScript.ortoScaleIndex];
                if (PlayerHudManager.Instance != null && PlayerHudManager.Instance.isInitialized)
                {
                    PlayerHudManager.Instance.UpdateOrtoScale(powerWeaponScript.currentOrtoScale);
                }
                m_PlayerStuffRefrences.get_PlayerTeamHandler.m_PlayerFinder.ChangeOrtoScale(powerWeaponScript.currentOrtoScale);
                break;
        }
    }

    void ResetWeaponStats()
    {
        if (nl_AllWeaponsList.Count < 2) return;

        nl_AllWeaponsList[0].TryGet(out NetworkObject weapon1);
        if (weapon1 != null)
        {
            weapon1.TryGetComponent(out GeneralGunHandler weaponScript1);
            weaponScript1?.RestetAllStats();
        }

        nl_AllWeaponsList[1].TryGet(out NetworkObject weapon2);
        if (weapon2 != null)
        {
            weapon2.TryGetComponent(out GeneralGunHandler weaponScript2);
            weaponScript2?.RestetAllStats();
        }
    }
    #endregion

    #region Cooldown Management
    public void StartMeleeCooldown()
    {
        RunLog($"Called start melee cooldown", nameof(StartMeleeCooldown));

        if (IsServer)
        {
            n_MeleeOnCooldown.Value = true;
            _meleeCooldownTime = _meleeMaxCooldownTime;
            n_MeleeCooldownTime.Value = _meleeMaxCooldownTime;
        }
        else
        {
            SetMeleeCooldownServerRpc(true);
            _meleeCooldownTime = _meleeMaxCooldownTime;
            SetMeleeCooldownTimeServerRpc(_meleeMaxCooldownTime);
        }
        StartCoroutine(MeleeCooldownCoroutine());
    }

    public void StartPowerWeaponCooldown(int timeBefoCanUse, int totalActiveTime)
    {
        if (!IsOwner) return;
        RunLog($"Called Start Power weapon cooldown", nameof(StartPowerWeaponCooldown));

        if (IsServer)
        {
            n_PowerWeaponTimeBeforeCanUse.Value = 0;
            n_PowerWeaponActiveTime.Value = totalActiveTime;
            n_CanUsePowerWeapon.Value = false;
            RunLog($"Changed can use powerweapon to false", nameof(StartPowerWeaponCooldown));
        }
        else
        {
            ChangePowerWeaponTimeBeforeCanUseServerRpc(0);
            ChangePowerWeaponActiveTimeServerRpc(totalActiveTime);
            ChangeCanUsePowerWeaponServerRpc(false);
        }
    }

    public void StartPowerWeaponActiveCountdown()
    {
        StartCoroutine(CountDownActiveTime());
    }

    public void ForceStopPowerWeapon()
    {
        SwitchToPrimaryWeapon();
        if (IsServer)
        {
            n_PowerWeaponActiveTime.Value = 0;
            n_PowerWeaponTimeBeforeCanUse.Value = 0;
            n_CanUsePowerWeapon.Value = false;
            n_IsUsingPowerWeapon.Value = false;
        }
        else
        {
            ChangePowerWeaponActiveTimeServerRpc(0);
            ChangePowerWeaponTimeBeforeCanUseServerRpc(0);
            ChangeCanUsePowerWeaponServerRpc(false);
            ChangeIsUsingPowerWeaponServerRpc(false);
        }

        StartCoroutine(CountUpToPowerWeaponReady());
    }
    #endregion

    #region Coroutines
    IEnumerator CountUpToPowerWeaponReady()
    {
        if (!IsOwner) yield break;

        if (IsServer)
        {
            n_PowerWeaponActiveTime.Value = _powerWeaponTotalActiveTime;
            while (n_PowerWeaponTimeBeforeCanUse.Value < _powerWeaponMaxTimeBeforeCanUse)
            {
                yield return OneSecond;
                n_PowerWeaponTimeBeforeCanUse.Value += 1;
            }
            n_CanUsePowerWeapon.Value = true;
        }
        else
        {
            ChangePowerWeaponActiveTimeServerRpc(_powerWeaponTotalActiveTime);
            while (n_PowerWeaponTimeBeforeCanUse.Value < _powerWeaponMaxTimeBeforeCanUse)
            {
                yield return OneSecond;
                IncreasePowerWeaponTimeBeforeCanUseServerRpc();
            }
            ChangeCanUsePowerWeaponServerRpc(true);
        }
    }

    IEnumerator CountDownActiveTime()
    {
        if (!IsOwner) yield break;

        if (IsServer)
        {
            n_PowerWeaponTimeBeforeCanUse.Value = 0;
            while (n_PowerWeaponActiveTime.Value > 0 && n_WeaponTypeSelected.Value == WeaponSelected.powerWeapon)
            {
                yield return OneSecond;
                n_PowerWeaponActiveTime.Value -= 1;
            }
            n_CanUsePowerWeapon.Value = false;
        }
        else
        {
            ChangePowerWeaponTimeBeforeCanUseServerRpc(0);
            while (n_PowerWeaponActiveTime.Value > 0 && n_WeaponTypeSelected.Value == WeaponSelected.powerWeapon)
            {
                yield return OneSecond;
                DecreasePowerWeaponActiveTimeServerRpc();
            }
            ChangeCanUsePowerWeaponServerRpc(false);
        }
    }

    private IEnumerator MeleeCooldownCoroutine()
    {
        RunLog($"Starting melee cool down coroutine", nameof(MeleeCooldownCoroutine));

        if (IsServer)
        {
            while (n_MeleeCooldownTime.Value > 0)
            {
                yield return OneSecond;
                _meleeCooldownTime -= 1;
                n_MeleeCooldownTime.Value -= 1;
                if (DebugOn) RunLog($"Melee cool down val {n_MeleeCooldownTime.Value}", nameof(MeleeCooldownCoroutine));
            }
            n_MeleeOnCooldown.Value = false;
            n_MeleeCooldownTime.Value = 0;
            _meleeCooldownTime = 0;
        }
        else
        {
            while (n_MeleeCooldownTime.Value > 0)
            {
                yield return OneSecond;
                _meleeCooldownTime -= 1;
                DecreaseMeleeCooldownTimeServerRpc();
            }
            SetMeleeCooldownServerRpc(false);
            SetMeleeCooldownTimeServerRpc(0);
        }
    }
    #endregion

    #region UI Updates
    public void BoostPowerWeaponCooldown(int pointsEarned)
    {
        if (!IsOwner) return;
        if (IsBotEntity) return;

        int boostAmount = Mathf.Min(pointsEarned / 100, 5);

        if (IsServer)
        {
            int newTime = Mathf.Min(n_PowerWeaponTimeBeforeCanUse.Value + boostAmount,
                                   _powerWeaponMaxTimeBeforeCanUse);
            n_PowerWeaponTimeBeforeCanUse.Value = newTime;
        }
        else
        {
            BoostPowerWeaponCooldownServerRpc(boostAmount);
        }
    }

    private void SetPowerWeaponTimerSlider(float max, float increment)
    {
        if (IsBotEntity) return;
        if (!IsOwner) return;

        if (PlayerHudManager.HasInstance && PlayerHudManager.Instance.isInitialized)
        {
            string weaponType = "PowerWeapon";
            PlayerHudManager.Instance.UpdateWeaponSlider(max, increment, weaponType);
        }
    }

    private void SetPowerWeaponFxHolder(Quaternion quaternion)
    {
        if (IsBotEntity) return;
        if (!IsOwner) return;

        if (PlayerHudManager.HasInstance && PlayerHudManager.Instance.isInitialized)
        {
            PlayerHudManager.Instance.UpdatePowerWeaponFxHolder(quaternion);
        }
    }

    private void SetMeleeWeaponCooldownSlider(float max, float increment)
    {
        if (IsBotEntity) return;
        if (!IsOwner) return;

        if (PlayerHudManager.HasInstance && PlayerHudManager.Instance.isInitialized)
        {
            string weaponType = "MeleeWeapon";
            PlayerHudManager.Instance.UpdateWeaponSlider(max, increment, weaponType);
        }
    }
    #endregion

    #region Server RPCs
    [ServerRpc]
    private void SetMeleeCooldownServerRpc(bool v)
    {
        n_MeleeOnCooldown.Value = v;
    }

    [ServerRpc]
    void ChangePowerWeaponTimeBeforeCanUseServerRpc(int value)
    {
        n_PowerWeaponTimeBeforeCanUse.Value = value;
    }

    [ServerRpc]
    void IncreasePowerWeaponTimeBeforeCanUseServerRpc()
    {
        n_PowerWeaponTimeBeforeCanUse.Value += 1;
    }

    [ServerRpc]
    void ChangePowerWeaponActiveTimeServerRpc(int value)
    {
        n_PowerWeaponActiveTime.Value = value;
    }

    [ServerRpc]
    void DecreasePowerWeaponActiveTimeServerRpc()
    {
        n_PowerWeaponActiveTime.Value -= 1;
    }

    [ServerRpc]
    void ChangeCanUsePowerWeaponServerRpc(bool value)
    {
        n_CanUsePowerWeapon.Value = value;
    }

    [ServerRpc]
    private void SetMeleeCooldownTimeServerRpc(float value)
    {
        n_MeleeCooldownTime.Value = value;
    }

    [ServerRpc]
    private void DecreaseMeleeCooldownTimeServerRpc()
    {
        n_MeleeCooldownTime.Value -= 1;
    }

    [ServerRpc]
    void BoostPowerWeaponCooldownServerRpc(int boostAmount)
    {
        int newTime = Mathf.Min(n_PowerWeaponTimeBeforeCanUse.Value + boostAmount,
                               _powerWeaponMaxTimeBeforeCanUse);
        n_PowerWeaponTimeBeforeCanUse.Value = newTime;
    }

    [ServerRpc]
    void ChangeIsUsingPowerWeaponServerRpc(bool value)
    {
        n_IsUsingPowerWeapon.Value = value;
    }
    #endregion

    #region Logging Helper Methods
    private void RunLog(string message, string methodName = "") =>
        MID_Logger.LogDebug(_logLevel, message, nameof(NetcodeWeaponCatigorizer), methodName);

    private void RunLogWarning(string message, string methodName = "") =>
        MID_Logger.LogWarning(MID_LogLevel.Info, message, nameof(NetcodeWeaponCatigorizer), methodName);

    private void RunLogError(string message, string methodName = "", System.Exception e = null) =>
        MID_Logger.LogError(MID_LogLevel.Info, message, nameof(NetcodeWeaponCatigorizer), methodName, e);
    #endregion
}
