// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/StickToTheDeath/bots.md, section "TeamPlayer.cs"
// ============================================================================
using System.Collections;
using UnityEngine;
using Unity.Netcode;
using MidManStudio.Core.Logging;
using MidManStudio.Core.TickDispatcher;
using MidManStudio.InGame.SharedSetup;
using MidManStudio.Sttd.InGame.GameItemData;
using MidManStudio.Sttd.InGame.Setup;

/// <summary>
/// Team and match state of one player or bot.
/// A human: the server asks the team handler for the team and registers the player for points,
/// the local player positions itself, follows the match timer for the camera and keeps the HUD
/// in sync. A bot has nothing to do at spawn, NetBotPlayerHandler sets its id, flag and team.
/// Every entity tells the local human to refresh the layers when it spawns or changes team.
/// </summary>
public class TeamPlayer : NetworkBehaviour
{
    #region Configuration
    [Header("Debug Settings")]
    [SerializeField] private MID_LogLevel _logLevel = MID_LogLevel.Error;

    [Header("Network Variables")]
    public NetworkVariable<bool> n_IsBotPlayer = new NetworkVariable<bool>();
    public NetworkVariable<PlayerTeam> m_PlayerTeam = new NetworkVariable<PlayerTeam>();

    [Header("References")]
    [SerializeField] IAmPlayerServiceLocator m_PlayerStuffRefrence;
    [SerializeField] internal CinemachinePlayerFind m_PlayerFinder;

    [Header("Layers (local player's view)")]
    [SerializeField] int _mainPlayerLayer = 3;
    [SerializeField] int _teammatePlayerLayer = 9;
    [SerializeField] int _enemyPlayerLayer = 10;

    private const float TeamHandlerWaitSeconds = 30f;
    private const float TeamAssignmentWaitSeconds = 5f;
    private const int TimerNotShown = int.MinValue;
    private const int TimerHidden = -1;
    private const TickRate HudTickRate = TickRate.Tick_0_2;
    #endregion

    #region State
    // Raised by every entity when it spawns or changes team. The local human re-layers on it.
    private static System.Action s_EntityTeamStateChanged;

    /// <summary>
    /// Server only. Raised once a human player has its team, the moment a player who joins during a
    /// match becomes a valid target of the effects that are already running (the clairvoyance summons).
    /// </summary>
    public static event System.Action<TeamPlayer> OnHumanTeamKnownServer;

    private System.Action _layerRefreshHandler;
    private Coroutine _spawnRoutine;
    private NetworkVariable<TimerState> _timerState;

    private bool _prefabIsBot;
    private bool _spawnSequenceDone;
    private bool _authorityWindowOpen;
    private bool _teamKnown;
    private bool _teamRequestSent;
    private bool _registered;
    private bool _localHandlersSubscribed;
    private bool _matchStateHandled;
    private bool _cameraMoveRequested;
    private bool _hudSubscribed;
    private bool _hudStartPushed;

    private int _lastKills;
    private int _lastDeaths;
    private int _lastTimerShown;

    // A bot is told apart from a human at spawn by the bot controller on its prefab, because the
    // bot flag and the bot id are only set by the server after the spawn.
    private bool IsBotEntity => _prefabIsBot || n_IsBotPlayer.Value;
    private bool NeedsSpawnSequence => !IsBotEntity && (IsServer || IsOwner);
    private bool DebugOn => _logLevel >= MID_LogLevel.Debug;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    private static void ResetStatics()
    {
        s_EntityTeamStateChanged = null;
        OnHumanTeamKnownServer = null;
    }
    #endregion

    #region Lifecycle
    public override void OnNetworkSpawn()
    {
        base.OnNetworkSpawn();

        _prefabIsBot = m_PlayerStuffRefrence != null && m_PlayerStuffRefrence.get_NetworkBotPlayerHandler != null;
        if (m_PlayerStuffRefrence == null)
        {
            RunLogError("IAmPlayerServiceLocator reference is missing on the prefab", nameof(OnNetworkSpawn));
        }

        ResetSpawnState();
        m_PlayerTeam.OnValueChanged += OnTeamChanged;

        // The weapon changer scales the camera through this reference as soon as a weapon is equipped.
        if (IsOwner && !IsBotEntity)
        {
            ResolveCamera();
        }

        RaiseEntityTeamStateChanged();

        if (NeedsSpawnSequence)
        {
            _spawnRoutine = StartCoroutine(HumanSpawnSequence());
        }
    }

    public override void OnNetworkDespawn()
    {
        StopSpawnSequence();
        m_PlayerTeam.OnValueChanged -= OnTeamChanged;
        UnsubscribeLocalPlayerHandlers();

        base.OnNetworkDespawn();
    }

    private void OnEnable()
    {
        // Disabling the component stops its coroutines without running them to the end.
        if (IsSpawned && !_spawnSequenceDone && _spawnRoutine == null && NeedsSpawnSequence)
        {
            _spawnRoutine = StartCoroutine(HumanSpawnSequence());
        }
    }

    private void OnDisable()
    {
        _spawnRoutine = null;
        CloseAuthorityWindow();
    }

    private void ResetSpawnState()
    {
        _spawnSequenceDone = false;
        _teamKnown = false;
        _teamRequestSent = false;
        _registered = false;
        _matchStateHandled = false;
        _cameraMoveRequested = false;
        _hudStartPushed = false;
        _lastKills = -1;
        _lastDeaths = -1;
        _lastTimerShown = TimerNotShown;
    }

    private void StopSpawnSequence()
    {
        if (_spawnRoutine != null)
        {
            StopCoroutine(_spawnRoutine);
            _spawnRoutine = null;
        }

        CloseAuthorityWindow();
    }
    #endregion

    #region Spawn Sequence
    private IEnumerator HumanSpawnSequence()
    {
        OpenAuthorityWindow();
        try
        {
            if (IsServer)
            {
                float handlerDeadline = Time.unscaledTime + TeamHandlerWaitSeconds;
                while (!TeamHandlerReady() && Time.unscaledTime < handlerDeadline)
                {
                    yield return null;
                }

                SendTeamRequest();
                TryRegisterInPoints();

                // The team is applied by the handler, tell the server side listeners when it is there
                float serverTeamDeadline = Time.unscaledTime + TeamAssignmentWaitSeconds;
                while (!CheckTeamKnown() && Time.unscaledTime < serverTeamDeadline)
                {
                    yield return null;
                }

                if (CheckTeamKnown())
                {
                    OnHumanTeamKnownServer?.Invoke(this);
                }
            }

            if (IsOwner)
            {
                float teamDeadline = Time.unscaledTime + TeamAssignmentWaitSeconds;
                while (!CheckTeamKnown() && Time.unscaledTime < teamDeadline)
                {
                    yield return null;
                }

                if (!CheckTeamKnown())
                {
                    RunLogError($"No team assignment after {TeamAssignmentWaitSeconds:F0}s, continuing with {m_PlayerTeam.Value}",
                        nameof(HumanSpawnSequence));
                }

                if (IsServer)
                {
                    RelocateOnServer();
                }

                ResolveCamera();
                SubscribeLocalPlayerHandlers();
                StartMatchStateHandling();
                StartHud();
            }

            _spawnSequenceDone = true;
        }
        finally
        {
            CloseAuthorityWindow();
            _spawnRoutine = null;
        }
    }

    // While the window is open the server places the player and the owner does not push its own
    // position over it. The finally block of the spawn sequence and the despawn always close it.
    private void OpenAuthorityWindow()
    {
        if (_authorityWindowOpen) return;
        _authorityWindowOpen = true;
        SetAuthorityMode(AuthorityMode.Server);
    }

    private void CloseAuthorityWindow()
    {
        if (!_authorityWindowOpen) return;
        _authorityWindowOpen = false;
        SetAuthorityMode(AuthorityMode.Client);
    }

    private void SetAuthorityMode(AuthorityMode mode)
    {
        if (m_PlayerStuffRefrence == null) return;

        ClientNetTransform netTransform = m_PlayerStuffRefrence.get_ClientNetTransform;
        if (netTransform == null) return;

        netTransform.authorityMode = mode;
        bool shouldSync = mode == AuthorityMode.Client;
        netTransform.SyncPositionX = shouldSync;
        netTransform.SyncPositionY = shouldSync;
    }

    private void RelocateOnServer()
    {
        NetworkServerManeger server = NetworkServerManeger.networkServerSingleton;
        if (server == null)
        {
            RunLogError("NetworkServerManeger singleton is null, the player is not relocated", nameof(RelocateOnServer));
            return;
        }

        server.RespawnAndRelocatePlayer(NetworkObject);
    }

    private void ResolveCamera()
    {
        if (m_PlayerFinder == null)
        {
            m_PlayerFinder = CinemachinePlayerFind.CinemachineSingleton;
        }
    }
    #endregion

    #region Team Assignment
    private bool TeamHandlerReady()
    {
        NetworkServerManeger server = NetworkServerManeger.networkServerSingleton;
        return server != null && server._teamHandler != null && server._teamHandler.IsInitialized;
    }

    // Server only. The request is sent once. The handler applies the team to this entity.
    private void SendTeamRequest()
    {
        if (_teamRequestSent) return;
        _teamRequestSent = true;

        NetworkServerManeger server = NetworkServerManeger.networkServerSingleton;
        if (server == null || server._teamHandler == null)
        {
            RunLogError("NetTeamHandler not available, assigning the Blue team", nameof(SendTeamRequest));
            m_PlayerTeam.Value = PlayerTeam._BlueTeam;
            _teamKnown = true;
            return;
        }

        if (!server._teamHandler.IsInitialized)
        {
            RunLogError("NetTeamHandler is still not initialized, sending the request anyway", nameof(SendTeamRequest));
        }

        server._teamHandler.RequestTeamAssignmentServerRpc(OwnerClientId);
        if (DebugOn) RunLog($"Team request sent for player {OwnerClientId}", nameof(SendTeamRequest));
    }

    // The team value alone cannot tell "assigned" from "still the prefab default", and a change
    // event does not fire when the assigned team equals the default. The handler can tell.
    private bool CheckTeamKnown()
    {
        if (_teamKnown) return true;

        NetworkServerManeger server = NetworkServerManeger.networkServerSingleton;
        if (server != null && server._teamHandler != null && server._teamHandler.HasTeamAssignment(OwnerClientId))
        {
            _teamKnown = true;
        }

        return _teamKnown;
    }

    private void TryRegisterInPoints()
    {
        if (_registered) return;

        NetworkServerManeger server = NetworkServerManeger.networkServerSingleton;
        if (server == null)
        {
            RunLogError("NetworkServerManeger singleton is null, the player is not registered for points", nameof(TryRegisterInPoints));
            return;
        }

        server.AddPlayerToKillPointsAndDeathDictionaryServerRpc(OwnerClientId);
        _registered = true;
        if (DebugOn) RunLog($"Player {OwnerClientId} registered for points", nameof(TryRegisterInPoints));
    }

    private void OnTeamChanged(PlayerTeam oldTeam, PlayerTeam newTeam)
    {
        _teamKnown = true;
        if (DebugOn) RunLog($"Team of entity {GetEntityId()}: {oldTeam} -> {newTeam}", nameof(OnTeamChanged));

        RaiseEntityTeamStateChanged();
    }

    /// <summary>
    /// Only the server may set the bot flag. The bot handler calls it right after the spawn,
    /// because a NetworkVariable cannot be changed before the object is spawned.
    /// </summary>
    [ServerRpc(RequireOwnership = false)]
    public void SetIsBotServerRpc(bool isBot, ServerRpcParams serverRpcParams = default)
    {
        if (!IsServer) return;

        ulong senderId = serverRpcParams.Receive.SenderClientId;
        if (senderId != NetworkManager.ServerClientId)
        {
            MID_Logger.LogWarning(MID_LogLevel.Info, $"Client {senderId} tried to set the bot flag, rejected",
                nameof(TeamPlayer), nameof(SetIsBotServerRpc));
            return;
        }

        n_IsBotPlayer.Value = isBot;
        if (DebugOn) RunLog($"Bot flag set: {isBot}", nameof(SetIsBotServerRpc));
    }

    private ulong GetEntityId()
    {
        if (IsBotEntity && m_PlayerStuffRefrence != null)
        {
            return m_PlayerStuffRefrence.get__MID__PlayerOrBotOwnerId;
        }

        return OwnerClientId;
    }
    #endregion

    #region Layers (local human only)
    private static void RaiseEntityTeamStateChanged()
    {
        s_EntityTeamStateChanged?.Invoke();
    }

    private void SubscribeLocalPlayerHandlers()
    {
        if (_localHandlersSubscribed) return;

        if (_layerRefreshHandler == null)
        {
            _layerRefreshHandler = ApplyLayersFromLocalPlayerPerspective;
        }

        s_EntityTeamStateChanged += _layerRefreshHandler;
        _localHandlersSubscribed = true;

        ApplyLayersFromLocalPlayerPerspective();
    }

    // The local human sees itself on the main layer, enemies on the enemy layer and everyone else
    // on the teammate layer. Who is an enemy is decided by NetTeamRules, like the damage rules.
    private void ApplyLayersFromLocalPlayerPerspective()
    {
        if (this == null || !IsSpawned || !IsOwner || IsBotEntity) return;

        if (!CheckTeamKnown())
        {
            if (DebugOn) RunLog("Own team not assigned yet, skipping the layer pass", nameof(ApplyLayersFromLocalPlayerPerspective));
            return;
        }

        PlayerTeam myTeam = m_PlayerTeam.Value;
        System.Collections.Generic.IReadOnlyList<IAmPlayerServiceLocator> all = IAmPlayerServiceLocator.All;

        for (int i = 0; i < all.Count; i++)
        {
            IAmPlayerServiceLocator entityRefs = all[i];
            if (entityRefs == null) continue;

            TeamPlayer entity = entityRefs.get_PlayerTeamHandler;
            if (entity == null) continue;

            int layer;
            if (entity == this)
            {
                layer = _mainPlayerLayer;
            }
            else
            {
                layer = NetTeamRules.AreEnemies(myTeam, entity.m_PlayerTeam.Value) ? _enemyPlayerLayer : _teammatePlayerLayer;
            }

            GameObject entityObject = entity.gameObject;
            if (entityObject.layer != layer)
            {
                entityObject.layer = layer;
            }
        }
    }

    private void UnsubscribeLocalPlayerHandlers()
    {
        if (_localHandlersSubscribed)
        {
            s_EntityTeamStateChanged -= _layerRefreshHandler;
            _localHandlersSubscribed = false;
        }

        if (_timerState != null)
        {
            _timerState.OnValueChanged -= OnMatchTimerStateChanged;
            _timerState = null;
        }

        if (_hudSubscribed)
        {
            MID_TickDispatcher.Unsubscribe(HudTickRate, UpdatePlayerHud);
            _hudSubscribed = false;
        }
    }
    #endregion

    #region Camera and Match State (local human only)
    private void StartMatchStateHandling()
    {
        if (_matchStateHandled) return;
        _matchStateHandled = true;

        GameSetupCoordinator coordinator = GameSetupCoordinator.TryGetInstance();
        if (coordinator == null)
        {
            RunLogError("GameSetupCoordinator not found, the camera and match state are not handled", nameof(StartMatchStateHandling));
            return;
        }

        if (!coordinator.IsOnlineMode())
        {
            RequestCameraMove();
            return;
        }

        var runner = coordinator.GetGameManager() as MidManStudio.Sttd.InGame.OnlineSetup.OnlineInGameRunner;
        if (runner == null)
        {
            RunLogError("Online runner not found, the camera follows no timer state", nameof(StartMatchStateHandling));
            return;
        }

        // The runner returns null until the server manager and its time handler exist.
        NetworkVariable<TimerState> timerState = runner.CurrentMatchTimerState;
        if (timerState == null)
        {
            RunLogError("Match timer state not available yet, the camera follows no timer state", nameof(StartMatchStateHandling));
            return;
        }

        _timerState = timerState;
        timerState.OnValueChanged += OnMatchTimerStateChanged;

        TimerState state = timerState.Value;
        if (state == TimerState.InMatch || state == TimerState.PreMatchCountdown)
        {
            RequestCameraMove();
        }
    }

    private void OnMatchTimerStateChanged(TimerState oldValue, TimerState newValue)
    {
        if (newValue == TimerState.PreMatchCountdown)
        {
            RequestCameraMove();
        }
    }

    private void RequestCameraMove()
    {
        if (_cameraMoveRequested) return;
        if (m_PlayerFinder == null || m_PlayerFinder.CineMachineInitialized) return;

        _cameraMoveRequested = true;
        m_PlayerFinder.CameraMove();
    }
    #endregion

    #region HUD (local human only)
    private void StartHud()
    {
        if (_hudSubscribed) return;

        MID_TickDispatcher.Subscribe(HudTickRate, UpdatePlayerHud);
        _hudSubscribed = true;
    }

    // Runs every 0.2 s but only pushes a value to the HUD when it changed.
    private void UpdatePlayerHud(float deltaTime)
    {
        if (this == null || !IsSpawned || !IsOwner || IsBotEntity) return;
        if (!PlayerHudManager.HasInstance) return;

        PlayerHudManager hud = PlayerHudManager.Instance;
        if (hud == null || !hud.isInitialized) return;

        NetworkServerManeger server = NetworkServerManeger.networkServerSingleton;
        NetPointsHandler points = server != null ? server._pointsHandler : null;
        if (points != null)
        {
            if (!_hudStartPushed)
            {
                _hudStartPushed = true;
                if (UsesTeamPoints(NetTeamRules.CurrentMode))
                {
                    points.RefreshTeamPointsHud();
                }
            }

            int kills = points.GetCurrentPlayerKills(OwnerClientId);
            if (kills != _lastKills)
            {
                _lastKills = kills;
                hud.UpdateKillCounter(kills);
            }

            int deaths = points.GetCurrentPlayerDeaths(OwnerClientId);
            if (deaths != _lastDeaths)
            {
                _lastDeaths = deaths;
                hud.UpdateDeathCounter(deaths);
            }
        }

        PushMatchTimer(hud);
    }

    private void PushMatchTimer(PlayerHudManager hud)
    {
        GameSetupCoordinator coordinator = GameSetupCoordinator.TryGetInstance();
        if (coordinator == null) return;

        // A timer that is overridden (Survival) is hidden.
        IGameManager manager = coordinator.GetGameManager();
        if (manager != null && manager.IsTimerOverridden())
        {
            if (_lastTimerShown != TimerHidden)
            {
                _lastTimerShown = TimerHidden;
                hud.UpdateMatchTimer(-1f);
            }
            return;
        }

        if (coordinator.GetCurrentTimerState() == TimerState.NullState) return;

        float timeRemaining = coordinator.GetTimeRemaining();
        int shownSecond = Mathf.FloorToInt(timeRemaining);
        if (shownSecond == _lastTimerShown) return;

        _lastTimerShown = shownSecond;
        hud.UpdateMatchTimer(timeRemaining);
    }

    private static bool UsesTeamPoints(MID_GameMatchMode mode)
    {
        return mode != MID_GameMatchMode._FreeForAll && mode != MID_GameMatchMode._Survival;
    }
    #endregion

    #region Logging
    private void RunLog(string message, string methodName = "") =>
        MID_Logger.LogDebug(_logLevel, message, nameof(TeamPlayer), methodName);

    private void RunLogError(string message, string methodName = "", System.Exception e = null) =>
        MID_Logger.LogError(_logLevel, message, nameof(TeamPlayer), methodName, e);
    #endregion
}
