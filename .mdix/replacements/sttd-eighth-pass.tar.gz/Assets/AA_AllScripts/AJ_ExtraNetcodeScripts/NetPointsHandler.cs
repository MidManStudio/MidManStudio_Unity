﻿// ============================================================================
// NOTICE: Full documentation and design decisions for this file
// live in docs/StickToTheDeath/bots.md, section "NetPointsHandler.cs"
// ============================================================================
using UnityEngine;
using Unity.Netcode;
using MidManStudio.Core.Logging;
using MidManStudio.Sttd.Core.HelperFunctions;
using MidManStudio.Sttd.InGame.NetworkDataStructures;
using System;
using System.Collections.Generic;
using MidManStudio.Sttd.InGame.GameItemData;
using LobbyRelaySample;
using MidManStudio.Netcode.Collections;
namespace MidManStudio.Sttd.InGame.Setup
{
    /// <summary>
    /// Server-authoritative points and statistics handler
    /// Manages kills, deaths, streaks, team points, and survival points
    /// Supports regular matches and survival mode
    /// </summary>
    [RequireComponent(typeof(NetworkObject))]
    public class NetPointsHandler : NetworkBehaviour
    {
        #region References
        private NetworkServerManeger _serverManager;
        private IGameManager _gameManager;
        #endregion

        #region Configuration
        [Header("Debug Settings")]
        [SerializeField] private MID_LogLevel _logLevel = MID_LogLevel.Error;

        [Header("Points Configuration")]
        [SerializeField] private int maxTeamPointsRequired = 50;

        [Header("Match End Conditions Per Mode")]
        private readonly Dictionary<MID_GameMatchMode, int> _modePointThresholds = new Dictionary<MID_GameMatchMode, int>
        {
            { MID_GameMatchMode._TeamDeathMatch, 50 },
            { MID_GameMatchMode._HardPoint, 100 },
            { MID_GameMatchMode._Objectives, 75 },
            { MID_GameMatchMode._IgniteSubjugation, 60 },
            { MID_GameMatchMode._FreeForAll, 30 },
            { MID_GameMatchMode._WeekEndBrawl, 150 },
            { MID_GameMatchMode._Survival, -1 } // No point threshold
        };
        #endregion

        #region Network Dictionaries - Regular Match
        private MID_NetworkDictionary<ulong, int> nd_PlayersKillStash;
        private MID_NetworkDictionary<ulong, int> nd_PlayersDeathStash;
        private MID_NetworkDictionary<ulong, int> nd_PlayersPointsStash;
        private MID_NetworkDictionary<ulong, int> nd_PlayerKillStreekStash;
        private MID_NetworkDictionary<ulong, int> nd_PlayerMultikillTimedStreekStash;
        private MID_NetworkDictionary<ulong, int> nd_PlayerDeathStreekStash;

        private NetworkVariable<int> nl_BlueTeamPoints = new NetworkVariable<int>();
        private NetworkVariable<int> nl_RedTeamPoints = new NetworkVariable<int>();

        // Multikill window, tracked on the server for every entity so bots and remote clients
        // follow the same rule as the host.
        /// <summary>Server only. Raised after a kill is counted, with the killer and its new kill count.</summary>
        public event Action<ulong, int> OnKillCountChanged;

        private const float MultiKillWindowSeconds = 20f;
        private readonly Dictionary<ulong, float> _lastKillTime = new Dictionary<ulong, float>();
        #endregion

        #region Network Dictionaries - Survival Mode
        private MID_NetworkDictionary<ulong, int> nd_SurvivalPoints;
        private MID_NetworkDictionary<ulong, int> nd_SurvivalRevivesRemaining;
        #endregion

        #region Network Dictionaries - Weekend Brawl
        [Header("Weekend Brawl - Four Team System")]
        private NetworkVariable<int> nl_BlackTeamPoints;
        private NetworkVariable<int> nl_WhiteTeamPoints;
        #endregion

        #region Summon Points
        [Header("Summon Points Configuration")]
        [SerializeField] private int _summonPointsConversionRate = 100;
        [SerializeField] private int _maxSummonPoints = 1000;

        private MID_NetworkDictionary<ulong, int> nd_PlayerSummonPoints;
        #endregion

        #region Life Cycle
        private void Awake()
        {
            nd_PlayersKillStash = new MID_NetworkDictionary<ulong, int>();
            nd_PlayersDeathStash = new MID_NetworkDictionary<ulong, int>();
            nd_PlayersPointsStash = new MID_NetworkDictionary<ulong, int>();
            nd_PlayerKillStreekStash = new MID_NetworkDictionary<ulong, int>();
            nd_PlayerMultikillTimedStreekStash = new MID_NetworkDictionary<ulong, int>();
            nd_PlayerDeathStreekStash = new MID_NetworkDictionary<ulong, int>();

            nl_BlueTeamPoints = new NetworkVariable<int>(0);
            nl_RedTeamPoints = new NetworkVariable<int>(0);
            nl_BlackTeamPoints = new NetworkVariable<int>(0);
            nl_WhiteTeamPoints = new NetworkVariable<int>(0);

            nd_PlayerSummonPoints = new MID_NetworkDictionary<ulong, int>();

            nd_SurvivalPoints = new MID_NetworkDictionary<ulong, int>();
            nd_SurvivalRevivesRemaining = new MID_NetworkDictionary<ulong, int>();
        }
        public override void OnNetworkSpawn()
        {
            base.OnNetworkSpawn();

            if (IsServer)
            {
                nl_BlueTeamPoints.OnValueChanged += OnBlueTeamPointsChanged;
                nl_RedTeamPoints.OnValueChanged += OnRedTeamPointsChanged;
                nl_BlackTeamPoints.OnValueChanged += OnBlackTeamPointsChanged;
                nl_WhiteTeamPoints.OnValueChanged += OnWhiteTeamPointsChanged;
            }

            if (IsClient)
            {
                nl_BlueTeamPoints.OnValueChanged += OnTeamPointsChangedClient;
                nl_RedTeamPoints.OnValueChanged += OnTeamPointsChangedClient;
                nl_BlackTeamPoints.OnValueChanged += OnTeamPointsChangedClient;
                nl_WhiteTeamPoints.OnValueChanged += OnTeamPointsChangedClient;
            }
        }

        private void OnWhiteTeamPointsChanged(int previousValue, int newValue)
        {
            if (IsServer)
            {
                CheckTeamPointThreshold();
            }
        }

        private void OnBlackTeamPointsChanged(int previousValue, int newValue)
        {
            if (IsServer)
            {
                CheckTeamPointThreshold();
            }
        }

        private void OnTeamPointsChangedClient(int oldValue, int newValue)
        {
            RefreshTeamPointsHud();
        }

        /// <summary>
        /// Pushes the current team scores and the match threshold to the local HUD. Called when a team
        /// score changes and by the local player when its HUD is ready, so the start values are real.
        /// </summary>
        public void RefreshTeamPointsHud()
        {
            if (PlayerHudManager.HasInstance && PlayerHudManager.Instance.isInitialized)
            {
                var gameMode = GetCurrentGameMode();

                if (gameMode == MID_GameMatchMode._WeekEndBrawl)
                {
                    PlayerHudManager.Instance.UpdateWeekendBrawlTeamPoints(
                        nl_BlueTeamPoints.Value,
                        nl_RedTeamPoints.Value,
                        nl_BlackTeamPoints.Value,
                        nl_WhiteTeamPoints.Value,
                        GetPointThresholdForCurrentMode()
                    );
                }
                else
                {
                    PlayerHudManager.Instance.UpdateStandardTeamPoints(
                        nl_BlueTeamPoints.Value,
                        nl_RedTeamPoints.Value,
                        GetPointThresholdForCurrentMode()
                    );
                }
            }
        }

        public override void OnNetworkDespawn()
        {
            if (IsServer)
            {
                nl_BlueTeamPoints.OnValueChanged -= OnBlueTeamPointsChanged;
                nl_RedTeamPoints.OnValueChanged -= OnRedTeamPointsChanged;
                nl_BlackTeamPoints.OnValueChanged -= OnBlackTeamPointsChanged;
                nl_WhiteTeamPoints.OnValueChanged -= OnWhiteTeamPointsChanged;
            }

            base.OnNetworkDespawn();
        }
        #endregion

        #region Initialization
      

        public void Initialize(NetworkServerManeger serverManager)
        {
            _serverManager = serverManager;

            // Get game manager reference from coordinator
            if (GameSetupCoordinator.HasInstance)
            {
                _gameManager = GameSetupCoordinator.Instance.GetGameManager();
                if (DebugOn) RunLog($"Game manager cached: {_gameManager?.GetType().Name}", nameof(Initialize));
            }
            else
            {
                RunLogWarning("Coordinator not available during initialization", nameof(Initialize));
            }

            if (IsServer)
            {
                _lastKillTime.Clear();
                nd_PlayersKillStash.ResetDirty();
                nd_PlayersDeathStash.ResetDirty();
                nd_PlayersPointsStash.ResetDirty();
                nd_PlayerKillStreekStash.ResetDirty();
                nd_PlayerMultikillTimedStreekStash.ResetDirty();
                nd_PlayerDeathStreekStash.ResetDirty();
                nd_SurvivalPoints.ResetDirty();
                nd_SurvivalRevivesRemaining.ResetDirty();
                nl_BlueTeamPoints.ResetDirty();
                nl_RedTeamPoints.ResetDirty();
                nl_BlackTeamPoints.ResetDirty();
                nl_WhiteTeamPoints.ResetDirty();
                nd_PlayerSummonPoints.ResetDirty();
            }

            InitializeSummonPoints();
            RunLog("NetPointsHandler initialized", nameof(Initialize));
        }

        private void InitializeSummonPoints()
        {
            nd_PlayerSummonPoints = new MID_NetworkDictionary<ulong, int>();
        }
        #endregion

        #region Game Mode Query
        private MID_GameMatchMode GetCurrentGameMode()
        {
            if (_gameManager == null)
            {
                // Try to get it again if we missed it
                if (GameSetupCoordinator.HasInstance)
                {
                    _gameManager = GameSetupCoordinator.Instance.GetGameManager();
                }
            }

            return _gameManager?.GetCurrentMatchMode() ?? MID_GameMatchMode._TeamDeathMatch;
        }

        private int GetPointThresholdForCurrentMode()
        {
            var currentMode = GetCurrentGameMode();
            return _modePointThresholds.TryGetValue(currentMode, out int threshold) ? threshold : maxTeamPointsRequired;
        }
        #endregion


        #region Entity Registration
        public void AddEntityToAllDictionaries(ulong entityId)
        {
            if (!IsServer) return;

            AddToKillDictionaries(entityId);
            AddToDeathDictionaries(entityId);
            AddToPointsStash(entityId);
            AddToSummonPointsStash(entityId);

            string entityType = IsBotId(entityId) ? "bot" : "player";
            if (DebugOn) RunLog($"Added {entityType} {entityId} to all dictionaries", nameof(AddEntityToAllDictionaries));
        }

        private void AddToPointsStash(ulong entityId)
        {
            if (!nd_PlayersPointsStash.ContainsKey(entityId))
            {
                nd_PlayersPointsStash.Add(entityId, 0);
            }
        }

        private void AddToKillDictionaries(ulong entityId)
        {
            if (!nd_PlayersKillStash.ContainsKey(entityId))
            {
                nd_PlayersKillStash.Add(entityId, 0);
            }

            if (!nd_PlayerKillStreekStash.ContainsKey(entityId))
            {
                nd_PlayerKillStreekStash.Add(entityId, 0);
            }

            if (!nd_PlayerMultikillTimedStreekStash.ContainsKey(entityId))
            {
                nd_PlayerMultikillTimedStreekStash.Add(entityId, 0);
            }
        }

        private void AddToDeathDictionaries(ulong entityId)
        {
            if (!nd_PlayersDeathStash.ContainsKey(entityId))
            {
                nd_PlayersDeathStash.Add(entityId, 0);
            }

            if (!nd_PlayerDeathStreekStash.ContainsKey(entityId))
            {
                nd_PlayerDeathStreekStash.Add(entityId, 0);
            }
        }

        public bool IsEntityRegistered(ulong entityId)
        {
            return nd_PlayersKillStash.ContainsKey(entityId) &&
                   nd_PlayersDeathStash.ContainsKey(entityId) &&
                   nd_PlayersPointsStash.ContainsKey(entityId);
        }
        #endregion

        #region Summon Points
        private void AddToSummonPointsStash(ulong entityId)
        {
            if (!nd_PlayerSummonPoints.ContainsKey(entityId))
            {
                nd_PlayerSummonPoints.Add(entityId, 0);
            }
        }

        public void AwardSummonPoints(ulong playerId, int matchPoints)
        {
            if (!IsServer) return;

            if (!nd_PlayerSummonPoints.ContainsKey(playerId))
            {
                AddToSummonPointsStash(playerId);
            }

            int summonPointsToAdd = matchPoints / _summonPointsConversionRate;

            if (summonPointsToAdd > 0)
            {
                int currentSummonPoints = nd_PlayerSummonPoints[playerId];
                int newSummonPoints = Mathf.Min(currentSummonPoints + summonPointsToAdd, _maxSummonPoints);
                nd_PlayerSummonPoints[playerId] = newSummonPoints;

                string entityType = IsBotId(playerId) ? "Bot" : "Player";
                if (DebugOn) RunLog($"{entityType} {playerId} summon points: {newSummonPoints} (added {summonPointsToAdd})",
                    nameof(AwardSummonPoints));

                if (!IsBotId(playerId))
                {
                    UpdateSummonPointsHUD_ClientRpc(playerId, newSummonPoints);
                }
            }
        }

        public bool ConsumeSummonPoints(ulong playerId, int pointsCost)
        {
            if (!IsServer) return false;

            if (!nd_PlayerSummonPoints.ContainsKey(playerId))
            {
                return false;
            }

            int currentPoints = nd_PlayerSummonPoints[playerId];

            if (currentPoints >= pointsCost)
            {
                nd_PlayerSummonPoints[playerId] = currentPoints - pointsCost;

                if (DebugOn) RunLog($"Player {playerId} consumed {pointsCost} summon points, remaining: {nd_PlayerSummonPoints[playerId]}",
                    nameof(ConsumeSummonPoints));

                if (!IsBotId(playerId))
                {
                    UpdateSummonPointsHUD_ClientRpc(playerId, nd_PlayerSummonPoints[playerId]);
                }

                return true;
            }

            return false;
        }

        public int GetSummonPoints(ulong playerId)
        {
            return nd_PlayerSummonPoints.ContainsKey(playerId) ? nd_PlayerSummonPoints[playerId] : 0;
        }

        public void AddSummonPointsManually(ulong playerId, int points)
        {
            if (!IsServer) return;

            if (!nd_PlayerSummonPoints.ContainsKey(playerId))
            {
                AddToSummonPointsStash(playerId);
            }

            int currentPoints = nd_PlayerSummonPoints[playerId];
            int newPoints = Mathf.Min(currentPoints + points, _maxSummonPoints);
            nd_PlayerSummonPoints[playerId] = newPoints;

            if (DebugOn) RunLog($"Player {playerId} manually gained {points} summon points, total: {newPoints}",
                nameof(AddSummonPointsManually));

            if (!IsBotId(playerId))
            {
                UpdateSummonPointsHUD_ClientRpc(playerId, newPoints);
            }
        }

        [ClientRpc]
        private void UpdateSummonPointsHUD_ClientRpc(ulong playerId, int summonPoints)
        {
            if (NetworkManager.Singleton.LocalClientId == playerId && PlayerHudManager.HasInstance)
            {
                // PlayerHudManager.Instance.UpdateSummonPoints(summonPoints);
            }
        }
        #endregion

        #region Points Management - Regular Match
        public void ProcessKillRewards(IAmPlayerServiceLocator senderRefs, ulong senderId,
            MID_PlayerKillTypeAndPoints baseKill)
        {
            if (!IsServer) return;

            try
            {
                if (DebugOn) RunLog($"Processing kill rewards for {senderId}, Kill type: {baseKill._playerKillType}",
                    nameof(ProcessKillRewards));

                if (!IsEntityRegistered(senderId))
                {
                    RunLogWarning($"Killer {senderId} not registered - registering now",
                        nameof(ProcessKillRewards));
                    AddEntityToAllDictionaries(senderId);
                }

                ExpireMultiKillWindow(senderId);
                var (extraPopup1, extraPopup2) = CalculateMultikillBonus(senderId);
                var totalPoints = baseKill._valueInPoints + extraPopup1._valueInPoints + extraPopup2._valueInPoints;

                IncrementPlayersPersonalPoints(totalPoints, senderId);

                if (!IsBotId(senderId) && senderRefs != null && !senderRefs.IsBotPlayer)
                {
                    senderRefs.ShowKillPopupClientRpc(baseKill, extraPopup1, extraPopup2, 2, senderId);
                }

                if (DebugOn) RunLog($"Awarded {totalPoints} points to {senderId}", nameof(ProcessKillRewards));
            }
            catch (Exception e)
            {
                RunLogError("Exception in ProcessKillRewards", nameof(ProcessKillRewards), e);
            }
        }

        // A kill that comes more than the window after the previous one starts a new multikill.
        private void ExpireMultiKillWindow(ulong entityId)
        {
            float now = Time.time;

            if (_lastKillTime.TryGetValue(entityId, out float lastKill) &&
                now - lastKill > MultiKillWindowSeconds &&
                nd_PlayerMultikillTimedStreekStash.ContainsKey(entityId))
            {
                nd_PlayerMultikillTimedStreekStash[entityId] = 0;
            }

            _lastKillTime[entityId] = now;
        }

        private (MID_PlayerKillTypeAndPoints, MID_PlayerKillTypeAndPoints) CalculateMultikillBonus(ulong playerId)
        {
            var extraPopup1 = new MID_PlayerKillTypeAndPoints { _playerKillType = MID_PlayerKillType.None, _valueInPoints = 0 };
            var extraPopup2 = new MID_PlayerKillTypeAndPoints { _playerKillType = MID_PlayerKillType.None, _valueInPoints = 0 };

            if (!nd_PlayerMultikillTimedStreekStash.ContainsKey(playerId))
            {
                return (extraPopup1, extraPopup2);
            }

            var multikills = nd_PlayerMultikillTimedStreekStash[playerId];

            switch (multikills)
            {
                case 1: extraPopup1 = new MID_PlayerKillTypeAndPoints { _playerKillType = MID_PlayerKillType.DoubleKill, _valueInPoints = 35 }; break;
                case 2: extraPopup1 = new MID_PlayerKillTypeAndPoints { _playerKillType = MID_PlayerKillType.TripleKill, _valueInPoints = 40 }; break;
                case 3: extraPopup1 = new MID_PlayerKillTypeAndPoints { _playerKillType = MID_PlayerKillType.QuadKill, _valueInPoints = 45 }; break;
                case 4: extraPopup1 = new MID_PlayerKillTypeAndPoints { _playerKillType = MID_PlayerKillType.PentaKill, _valueInPoints = 50 }; break;
                case 5: extraPopup1 = new MID_PlayerKillTypeAndPoints { _playerKillType = MID_PlayerKillType.HexaKill, _valueInPoints = 55 }; break;
                case 6: extraPopup1 = new MID_PlayerKillTypeAndPoints { _playerKillType = MID_PlayerKillType.CookingTheseFools, _valueInPoints = 60 }; break;
                case 7:
                    extraPopup1 = new MID_PlayerKillTypeAndPoints { _playerKillType = MID_PlayerKillType.Berserker, _valueInPoints = 65 };
                    extraPopup2 = new MID_PlayerKillTypeAndPoints { _playerKillType = MID_PlayerKillType.Ultimatum, _valueInPoints = 65 };
                    break;
            }

            return (extraPopup1, extraPopup2);
        }

        public void IncrementPlayersPersonalPoints(int amount, ulong entityId)
        {
            if (!IsServer) return;

            if (nd_PlayersPointsStash.ContainsKey(entityId))
            {
                nd_PlayersPointsStash[entityId] += amount;
                string entityType = IsBotId(entityId) ? "Bot" : "Player";
                if (DebugOn) RunLog($"{entityType} {entityId} points: {nd_PlayersPointsStash[entityId]}",
                    nameof(IncrementPlayersPersonalPoints));

                AwardSummonPoints(entityId, amount);

                if (!IsBotId(entityId))
                {
                    UpdatePersonalPointsHUD_ClientRpc(entityId, nd_PlayersPointsStash[entityId]);
                }
            }
        }

        [ClientRpc]
        private void UpdatePersonalPointsHUD_ClientRpc(ulong playerId, int personalPoints)
        {
            if (NetworkManager.Singleton.LocalClientId == playerId && PlayerHudManager.HasInstance)
            {
                // PlayerHudManager.Instance.UpdatePersonalPoints(personalPoints);
            }
        }

        public void DecrementPlayerPersonalPoints(int amount, ulong entityId)
        {
            if (!IsServer) return;

            if (nd_PlayersPointsStash.ContainsKey(entityId))
            {
                nd_PlayersPointsStash[entityId] = Mathf.Max(0, nd_PlayersPointsStash[entityId] - amount);
            }
        }
        #endregion

        #region Stats Management
        public void UpdatePlayerStats(ulong killerId, ulong victimId)
        {
            if (!IsServer) return;

            try
            {
                IncrementDeath(victimId);
                IncrementPlayerDeathStreek(victimId);
                ResetPlayerKillStreek(victimId);

                ResetPlayerDeathStreek(killerId);
                IncrementKill(killerId);
                IncrementPlayerKillStreek(killerId);
                IncrementPlayerMultikillTimedKillStreek(killerId);

                OnKillCountChanged?.Invoke(killerId, GetCurrentPlayerKills(killerId));

                if (!IsBotId(killerId))
                {
                    var killerObj = GetPlayerOrBotObject(killerId);
                    if (killerObj != null && killerObj.TryGetComponent(out IAmPlayerServiceLocator killerRefs))
                    {
                        if (killerRefs.get_PlayerInGameCollections != null)
                        {
                            killerRefs.get_PlayerInGameCollections.n_ResetMultiKillStreek.Value = true;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                RunLogError("Exception in UpdatePlayerStats", nameof(UpdatePlayerStats), e);
            }
        }

        public void IncrementKill(ulong entityId)
        {
            if (!IsServer) return;

            if (nd_PlayersKillStash.ContainsKey(entityId))
            {
                nd_PlayersKillStash[entityId] += 1;
                string entityType = IsBotId(entityId) ? "Bot" : "Player";
                if (DebugOn) RunLog($"{entityType} {entityId} kills: {nd_PlayersKillStash[entityId]}", nameof(IncrementKill));
            }
        }

        public void IncrementDeath(ulong entityId)
        {
            if (!IsServer) return;

            if (nd_PlayersDeathStash.ContainsKey(entityId))
            {
                nd_PlayersDeathStash[entityId] += 1;
                string entityType = IsBotId(entityId) ? "Bot" : "Player";
                if (DebugOn) RunLog($"{entityType} {entityId} deaths: {nd_PlayersDeathStash[entityId]}", nameof(IncrementDeath));
            }
        }

        private void IncrementPlayerKillStreek(ulong entityId)
        {
            if (!IsServer) return;

            if (nd_PlayerKillStreekStash.ContainsKey(entityId))
            {
                nd_PlayerKillStreekStash[entityId] += 1;
            }
        }

        public void IncrementPlayerDeathStreek(ulong entityId)
        {
            if (!IsServer) return;

            if (nd_PlayerDeathStreekStash.ContainsKey(entityId))
            {
                nd_PlayerDeathStreekStash[entityId] += 1;
            }
        }

        private void IncrementPlayerMultikillTimedKillStreek(ulong entityId)
        {
            if (!IsServer) return;

            if (nd_PlayerMultikillTimedStreekStash.ContainsKey(entityId))
            {
                nd_PlayerMultikillTimedStreekStash[entityId] += 1;
            }
        }

        public void ResetPlayerKillStreek(ulong entityId)
        {
            if (!IsServer) return;

            if (nd_PlayerKillStreekStash.ContainsKey(entityId))
            {
                nd_PlayerKillStreekStash[entityId] = 0;
            }
        }

        public void ResetPlayerDeathStreek(ulong entityId)
        {
            if (!IsServer) return;

            if (nd_PlayerDeathStreekStash.ContainsKey(entityId))
            {
                nd_PlayerDeathStreekStash[entityId] = 0;
            }
        }

        [ServerRpc(RequireOwnership = false)]
        public void ResetMultiKillStreekServerRpc(ulong entityId)
        {
            if (nd_PlayerMultikillTimedStreekStash.ContainsKey(entityId))
            {
                nd_PlayerMultikillTimedStreekStash[entityId] = 0;
            }
        }
        #endregion

        #region Team Points
        [ServerRpc(RequireOwnership = false)]
        public void IncrementTeamPointsServerRpc(PlayerTeam team, ServerRpcParams serverRpcParams = default)
        {
            if (!IsServer) return;

            // Mode handlers run on the server and are trusted. A remote client must not move the score.
            if (serverRpcParams.Receive.SenderClientId != NetworkManager.ServerClientId)
            {
                MID_Logger.LogWarning(MID_LogLevel.Info,
                    $"Ignored team point request from client {serverRpcParams.Receive.SenderClientId}",
                    nameof(NetPointsHandler), nameof(IncrementTeamPointsServerRpc));
                return;
            }

            AddTeamPoint(team);
        }

        /// <summary>
        /// Team Deathmatch scores one team point per kill. Every other mode scores through its own
        /// handler, so this does nothing there.
        /// </summary>
        public void AwardKillTeamPoint(PlayerTeam killerTeam)
        {
            if (!IsServer) return;
            if (GetCurrentGameMode() != MID_GameMatchMode._TeamDeathMatch) return;

            AddTeamPoint(killerTeam);
        }

        private void AddTeamPoint(PlayerTeam team)
        {
            switch (team)
            {
                case PlayerTeam._BlueTeam:
                    nl_BlueTeamPoints.Value += 1;
                    if (DebugOn) RunLog($"Blue team points: {nl_BlueTeamPoints.Value}", nameof(AddTeamPoint));
                    break;

                case PlayerTeam._RedTeam:
                    nl_RedTeamPoints.Value += 1;
                    if (DebugOn) RunLog($"Red team points: {nl_RedTeamPoints.Value}", nameof(AddTeamPoint));
                    break;

                default:
                    RunLogWarning($"No two-team score for {team}, point ignored", nameof(AddTeamPoint));
                    break;
            }
        }

        private void OnBlueTeamPointsChanged(int oldValue, int newValue)
        {
            if (IsServer)
            {
                CheckTeamPointThreshold();
            }
        }

        private void OnRedTeamPointsChanged(int oldValue, int newValue)
        {
            if (IsServer)
            {
                CheckTeamPointThreshold();
            }
        }
        #endregion

        #region Survival Points
        public void AwardSurvivalPoints(ulong playerId, int points)
        {
            if (!IsServer) return;

            if (!nd_SurvivalPoints.ContainsKey(playerId))
            {
                nd_SurvivalPoints.Add(playerId, 0);
            }

            nd_SurvivalPoints[playerId] += points;
            if (DebugOn) RunLog($"Player {playerId} survival points: {nd_SurvivalPoints[playerId]}",
                nameof(AwardSurvivalPoints));

            if (!IsBotId(playerId))
            {
                UpdateSurvivalPointsClientRpc(playerId, nd_SurvivalPoints[playerId]);
            }
        }

        [ClientRpc]
        private void UpdateSurvivalPointsClientRpc(ulong playerId, int points)
        {
            if (NetworkManager.Singleton.LocalClientId == playerId && PlayerHudManager.HasInstance)
            {
                PlayerHudManager.Instance.UpdateSurvivalPoints(points);
            }
        }

        public void InitializeSurvivalRevives(ulong playerId, int startingRevives = 3)
        {
            if (!IsServer) return;

            if (!nd_SurvivalRevivesRemaining.ContainsKey(playerId))
            {
                nd_SurvivalRevivesRemaining.Add(playerId, startingRevives);
            }
            else
            {
                nd_SurvivalRevivesRemaining[playerId] = startingRevives;
            }

            if (DebugOn) RunLog($"Player {playerId} initialized with {startingRevives} revives",
                nameof(InitializeSurvivalRevives));
        }

        public bool ConsumeSurvivalRevive(ulong playerId)
        {
            if (!IsServer) return false;

            if (!nd_SurvivalRevivesRemaining.ContainsKey(playerId))
            {
                return false;
            }

            if (nd_SurvivalRevivesRemaining[playerId] > 0)
            {
                nd_SurvivalRevivesRemaining[playerId] -= 1;
                if (DebugOn) RunLog($"Player {playerId} revives remaining: {nd_SurvivalRevivesRemaining[playerId]}",
                    nameof(ConsumeSurvivalRevive));
                return true;
            }

            return false;
        }

        public void AddSurvivalRevive(ulong playerId, int maxRevives = 5)
        {
            if (!IsServer) return;

            if (!nd_SurvivalRevivesRemaining.ContainsKey(playerId))
            {
                nd_SurvivalRevivesRemaining.Add(playerId, 1);
            }
            else
            {
                nd_SurvivalRevivesRemaining[playerId] = Mathf.Min(
                    nd_SurvivalRevivesRemaining[playerId] + 1,
                    maxRevives
                );
            }

            if (DebugOn) RunLog($"Player {playerId} gained revive, total: {nd_SurvivalRevivesRemaining[playerId]}",
                nameof(AddSurvivalRevive));
        }

        public int GetSurvivalRevivesRemaining(ulong playerId)
        {
            if (nd_SurvivalRevivesRemaining.ContainsKey(playerId))
            {
                return nd_SurvivalRevivesRemaining[playerId];
            }
            return 0;
        }
        #endregion

        #region Weekend Brawl Team Points
        [ServerRpc(RequireOwnership = false)]
        public void IncrementWeekendBrawlTeamPointsServerRpc(PlayerTeam team)
        {
            if (!IsServer) return;

            switch (team)
            {
                case PlayerTeam._BlueTeam:
                    nl_BlueTeamPoints.Value++;
                    break;

                case PlayerTeam._RedTeam:
                    nl_RedTeamPoints.Value++;
                    break;

                case PlayerTeam._BlackTeam:
                    nl_BlackTeamPoints.Value++;
                    break;

                case PlayerTeam._WhiteTeam:
                    nl_WhiteTeamPoints.Value++;
                    break;
            }

            if (DebugOn) RunLog($"{team} points: {GetTeamPoints(team)}", nameof(IncrementWeekendBrawlTeamPointsServerRpc));
        }

        public int GetTeamPoints(PlayerTeam team)
        {
            return team switch
            {
              PlayerTeam._BlueTeam => nl_BlueTeamPoints.Value,
               PlayerTeam._RedTeam => nl_RedTeamPoints.Value,
                PlayerTeam._BlackTeam => nl_BlackTeamPoints.Value,
                PlayerTeam._WhiteTeam => nl_WhiteTeamPoints.Value,
                _ => 0
            };
        }
        #endregion

        // Only showing the changed method - rest of file stays the same

        #region Point Threshold Check (Match End Condition)
        /// <summary>
        /// Check if any team has reached the point threshold and end match if needed
        /// Called whenever team points change
        /// UPDATED: Now calls IGameManager.ForceEndMatch() instead of direct timer manipulation
        /// </summary>
        private void CheckTeamPointThreshold()
        {
            if (!IsServer) return;

            var currentMode = GetCurrentGameMode();

            // Survival mode doesn't end by points
            if (currentMode == MID_GameMatchMode._Survival)
            {
                return;
            }

            int threshold = GetPointThresholdForCurrentMode();

            bool shouldEndMatch = false;
            PlayerTeam winningTeam = PlayerTeam._BlueTeam;

            switch (currentMode)
            {
                case MID_GameMatchMode._WeekEndBrawl:
                    // Check all four teams
                    if (nl_BlueTeamPoints.Value >= threshold)
                    {
                        shouldEndMatch = true;
                        winningTeam = PlayerTeam._BlueTeam;
                    }
                    else if (nl_RedTeamPoints.Value >= threshold)
                    {
                        shouldEndMatch = true;
                        winningTeam = PlayerTeam._RedTeam;
                    }
                    else if (nl_BlackTeamPoints.Value >= threshold)
                    {
                        shouldEndMatch = true;
                        winningTeam = PlayerTeam._BlackTeam;
                    }
                    else if (nl_WhiteTeamPoints.Value >= threshold)
                    {
                        shouldEndMatch = true;
                        winningTeam = PlayerTeam._WhiteTeam;
                    }
                    break;

                default:
                    // Standard two-team modes
                    if (nl_BlueTeamPoints.Value >= threshold)
                    {
                        shouldEndMatch = true;
                        winningTeam = PlayerTeam._BlueTeam;
                    }
                    else if (nl_RedTeamPoints.Value >= threshold)
                    {
                        shouldEndMatch = true;
                        winningTeam = PlayerTeam._RedTeam;
                    }
                    break;
            }

            if (shouldEndMatch)
            {
                if (DebugOn) RunLog($"Point threshold reached! {winningTeam} wins with {GetTeamPoints(winningTeam)} points (threshold: {threshold})",
                    nameof(CheckTeamPointThreshold));

                // Call game manager to force end match
                if (_gameManager != null)
                {
                    _gameManager.ForceEndMatch();
                }
                else
                {
                    RunLogError("Cannot force end match - game manager is null!", nameof(CheckTeamPointThreshold));
                }
            }
        }

        #endregion

        #region Getters
        public int GetCurrentPlayerKills(ulong entityId)
        {
            return nd_PlayersKillStash.ContainsKey(entityId) ? nd_PlayersKillStash[entityId] : 0;
        }

        public int GetCurrentPlayerDeaths(ulong entityId)
        {
            return nd_PlayersDeathStash.ContainsKey(entityId) ? nd_PlayersDeathStash[entityId] : 0;
        }

        public int GetCurrentPlayerPoints(ulong entityId)
        {
            return nd_PlayersPointsStash.ContainsKey(entityId) ? nd_PlayersPointsStash[entityId] : 0;
        }

        public int GetCurrentBlueTeamPoints()
        {
            return nl_BlueTeamPoints.Value;
        }

        public int GetCurrentRedTeamPoints()
        {
            return nl_RedTeamPoints.Value;
        }

        public int GetSurvivalPoints(ulong playerId)
        {
            return nd_SurvivalPoints.ContainsKey(playerId) ? nd_SurvivalPoints[playerId] : 0;
        }
        #endregion

        #region Helper Methods
        private NetworkObject GetPlayerOrBotObject(ulong id)
        {
            if (IsBotId(id))
            {
                if (NetBotPlayerHandler.netBotHandlerSinglton.allSpawnedBots.TryGetValue(id, out NetworkObjectReference botRef))
                {
                    if (botRef.TryGet(out NetworkObject botObj))
                    {
                        return botObj;
                    }
                }
                return null;
            }
            else
            {
                if (NetworkManager.Singleton.ConnectedClients.TryGetValue(id, out var client))
                {
                    return client.PlayerObject;
                }
                return null;
            }
        }

        private static bool IsBotId(ulong id) => NetBotPlayerHandler.IsSpawnedBot(id);
        #endregion

        #region Logging
        private bool DebugOn => _logLevel >= MID_LogLevel.Debug;

        private void RunLog(string message, string methodName = "") =>
            MID_Logger.LogDebug(_logLevel, message, nameof(NetPointsHandler), methodName);

        private void RunLogWarning(string message, string methodName = "") =>
            MID_Logger.LogWarning(_logLevel, message, nameof(NetPointsHandler), methodName);

        private void RunLogError(string message, string methodName = "", Exception e = null) =>
            MID_Logger.LogError(_logLevel, message, nameof(NetPointsHandler), methodName, e);
        #endregion
    }
}
