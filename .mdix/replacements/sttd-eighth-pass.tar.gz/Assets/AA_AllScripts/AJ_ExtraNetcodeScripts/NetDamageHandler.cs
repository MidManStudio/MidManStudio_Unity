﻿// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/StickToTheDeath/bots.md and stickman-parts.md, section "NetDamageHandler.cs"
// ============================================================================
using UnityEngine;
using Unity.Netcode;
using MidManStudio.Core.Logging;
using MidManStudio.Sttd.InGame.NetworkDataStructures;
using MidManStudio.Sttd.InGame.GameItemData;
using MidManStudio.Sttd.InGame.GameModes.Survival;
using MidManStudio.Sttd.InGame.PsdRig;
using System;

namespace MidManStudio.Sttd.InGame.Setup
{
    /// <summary>
    /// Server-authoritative damage handler
    ///  Triggers damage flash/particles via ClientRpc on ALL clients
    /// </summary>
    [RequireComponent(typeof(NetworkObject))]
    public class NetDamageHandler : NetworkBehaviour
    {
        #region References
        private NetworkServerManeger _serverManager;
        private NetPointsHandler _pointsHandler;
        private NetRespawnHandler _respawnHandler;
        #endregion

        #region Configuration
        [Header("Debug Settings")]
        [SerializeField] private MID_LogLevel _logLevel = MID_LogLevel.Error;
        #endregion

        #region Survival Mode Integration
        private SurvivalModeHandler _cachedSurvivalHandler;
        private bool _survivalHandlerChecked = false;
        #endregion

        #region Initialization
        public void Initialize(NetworkServerManeger serverManager, NetPointsHandler pointsHandler, NetRespawnHandler respawnHandler)
        {
            _serverManager = serverManager;
            _pointsHandler = pointsHandler;
            _respawnHandler = respawnHandler;

            RunLog("NetDamageHandler initialized", nameof(Initialize));
        }
        #endregion

        #region Damage Request Handling
        public void ProcessDamageRequest(DoDamageRequest damageRequest)
        {
            if (!IsServer)
            {
                RunLogError("ProcessDamageRequest called on non-server!", nameof(ProcessDamageRequest));
                return;
            }

            try
            {
                if (DebugOn) RunLog($"Processing damage: Type={damageRequest.playerAndBotDamageType}, " +
                       $"Sender={damageRequest.damageSenderId}, Receiver={damageRequest.damageReciverId}, " +
                       $"Damage={damageRequest.damageAmt}", nameof(ProcessDamageRequest));

                // Survival enemies and summons are NetworkObjects of their own, not players or
                // bots, so they are routed before the player and bot receiver lookup below.
                switch (damageRequest.playerAndBotDamageType)
                {
                    case MID_PlayerAndBotDamageType.Player_Damage_SurvivalEnemy:
                    case MID_PlayerAndBotDamageType.Bot_Damage_SurvivalEnemy:
                    case MID_PlayerAndBotDamageType.Summon_Damage_SurvivalEnemy:
                        ValidateEntityRegistration(damageRequest.damageSenderId, "Sender");
                        HandleSurvivalEnemyDamage(damageRequest);
                        return;

                    case MID_PlayerAndBotDamageType.SurvivalEnemy_Damage_Summon:
                        HandleSummonDamage(damageRequest);
                        return;
                }

                var receiverObj = GetPlayerOrBotObject(damageRequest.damageReciverId);
                if (receiverObj == null)
                {
                    RunLogWarning($"Receiver {damageRequest.damageReciverId} not found - ignoring damage", nameof(ProcessDamageRequest));
                    return;
                }

                if (!receiverObj.TryGetComponent(out NetHealthComponent receiverHealth))
                {
                    RunLogError($"Receiver {damageRequest.damageReciverId} missing NetHealthComponent!", nameof(ProcessDamageRequest));
                    return;
                }

                if (receiverHealth.IsDead())
                {
                    if (DebugOn) RunLog($"Receiver {damageRequest.damageReciverId} is already dead - ignoring damage", nameof(ProcessDamageRequest));
                    return;
                }

                if (receiverHealth.IsSpawning())
                {
                    if (DebugOn) RunLog($"Receiver {damageRequest.damageReciverId} is spawning - ignoring damage", nameof(ProcessDamageRequest));
                    return;
                }

                ValidateEntityRegistration(damageRequest.damageSenderId, "Sender");
                ValidateEntityRegistration(damageRequest.damageReciverId, "Receiver");

                switch (damageRequest.playerAndBotDamageType)
                {
                    case MID_PlayerAndBotDamageType.Player_Damage_Player:
                    case MID_PlayerAndBotDamageType.Player_Damage_Bot:
                    case MID_PlayerAndBotDamageType.Bot_Damage_Player:
                    case MID_PlayerAndBotDamageType.Bot_Damage_Bot:
                        HandleRegularMatchDamage(damageRequest, receiverObj, receiverHealth);
                        break;

                    case MID_PlayerAndBotDamageType.SelfHarm:
                        HandleSelfHarmDamage(damageRequest);
                        break;

                    case MID_PlayerAndBotDamageType.SurvivalEnemy_Damage_Player:
                    case MID_PlayerAndBotDamageType.SurvivalEnemy_Damage_Bot:
                        HandleSurvivalPlayerDamage(damageRequest);
                        break;

                    case MID_PlayerAndBotDamageType.Environmental_Damage:
                        HandleEnvironmentalDamage(damageRequest);
                        break;

                    default:
                        RunLogError($"Unknown damage type: {damageRequest.playerAndBotDamageType}",
                            nameof(ProcessDamageRequest));
                        break;
                }
            }
            catch (Exception e)
            {
                RunLogError($"Exception processing damage request", nameof(ProcessDamageRequest), e);
            }
        }
        #endregion

        #region Regular Match Damage (Players & Bots)
        private void HandleRegularMatchDamage(DoDamageRequest damageRequest, NetworkObject receiverObj,
            NetHealthComponent receiverHealth)
        {
            NetworkObject senderObj = GetPlayerOrBotObject(damageRequest.damageSenderId);

            if (senderObj == null)
            {
                RunLogWarning("Null player objects in regular match damage", nameof(HandleRegularMatchDamage));
                return;
            }

            if (!senderObj.TryGetComponent(out IAmPlayerServiceLocator senderRefs) ||
                !receiverObj.TryGetComponent(out IAmPlayerServiceLocator receiverRefs))
            {
                RunLogError("Missing required components", nameof(HandleRegularMatchDamage));
                return;
            }

            // Team gate. Weapons check teams on their own, but grenades and particle damagers
            // never did, so the server decides here for every source. Damage a player or bot
            // deals to itself is not a team question and passes. NetTeamRules makes Free For All
            // an everyone-versus-everyone mode and Survival a single side.
            if (damageRequest.damageSenderId != damageRequest.damageReciverId && !AreEnemies(senderRefs, receiverRefs))
            {
                if (DebugOn) RunLog($"Damage from {damageRequest.damageSenderId} to {damageRequest.damageReciverId} blocked by the team gate",
                    nameof(HandleRegularMatchDamage));
                return;
            }

            // Apply damage via NetHealthComponent (server-authoritative)
            int damage = (int)damageRequest.damageAmt;
            bool died = receiverHealth.ApplyDamage(damage);

            // CRITICAL: Trigger damage flash and particles on ALL clients
            TriggerDamageVisualsClientRpc(new NetworkObjectReference(receiverObj));

            if (died)
            {
                if (TryInterceptSurvivalDeath(damageRequest.damageReciverId, damageRequest))
                {
                    if (DebugOn) RunLog($"Survival mode intercepted death for {damageRequest.damageReciverId}",
                        nameof(HandleRegularMatchDamage));
                    return;
                }

                // An entity that kills itself with a regular damage source (its own grenade) is a
                // suicide. It gets no kill, no points and no team point.
                if (damageRequest.damageSenderId == damageRequest.damageReciverId)
                    HandleSelfKill(receiverRefs, damageRequest);
                else
                    HandlePlayerKill(senderRefs, receiverRefs, damageRequest);
            }
        }
        #endregion

        #region Self-Harm Damage
        private void HandleSelfHarmDamage(DoDamageRequest damageRequest)
        {
            ulong victimId = damageRequest.damageReciverId;
            var victimObj = GetPlayerOrBotObject(victimId);

            if (victimObj == null)
            {
                RunLogWarning($"Victim {victimId} not found for self-harm", nameof(HandleSelfHarmDamage));
                return;
            }

            var victimRefs = victimObj.GetComponent<IAmPlayerServiceLocator>();
            var victimHealth = victimObj.GetComponent<NetHealthComponent>();

            if (victimRefs == null || victimHealth == null)
            {
                RunLogError($"Victim {victimId} missing required components", nameof(HandleSelfHarmDamage));
                return;
            }

            if (victimHealth.IsDead())
            {
                if (DebugOn) RunLog($"Victim {victimId} already dead - ignoring self-harm", nameof(HandleSelfHarmDamage));
                return;
            }

            if (DebugOn) RunLog($"Player/Bot {victimId} self-harm damage: {damageRequest.damageAmt}",
                nameof(HandleSelfHarmDamage));

            int damage = (int)damageRequest.damageAmt;
            bool died = victimHealth.ApplyDamage(damage);

            // CRITICAL: Trigger damage flash and particles on ALL clients
            TriggerDamageVisualsClientRpc(new NetworkObjectReference(victimObj));

            if (died)
            {
                if (TryInterceptSurvivalDeath(victimId, damageRequest))
                {
                    if (DebugOn) RunLog($"Survival mode intercepted self-harm death for {victimId}",
                        nameof(HandleSelfHarmDamage));
                    return;
                }

                HandleSelfKill(victimRefs, damageRequest);
            }
        }

        private void HandleSelfKill(IAmPlayerServiceLocator victimRefs, DoDamageRequest damageRequest)
        {
            ulong victimId = victimRefs.get__MID__PlayerOrBotOwnerId;

            _serverManager.SpawnRagDoll(victimRefs, damageRequest.wasBlownUp, damageRequest.explosionPoint);
            DisablePlayerComponentsClientRpc(new NetworkObjectReference(victimRefs.GetComponent<NetworkObject>()));

            _pointsHandler.IncrementDeath(victimId);
            _pointsHandler.IncrementPlayerDeathStreek(victimId);
            _pointsHandler.ResetPlayerKillStreek(victimId);

            if (damageRequest.whatWeaponDamagedPlayer == MID_WhatWeaponDamagedPlayer.Gun ||
                damageRequest.whatWeaponDamagedPlayer == MID_WhatWeaponDamagedPlayer.Grenade)
            {
                BroadcastSuicideMessage(victimRefs);
            }

            if (DebugOn) RunLog($"Self-kill registered for {victimId}", nameof(HandleSelfKill));
        }

        private void BroadcastSuicideMessage(IAmPlayerServiceLocator victimRefs)
        {
            var suicideMessage = new WhoKilledWho
            {
                weaponSpriteAtlasId = "PLAYER_HUD_SPRITE_ATLAS",
                weaponSpriteName = "SkullIcon",
                killerName = victimRefs?.GetUserName() ?? "Unknown",
                victimName = "themselves",
                sparkEffectIndex = 0
            };

            _serverManager.BrodCastWhoKilledWhoClientRpc(suicideMessage);
        }
        #endregion

        #region Survival Enemy Damage
        private void HandleSurvivalEnemyDamage(DoDamageRequest damageRequest)
        {
            if (!NetworkManager.Singleton.SpawnManager.SpawnedObjects.TryGetValue(
                damageRequest.damageReciverId, out NetworkObject enemyObj))
            {
                RunLogWarning($"Survival enemy {damageRequest.damageReciverId} not found",
                    nameof(HandleSurvivalEnemyDamage));
                return;
            }

            var enemyHealth = enemyObj.GetComponent<MidManStudio.Sttd.InGame.AI.NetAiHealthHandler>();
            var enemyBase = enemyObj.GetComponent<MidManStudio.Sttd.InGame.AI.NetAiBase>();

            if (enemyHealth == null || enemyBase == null)
            {
                RunLogError($"Survival enemy {damageRequest.damageReciverId} missing components",
                    nameof(HandleSurvivalEnemyDamage));
                return;
            }

            if (enemyHealth.IsDead())
            {
                RunLog("Enemy already dead - ignoring damage", nameof(HandleSurvivalEnemyDamage));
                return;
            }

            enemyHealth.TakeDamage(damageRequest);

            if (enemyHealth.IsDead())
            {
                ulong killerId = damageRequest.damageSenderId;

                if (damageRequest.playerAndBotDamageType == MID_PlayerAndBotDamageType.Summon_Damage_SurvivalEnemy)
                {
                    if (NetworkManager.Singleton.SpawnManager.SpawnedObjects.TryGetValue(
                        damageRequest.damageSenderId, out NetworkObject summonObj))
                    {
                        // TODO: Get summon owner ID
                    }
                }

                if (TryGetSurvivalHandler(out SurvivalModeHandler survivalHandler))
                {
                    var pointManager = survivalHandler.GetPointManager();
                    var roundManager = survivalHandler.GetRoundManager();

                    if (pointManager != null && roundManager != null)
                    {
                        pointManager.AwardPointsForKill(
                            killerId,
                            enemyBase.GetEntityClass(),
                            roundManager.GetCurrentRound()
                        );

                        if (DebugOn) RunLog($"Survival enemy killed - points awarded via SurvivalPointManager",
                            nameof(HandleSurvivalEnemyDamage));
                    }
                }
                else
                {
                    RunLogWarning("Enemy killed but survival mode not active!",
                        nameof(HandleSurvivalEnemyDamage));
                }
            }
        }
        #endregion

        #region Survival Player Damage
        private void HandleSurvivalPlayerDamage(DoDamageRequest damageRequest)
        {
            var victimObj = GetPlayerOrBotObject(damageRequest.damageReciverId);

            if (victimObj == null)
            {
                RunLogWarning($"Victim {damageRequest.damageReciverId} not found",
                    nameof(HandleSurvivalPlayerDamage));
                return;
            }

            var victimRefs = victimObj.GetComponent<IAmPlayerServiceLocator>();
            var victimHealth = victimObj.GetComponent<NetHealthComponent>();

            if (victimRefs == null || victimHealth == null)
            {
                RunLogError($"Victim missing required components", nameof(HandleSurvivalPlayerDamage));
                return;
            }

            if (victimHealth.IsDead())
            {
                RunLog("Victim already dead - ignoring damage", nameof(HandleSurvivalPlayerDamage));
                return;
            }

            int damage = (int)damageRequest.damageAmt;
            bool died = victimHealth.ApplyDamage(damage);

            // CRITICAL: Trigger damage flash and particles on ALL clients
            TriggerDamageVisualsClientRpc(new NetworkObjectReference(victimObj));

            if (died)
            {
                if (TryInterceptSurvivalDeath(damageRequest.damageReciverId, damageRequest))
                {
                    if (DebugOn) RunLog($"Survival mode intercepted death for {damageRequest.damageReciverId}",
                        nameof(HandleSurvivalPlayerDamage));
                    return;
                }

                HandlePlayerDeathFallback(victimRefs, damageRequest);
            }
        }

        private void HandlePlayerDeathFallback(IAmPlayerServiceLocator victimRefs, DoDamageRequest damageRequest)
        {
            ulong victimId = victimRefs.get__MID__PlayerOrBotOwnerId;

            _serverManager.SpawnRagDoll(victimRefs, damageRequest.wasBlownUp, damageRequest.explosionPoint);
            DisablePlayerComponentsClientRpc(new NetworkObjectReference(victimRefs.GetComponent<NetworkObject>()));

            _pointsHandler.IncrementDeath(victimId);

            if (DebugOn) RunLog($"Player {victimId} died (fallback handling)", nameof(HandlePlayerDeathFallback));
        }
        #endregion

        #region Survival Mode Integration
        private bool TryInterceptSurvivalDeath(ulong victimId, DoDamageRequest damageRequest)
        {
            if (!IsServer) return false;

            if (!TryGetSurvivalHandler(out SurvivalModeHandler survivalHandler))
                return false;

            if (!survivalHandler.IsSurvivalActive())
                return false;

            if (DebugOn) RunLog($"Intercepting death for survival mode - putting player {victimId} into downed state",
                nameof(TryInterceptSurvivalDeath));

            var playerManager = survivalHandler.GetPlayerManager();
            if (playerManager == null)
            {
                RunLogError("SurvivalPlayerManager not found!", nameof(TryInterceptSurvivalDeath));
                return false;
            }

            var victimObj = GetPlayerOrBotObject(victimId);
            if (victimObj != null)
            {
                DisablePlayerComponentsClientRpc(new NetworkObjectReference(victimObj));
            }

            playerManager.HandlePlayerDowned(victimId);

            return true;
        }

        private bool TryGetSurvivalHandler(out SurvivalModeHandler handler)
        {
            handler = null;

            if (_survivalHandlerChecked && _cachedSurvivalHandler != null)
            {
                handler = _cachedSurvivalHandler;
                return true;
            }

            if (GameSetupCoordinator.HasInstance)
            {
                var gameModeHandler = GameSetupCoordinator.Instance.GetGameModeHandler();
                if (gameModeHandler is SurvivalModeHandler survival)
                {
                    _cachedSurvivalHandler = survival;
                    _survivalHandlerChecked = true;
                    handler = survival;
                    return true;
                }
            }

            _survivalHandlerChecked = true;
            return false;
        }

        public void ClearSurvivalHandlerCache()
        {
            _cachedSurvivalHandler = null;
            _survivalHandlerChecked = false;
        }
        #endregion

        #region Summon Damage
        private void HandleSummonDamage(DoDamageRequest damageRequest)
        {
            if (!NetworkManager.Singleton.SpawnManager.SpawnedObjects.TryGetValue(
                damageRequest.damageReciverId, out NetworkObject summonObj))
            {
                RunLogWarning($"Summon {damageRequest.damageReciverId} not found", nameof(HandleSummonDamage));
                return;
            }

            var summonHealth = summonObj.GetComponent<MidManStudio.Sttd.InGame.AI.NetAiHealthHandler>();

            if (summonHealth == null)
            {
                RunLogError($"Summon missing health handler", nameof(HandleSummonDamage));
                return;
            }

            if (summonHealth.IsDead())
            {
                RunLog("Summon already dead - ignoring damage", nameof(HandleSummonDamage));
                return;
            }

            summonHealth.TakeDamage(damageRequest);

            if (DebugOn) RunLog($"Summon {damageRequest.damageReciverId} took {damageRequest.damageAmt} damage",
                nameof(HandleSummonDamage));
        }
        #endregion

        #region Status Effect Damage
        /// <summary>
        /// SERVER ONLY: One damage tick of a status effect. The entity that applied the effect gets the
        /// kill credit through the normal damage path, so a burn death counts like any other kill. When
        /// that entity is gone the tick is environmental and credits nobody, and an entity that burns
        /// itself dies as a suicide.
        /// </summary>
        public void ApplyStatusEffectDamage(ulong ownerId, ulong victimId, int amount)
        {
            if (!IsServer || amount <= 0) return;

            MID_PlayerAndBotDamageType damageType;

            if (ownerId == victimId)
            {
                damageType = MID_PlayerAndBotDamageType.SelfHarm;
            }
            else if (GetPlayerOrBotObject(ownerId) == null)
            {
                damageType = MID_PlayerAndBotDamageType.Environmental_Damage;
            }
            else
            {
                damageType = GetRegularDamageType(ownerId, victimId);
            }

            var killType = new MID_PlayerKillTypeAndPoints { _playerKillType = MID_PlayerKillType.Killer, _valueInPoints = 100 };

            ProcessDamageRequest(new DoDamageRequest(amount, ownerId, victimId, false, damageType, killType,
                MID_WhatWeaponDamagedPlayer.Grenade, null));
        }

        /// <summary>
        /// The regular match damage type between two entities, from the bot flag of each. Summons and
        /// status effects send their damage in the name of their owner and use this.
        /// </summary>
        public static MID_PlayerAndBotDamageType GetRegularDamageType(ulong senderId, ulong victimId)
        {
            bool senderIsBot = NetBotPlayerHandler.IsSpawnedBot(senderId);
            bool victimIsBot = NetBotPlayerHandler.IsSpawnedBot(victimId);

            return (senderIsBot, victimIsBot) switch
            {
                (false, false) => MID_PlayerAndBotDamageType.Player_Damage_Player,
                (false, true)  => MID_PlayerAndBotDamageType.Player_Damage_Bot,
                (true, false)  => MID_PlayerAndBotDamageType.Bot_Damage_Player,
                _              => MID_PlayerAndBotDamageType.Bot_Damage_Bot
            };
        }
        #endregion

        #region Environmental Damage
        /// <summary>
        /// SERVER ONLY: Damage from the map itself, such as the death boundary. A death from it counts
        /// for the victim, spawns the ragdoll, and credits nobody.
        /// </summary>
        public void ApplyEnvironmentalDamage(ulong victimId, int amount)
        {
            if (!IsServer || amount <= 0) return;

            ProcessDamageRequest(new DoDamageRequest(amount, victimId, victimId, false,
                MID_PlayerAndBotDamageType.Environmental_Damage, default, MID_WhatWeaponDamagedPlayer.Melee, null));
        }

        private void HandleEnvironmentalDamage(DoDamageRequest damageRequest)
        {
            damageRequest.playerAndBotDamageType = MID_PlayerAndBotDamageType.SelfHarm;
            HandleSelfHarmDamage(damageRequest);

            if (DebugOn) RunLog($"Environmental damage processed as self-harm", nameof(HandleEnvironmentalDamage));
        }
        #endregion

        #region Kill Handling
        private void HandlePlayerKill(IAmPlayerServiceLocator senderRefs, IAmPlayerServiceLocator receiverRefs,
            DoDamageRequest damageRequest)
        {
            try
            {
                if (DebugOn) RunLog($"Processing kill - Killer:{damageRequest.damageSenderId}, Victim:{damageRequest.damageReciverId}",
                    nameof(HandlePlayerKill));

                _serverManager.SpawnRagDoll(receiverRefs, damageRequest.wasBlownUp, damageRequest.explosionPoint);
                DisablePlayerComponentsClientRpc(new NetworkObjectReference(receiverRefs.GetComponent<NetworkObject>()));

                _pointsHandler.ProcessKillRewards(senderRefs, damageRequest.damageSenderId, damageRequest.playerKillTypeAndPoints);
                _pointsHandler.UpdatePlayerStats(damageRequest.damageSenderId, damageRequest.damageReciverId);
                _pointsHandler.AwardKillTeamPoint(senderRefs.get_PlayerTeamHandler.m_PlayerTeam.Value);

                _serverManager.BroadcastKillMessage(senderRefs, receiverRefs, damageRequest.whatWeaponDamagedPlayer);

                if (!NetBotPlayerHandler.IsSpawnedBot(damageRequest.damageSenderId) && CameraShakeManager.HasInstance)
                {
                    _serverManager.ShakeOnKillClientRpc(damageRequest.damageSenderId);
                }

                RunLog("Kill processed successfully", nameof(HandlePlayerKill));
            }
            catch (Exception e)
            {
                RunLogError("Exception in HandlePlayerKill", nameof(HandlePlayerKill), e);
            }
        }
        #endregion

        #region Damage Visuals ClientRpc - NEW
        /// <summary>
        /// CRITICAL: Trigger damage flash and particles on ALL clients
        /// Called when any player/bot takes damage (not healing)
        /// </summary>
        [ClientRpc]
        private void TriggerDamageVisualsClientRpc(NetworkObjectReference victimRef)
        {
            if (!victimRef.TryGet(out NetworkObject victimObj))
            {
                RunLogWarning("Failed to get victim object for damage visuals", nameof(TriggerDamageVisualsClientRpc));
                return;
            }

            var playerRefs = victimObj.GetComponent<IAmPlayerServiceLocator>();
            if (playerRefs == null)
            {
                RunLogWarning("Victim missing service locator", nameof(TriggerDamageVisualsClientRpc));
                return;
            }

            // Trigger damage flash
            if (playerRefs.get_DamageFlash != null)
            {
                playerRefs.get_DamageFlash.TriggerDamageFlash();
            }

            // Spawn damage particles
            if (playerRefs.get_DamageParticles != null)
            {
                playerRefs.get_DamageParticles.SpawnDamageParticle();
            }

            if (DebugOn) RunLog($"Damage visuals triggered for player {victimObj.OwnerClientId}", nameof(TriggerDamageVisualsClientRpc));
        }
        #endregion

        #region Component Enable/Disable (ClientRpc)
        /// <summary>
        /// Starts the in-place rig ragdoll on every client. The server sends it just before
        /// DisablePlayerComponentsClientRpc, which then leaves the renderers on for a ragdolling player.
        /// </summary>
        [ClientRpc]
        public void StartRigRagdollClientRpc(NetworkObjectReference playerRef, Vector2 impulse)
        {
            if (!playerRef.TryGet(out NetworkObject playerObj)) return;

            var rigRagdoll = playerObj.GetComponentInChildren<StickmanRigRagdoll>(true);
            if (rigRagdoll != null) rigRagdoll.Activate(impulse);
        }

        [ClientRpc]
        private void DisablePlayerComponentsClientRpc(NetworkObjectReference playerRef)
        {
            if (!playerRef.TryGet(out NetworkObject playerObj))
            {
                RunLogWarning("Failed to get player object for disabling", nameof(DisablePlayerComponentsClientRpc));
                return;
            }

            var playerRefs = playerObj.GetComponent<IAmPlayerServiceLocator>();
            if (playerRefs == null)
            {
                RunLogWarning("Player missing service locator", nameof(DisablePlayerComponentsClientRpc));
                return;
            }

            var rb = playerObj.GetComponent<Rigidbody2D>();
            if (rb != null) rb.simulated = false;

            var collider = playerObj.GetComponent<Collider2D>();
            if (collider != null) collider.enabled = false;

            // A rig ragdoll is the visible corpse, so the renderers stay on for it
            var activeRagdoll = playerObj.GetComponentInChildren<StickmanRigRagdoll>(true);
            if (activeRagdoll == null || !activeRagdoll.IsActive)
            {
                foreach (var sprite in playerObj.GetComponentsInChildren<SpriteRenderer>())
                {
                    sprite.enabled = false;
                }
            }

            if (playerRefs.get_PlayerController != null)
            {
                playerRefs.get_PlayerController.enabled = false;
            }

            if (playerRefs.get_PlayerArmHandler != null)
            {
                playerRefs.get_PlayerArmHandler.enabled = false;
            }

            if (playerRefs.get_NetWeaponCategorizer != null)
            {
                playerRefs.get_NetWeaponCategorizer.enabled = false;
            }

            if (playerRefs.get_JetpackHandlerScript != null)
            {
                playerRefs.get_JetpackHandlerScript.gameObject.SetActive(false);
            }

            if (DebugOn) RunLog($"Disabled components for player {playerObj.OwnerClientId}", nameof(DisablePlayerComponentsClientRpc));
        }

        [ClientRpc]
        public void EnablePlayerComponentsClientRpc(NetworkObjectReference playerRef)
        {
            if (!playerRef.TryGet(out NetworkObject playerObj))
            {
                RunLogWarning("Failed to get player object for enabling", nameof(EnablePlayerComponentsClientRpc));
                return;
            }

            var playerRefs = playerObj.GetComponent<IAmPlayerServiceLocator>();
            if (playerRefs == null)
            {
                RunLogWarning("Player missing service locator", nameof(EnablePlayerComponentsClientRpc));
                return;
            }

            // End a rig ragdoll first so the bind pose is back before the rig is shown again
            var rigRagdoll = playerObj.GetComponentInChildren<StickmanRigRagdoll>(true);
            bool wasRagdolled = rigRagdoll != null && rigRagdoll.IsActive;
            if (rigRagdoll != null) rigRagdoll.Deactivate();

            // The ragdoll aftermath dissolved the body away, so it materializes again like a first spawn
            if (wasRagdolled && playerRefs.get_PlayerInitializer != null)
            {
                playerRefs.get_PlayerInitializer.ZeroOutAndUnDissolve();
            }

            var rb = playerObj.GetComponent<Rigidbody2D>();
            if (rb != null)
            {
                rb.simulated = true;
                rb.WakeUp();
            }

            var collider = playerObj.GetComponent<Collider2D>();
            if (collider != null) collider.enabled = true;

            foreach (var sprite in playerObj.GetComponentsInChildren<SpriteRenderer>())
            {
                sprite.enabled = true;
            }

            if (playerRefs.get_PlayerController != null)
            {
                playerRefs.get_PlayerController.enabled = true;
            }

            if (playerRefs.get_PlayerArmHandler != null)
            {
                playerRefs.get_PlayerArmHandler.enabled = true;
            }

            if (playerRefs.get_NetWeaponCategorizer != null)
            {
                playerRefs.get_NetWeaponCategorizer.enabled = true;

                if (playerObj.IsOwner)
                {
                    playerRefs.get_NetWeaponCategorizer.CallQuickSwitch();
                }
            }

            if (playerRefs.get_JetpackHandlerScript != null)
            {
                playerRefs.get_JetpackHandlerScript.gameObject.SetActive(true);
            }

            if (DebugOn) RunLog($"Enabled components for player {playerObj.OwnerClientId}", nameof(EnablePlayerComponentsClientRpc));
        }
        #endregion

        #region Helper Methods
        private NetworkObject GetPlayerOrBotObject(ulong id)
        {
            if (NetBotPlayerHandler.IsSpawnedBot(id))
            {
                if (NetBotPlayerHandler.netBotHandlerSinglton.allSpawnedBots.TryGetValue(id, out NetworkObjectReference botRef)
                    && botRef.TryGet(out NetworkObject botObj))
                {
                    return botObj;
                }
                return null;
            }

            if (NetworkManager.Singleton.ConnectedClients.TryGetValue(id, out var client))
            {
                return client.PlayerObject;
            }
            return null;
        }

        private void ValidateEntityRegistration(ulong entityId, string context)
        {
            if (!_pointsHandler.IsEntityRegistered(entityId))
            {
                RunLogWarning($"{context} {entityId} not registered - auto-registering",
                    nameof(ValidateEntityRegistration));
                _pointsHandler.AddEntityToAllDictionaries(entityId);
            }
        }

        private static bool AreEnemies(IAmPlayerServiceLocator a, IAmPlayerServiceLocator b) =>
            NetTeamRules.AreEnemies(a, b);
        #endregion

        #region Logging
        private bool DebugOn => _logLevel >= MID_LogLevel.Debug;

        private void RunLog(string message, string methodName = "") =>
            MID_Logger.LogDebug(_logLevel, message, nameof(NetDamageHandler), methodName);

        private void RunLogWarning(string message, string methodName = "") =>
            MID_Logger.LogWarning(_logLevel, message, nameof(NetDamageHandler), methodName);

        private void RunLogError(string message, string methodName = "", Exception e = null) =>
            MID_Logger.LogError(_logLevel, message, nameof(NetDamageHandler), methodName, e);
        #endregion
    }
}
