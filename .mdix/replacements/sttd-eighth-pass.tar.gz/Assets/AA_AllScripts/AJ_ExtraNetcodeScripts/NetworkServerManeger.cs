﻿// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/StickToTheDeath/bots.md and stickman-parts.md, section "NetworkServerManeger.cs"
// ============================================================================
using System;
using System.Collections.Generic;
using UnityEngine;
using Unity.Netcode;
using Unity.Collections;
using MidManStudio.Sttd.InGame.GameItemData;
using MidManStudio.Sttd.InGame.NetworkDataStructures;
using MidManStudio.Core.Logging;
using LobbyRelaySample;
using MidManStudio.Sttd.InGame.Setup;
using System.Linq;
using MidManStudio.Sttd.InGame.GameItemData.Netcode;
using MidManStudio.InGame.SharedSetup;
using MidManStudio.Sttd.InGame.PsdRig;

/// <summary>
/// Central coordinator for server-authoritative game logic
/// Delegates to specialized handlers:
/// - NetRespawnHandler: Player/bot respawning
/// - NetPointsHandler: Points, kills, deaths, stats
/// - NetDamageHandler: Damage processing and kill logic
/// - NetEqItemSpawner: Equipment and weapon spawning
/// - NetTeamHandler: Team Assignments and handling
/// - NetTimeHandler: Match timer management
/// 
/// NetworkServerManager coordinates between handlers and provides:
/// - Team management
/// - Spawn point management
/// - Ragdoll spawning
/// - Kill feed broadcasting
/// - Map/mode awareness
/// </summary>
[RequireComponent(typeof(NetworkObject))]
[RequireComponent(typeof(NetRespawnHandler))]
[RequireComponent(typeof(NetPointsHandler))]
[RequireComponent(typeof(NetDamageHandler))]
[RequireComponent(typeof(NetEqItemSpawner))]
[RequireComponent(typeof(NetTeamHandler))]
[RequireComponent(typeof(NetTimeHandler))]
public class NetworkServerManeger : NetworkBehaviour
{
    #region Singleton
    public static NetworkServerManeger networkServerSingleton { get; private set; }
    #endregion

    #region Handler References
    [Header("Handler Components")]
    internal NetRespawnHandler _respawnHandler;
    internal NetPointsHandler _pointsHandler;
    internal NetDamageHandler _damageHandler;
    internal NetEqItemSpawner _eqItemSpawner;
    internal NetTeamHandler _teamHandler;
    internal NetTimeHandler _timeHandler;
    #endregion

    #region Configuration
    [Header("Debug Settings")]
    [SerializeField] private MID_LogLevel _logLevel = MID_LogLevel.Error;

    [Header("Ragdoll Prefab")]
    [SerializeField] private NetworkObject net_RagDoll;
    #endregion

    #region Spawn Points
    [Header("Spawn Point Management")]
    public List<Transform> allBlueTeamSpawnPoints = new List<Transform>();
    public List<Transform> allRedTeamSpawnPoints = new List<Transform>();
    public List<Transform> allFFRSpawnPoints = new List<Transform>();

    public LayerMask playerLayer;
    public float respawnRadius = 0.5f;
    #endregion

    #region Score Summons
    [Header("Score Summons")]
    public Transform blackPheonixInitialPoint;
    public Transform blackPheonixEndPoint;
    #endregion

    #region Game Mode Context
    private MID_GameMatchMode _currentGameMode;
    #endregion

    #region Initialization

    private void Awake()
    {
        NativeLeakDetection.Mode = NativeLeakDetectionMode.EnabledWithStackTrace;

        if (networkServerSingleton != null && networkServerSingleton != this)
        {
            Destroy(this);
        }
        else
        {
            networkServerSingleton = this;
        }
    }

    public override void OnNetworkSpawn()
    {
        base.OnNetworkSpawn();

        // Get handler references
        _respawnHandler = GetComponent<NetRespawnHandler>();
        _pointsHandler = GetComponent<NetPointsHandler>();
        _damageHandler = GetComponent<NetDamageHandler>();
        _eqItemSpawner = GetComponent<NetEqItemSpawner>();
        _teamHandler = GetComponent<NetTeamHandler>();
        _timeHandler = GetComponent<NetTimeHandler>();

        if (IsServer)
        {
            // Initialize handlers
            _respawnHandler.Initialize(this, _pointsHandler);
            _pointsHandler.Initialize(this);
            _damageHandler.Initialize(this, _pointsHandler, _respawnHandler);
            _eqItemSpawner.Initialize(this);

            RunLog("NetworkServerManager initialized with all handlers", nameof(OnNetworkSpawn));
        }

        if (!IsServer)
        {
            NetworkManager.Singleton.OnClientConnectedCallback += NetworkManeger_OnClientConnectedCallBack;
            NetworkManager.Singleton.OnClientDisconnectCallback += NetworkManeger_OnClientDisConnectedCallBack;
        }
    }

    public override void OnNetworkDespawn()
    {
        if (!IsServer)
        {
            NetworkManager.Singleton.OnClientConnectedCallback -= NetworkManeger_OnClientConnectedCallBack;
            NetworkManager.Singleton.OnClientDisconnectCallback -= NetworkManeger_OnClientDisConnectedCallBack;
        }

        base.OnNetworkDespawn();
    }

    /// <summary>
    /// Initialize with game mode - called by GameSetupCoordinator or GameManager
    /// </summary>
    public void InitializeWithGameMode(MID_GameMatchMode gameMode)
    {
        _currentGameMode = gameMode;

        // Initialize team handler with game mode
        _teamHandler.Initialize(gameMode);

        // Initialize time handler with game mode
        _timeHandler.Initialize(this, gameMode);

        if (DebugOn) RunLog($"NetworkServerManager initialized with game mode: {gameMode}", nameof(InitializeWithGameMode));
    }

    #endregion

    #region Network Callbacks

    private void NetworkManeger_OnClientConnectedCallBack(ulong clientId)
    {
        if (IsServer)
        {
            if (DebugOn) RunLog($"Client {clientId} connected", nameof(NetworkManeger_OnClientConnectedCallBack));
        }
    }

    private void NetworkManeger_OnClientDisConnectedCallBack(ulong clientId)
    {
        if (DebugOn) RunLog($"Client {clientId} disconnected", nameof(NetworkManeger_OnClientDisConnectedCallBack));
    }

    #endregion

    #region Entity Registration (Delegates to PointsHandler)

    /// <summary>
    /// Register player/bot in all tracking systems
    /// Delegates to NetPointsHandler
    /// </summary>
    [ServerRpc(RequireOwnership = false)]
    public void AddPlayerToKillPointsAndDeathDictionaryServerRpc(ulong _clientId, ServerRpcParams serverRpcParams = default)
    {
        if (!IsServer) return;

        // The server registers bots and the host locally. A remote client may only register itself.
        ulong senderId = serverRpcParams.Receive.SenderClientId;
        if (senderId != NetworkManager.ServerClientId && senderId != _clientId)
        {
            MID_Logger.LogWarning(MID_LogLevel.Info, $"Client {senderId} tried to register {_clientId}, rejected",
                nameof(NetworkServerManeger), nameof(AddPlayerToKillPointsAndDeathDictionaryServerRpc));
            return;
        }

        _pointsHandler.AddEntityToAllDictionaries(_clientId);

        string entityType = IsBotId(_clientId) ? "bot" : "player";
        if (DebugOn) RunLog($"Server added {entityType} {_clientId} to tracking systems",
            nameof(AddPlayerToKillPointsAndDeathDictionaryServerRpc));
    }

    #endregion

    #region Damage Handling (Delegates to DamageHandler)

    /// <summary>
    /// Process damage request
    /// Delegates to NetDamageHandler
    /// </summary>
    /// <remarks>
    /// Open to every client, because melee and power weapon hits are reported by the owning
    /// client. Server code (projectiles, grenades, bots, the host player) calls it locally
    /// and is trusted. A remote client is checked by <see cref="IsDamageRequestAllowed"/>.
    /// </remarks>
    [ServerRpc(RequireOwnership = false)]
    public void DoDamageRequestServerRpc(DoDamageRequest damageRequest, ServerRpcParams serverRpcParams = default)
    {
        if (!IsServer) return;

        if (!IsDamageRequestAllowed(damageRequest, serverRpcParams.Receive.SenderClientId)) return;

        _damageHandler.ProcessDamageRequest(damageRequest);
    }

    // A remote client may only report damage that its own player dealt: the sender id has to
    // be the client id, and the type has to be one where a player attacks. The damage amount
    // still comes from the client, the server has no weapon data to check it against.
    private bool IsDamageRequestAllowed(DoDamageRequest request, ulong senderClientId)
    {
        if (senderClientId == NetworkManager.ServerClientId) return true;

        if (request.damageSenderId != senderClientId)
        {
            MID_Logger.LogWarning(MID_LogLevel.Info,
                $"Client {senderClientId} sent damage as {request.damageSenderId}, rejected",
                nameof(NetworkServerManeger), nameof(DoDamageRequestServerRpc));
            return false;
        }

        switch (request.playerAndBotDamageType)
        {
            case MID_PlayerAndBotDamageType.Player_Damage_Player:
            case MID_PlayerAndBotDamageType.Player_Damage_Bot:
            case MID_PlayerAndBotDamageType.Player_Damage_SurvivalEnemy:
                return true;

            case MID_PlayerAndBotDamageType.SelfHarm:
                return request.damageReciverId == senderClientId;

            default:
                MID_Logger.LogWarning(MID_LogLevel.Info,
                    $"Client {senderClientId} sent damage type {request.playerAndBotDamageType}, rejected",
                    nameof(NetworkServerManeger), nameof(DoDamageRequestServerRpc));
                return false;
        }
    }

    #endregion

    #region Respawn Handling (Delegates to RespawnHandler)

    /// <summary>
    /// Request respawn for player/bot
    /// Delegates to NetRespawnHandler
    /// </summary>
    [ServerRpc(RequireOwnership = false)]
    public void RequestRespawnServerRpc(ulong playerId, ServerRpcParams serverRpcParams = default)
    {
        if (!IsServer) return;

        // A remote client may only ask for the respawn of its own player, never of a bot or
        // another player. Server code (bots, the host) calls this locally and is trusted.
        ulong senderClientId = serverRpcParams.Receive.SenderClientId;
        if (senderClientId != NetworkManager.ServerClientId &&
            (playerId != senderClientId || NetBotPlayerHandler.IsSpawnedBot(playerId)))
        {
            MID_Logger.LogWarning(MID_LogLevel.Info,
                $"Client {senderClientId} asked for the respawn of {playerId}, rejected",
                nameof(NetworkServerManeger), nameof(RequestRespawnServerRpc));
            return;
        }

        _respawnHandler.ProcessRespawnRequest(playerId);
    }

    /// <summary>
    /// Respawn and relocate player at spawn point
    /// Called by NetRespawnHandler
    /// </summary>
    public void RespawnAndRelocatePlayer(NetworkObject playerNetObj)
    {
        if (!IsServer)
        {
            RunLogError("RespawnAndRelocatePlayer called on non-server",
                nameof(RespawnAndRelocatePlayer));
            return;
        }

        try
        {
            var playerRefs = playerNetObj.GetComponent<IAmPlayerServiceLocator>();
            var teamManager = playerNetObj.GetComponent<TeamPlayer>();

            if (playerRefs == null || teamManager == null)
            {
                RunLogError("Missing required components for respawn",
                    nameof(RespawnAndRelocatePlayer));
                return;
            }

            // Get spawn point based on team
            Transform spawnPoint = GetSpawnPointForEntity(teamManager, playerRefs);

            if (spawnPoint == null)
            {
                RunLogError($"No spawn point found for entity {playerRefs.get__MID__PlayerOrBotOwnerId}",
                    nameof(RespawnAndRelocatePlayer));
                return;
            }

            // Calculate spawn position with randomization
            Vector3 spawnPosition = CalculateSpawnPosition(spawnPoint, teamManager);

            // Apply position
            playerNetObj.transform.position = spawnPosition;

            bool isBot = playerRefs.IsBotPlayer || IsBotId(playerRefs.get__MID__PlayerOrBotOwnerId);

            if (DebugOn) RunLog($"{(isBot ? "Bot" : "Player")} {playerRefs.get__MID__PlayerOrBotOwnerId} " +
                   $"spawned at {spawnPosition} (Team: {teamManager.m_PlayerTeam.Value})",
                   nameof(RespawnAndRelocatePlayer));
        }
        catch (Exception e)
        {
            RunLogError("Respawn failed", nameof(RespawnAndRelocatePlayer), e);
        }
    }

    #endregion

    #region Points Management (Delegates to PointsHandler)

    /// <summary>
    /// Increment team points
    /// Delegates to NetPointsHandler
    /// </summary>
    [ServerRpc(RequireOwnership = false)]
    public void IncrementTeamPointsServerRpc(PlayerTeam team, ServerRpcParams serverRpcParams = default)
    {
        if (!IsServer) return;

        // Mode handlers run on the server and are trusted. A remote client must not move the score.
        if (serverRpcParams.Receive.SenderClientId != NetworkManager.ServerClientId)
        {
            MID_Logger.LogWarning(MID_LogLevel.Info,
                $"Ignored team point request from client {serverRpcParams.Receive.SenderClientId}",
                nameof(NetworkServerManeger), nameof(IncrementTeamPointsServerRpc));
            return;
        }

        _pointsHandler.IncrementTeamPointsServerRpc(team);
    }

    /// <summary>
    /// Reset multikill streak
    /// Delegates to NetPointsHandler
    /// </summary>
    [ServerRpc]
    internal void ResetMultiKillStreekServerRpc(ulong _clientId)
    {
        if (!IsServer) return;

        _pointsHandler.ResetMultiKillStreekServerRpc(_clientId);
    }

    #endregion

    #region Timer Management (Delegates to TimeHandler)

    /// <summary>
    /// Start match timers - called by GameManager
    /// </summary>
    public void StartMatchTimers()
    {
        if (!IsServer) return;

        _timeHandler.StartMatchTimers();
        RunLog("Match timers started", nameof(StartMatchTimers));
    }

    /// <summary>
    /// Override timer system - called by mode handlers
    /// </summary>
    public void OverrideTimer(bool shouldOverride)
    {
        if (!IsServer) return;

        _timeHandler.OverrideTimer(shouldOverride);
    }

    /// <summary>
    /// Force end match - called by points handler or mode handler
    /// </summary>
    public void ForceEndMatch()
    {
        if (!IsServer) return;

        _timeHandler.ResetForNextMatch();
        RunLog("Match forcefully ended", nameof(ForceEndMatch));
    }

    /// <summary>
    /// Get current timer state
    /// </summary>
    public TimerState GetCurrentTimerState()
    {
        return _timeHandler.GetCurrentTimerState();
    }

    /// <summary>
    /// Get time remaining
    /// </summary>
    public float GetTimeRemaining()
    {
        return _timeHandler.GetTimeRemaining();
    }

    /// <summary>
    /// Check if timer is overridden
    /// </summary>
    public bool IsTimerOverridden()
    {
        return _timeHandler.IsTimerOverridden();
    }

    #endregion

    #region Spawn Point Management

    /// <summary>
    /// Initialize spawn points from MapReferences
    /// </summary>
    public void InitializeSpawnPointsFromMap()
    {
        if (!IsServer) return;

        if (MapRefrences.Instance == null)
        {
            RunLogError("MapRefrences.Instance not found when initializing spawn points!",
                nameof(InitializeSpawnPointsFromMap));
            return;
        }

        allBlueTeamSpawnPoints = GetBlueTeamSpawnPoints();
        allRedTeamSpawnPoints = GetRedTeamSpawnPoints();
        allFFRSpawnPoints = GetFreeForAllSpawnPoints();

        if (DebugOn) RunLog($"Spawn points initialized - Blue: {allBlueTeamSpawnPoints.Count}, " +
               $"Red: {allRedTeamSpawnPoints.Count}, FFA: {allFFRSpawnPoints.Count}",
               nameof(InitializeSpawnPointsFromMap));
    }

    /// <summary>
    /// The spawn points a team spawns on. Blue and Red have their own. Free For All, and every other
    /// team, use the free-for-all points. The lists are loaded from the map on first use.
    /// </summary>
    public List<Transform> GetTeamSpawnPoints(PlayerTeam team)
    {
        if (allBlueTeamSpawnPoints.Count == 0 && allRedTeamSpawnPoints.Count == 0 && allFFRSpawnPoints.Count == 0)
        {
            InitializeSpawnPointsFromMap();
        }

        // Free For All has no sides, so it spawns on the free-for-all points when the map has them
        if (NetTeamRules.IsFreeForAll && allFFRSpawnPoints.Count > 0)
        {
            return allFFRSpawnPoints;
        }

        return team switch
        {
            PlayerTeam._BlueTeam => allBlueTeamSpawnPoints,
            PlayerTeam._RedTeam => allRedTeamSpawnPoints,
            _ => allFFRSpawnPoints
        };
    }

    /// <summary>
    /// Adds every player spawn point of the map (Blue, Red and free-for-all) to the list.
    /// </summary>
    public void CollectPlayerSpawnPoints(List<Transform> into)
    {
        if (allBlueTeamSpawnPoints.Count == 0 && allRedTeamSpawnPoints.Count == 0 && allFFRSpawnPoints.Count == 0)
        {
            InitializeSpawnPointsFromMap();
        }

        into.AddRange(allBlueTeamSpawnPoints);
        into.AddRange(allRedTeamSpawnPoints);
        into.AddRange(allFFRSpawnPoints);
    }

    /// <summary>
    /// Get spawn point for entity based on team
    /// </summary>
    private Transform GetSpawnPointForEntity(TeamPlayer teamManager, IAmPlayerServiceLocator playerRefs)
    {
        // Get team
        PlayerTeam team = teamManager.m_PlayerTeam.Value;

        // The points the team spawns on
        List<Transform> spawnPointList = GetTeamSpawnPoints(team);

        // Validate spawn point list
        if (spawnPointList == null || spawnPointList.Count == 0)
        {
            RunLogWarning($"No spawn points for team {team}, using fallback",
                nameof(GetSpawnPointForEntity));

            // Fallback to FFA points
            if (allFFRSpawnPoints.Count > 0)
                spawnPointList = allFFRSpawnPoints;
            else
                return transform; // Last resort fallback
        }

        // Find spawn point with least enemies nearby
        return FindBestSpawnPoint(spawnPointList, team, playerRefs);
    }

    /// <summary>
    /// Find spawn point with fewest enemies nearby
    /// </summary>
    private Transform FindBestSpawnPoint(List<Transform> spawnPoints, PlayerTeam team, IAmPlayerServiceLocator spawning)
    {
        CollectLivingEnemyPositions(team, spawning);

        Transform bestSpawnPoint = spawnPoints[0];
        int fewestEnemies = int.MaxValue;

        foreach (var spawnPoint in spawnPoints)
        {
            if (spawnPoint == null) continue;

            int enemyCount = CountNearbyEnemies(spawnPoint.position);

            if (enemyCount < fewestEnemies)
            {
                fewestEnemies = enemyCount;
                bestSpawnPoint = spawnPoint;

                // If we found a completely safe spawn, use it immediately
                if (enemyCount == 0)
                    break;
            }
        }

        return bestSpawnPoint;
    }

    private const float NearbyEnemyRadiusSqr = 5f * 5f;
    private readonly List<Vector2> _livingEnemyPositions = new List<Vector2>();

    /// <summary>
    /// Gathers where the living enemies of the spawning entity stand, once per spawn choice.
    /// Reads the entity list, so no physics query and no per-collider GetComponent is needed.
    /// </summary>
    private void CollectLivingEnemyPositions(PlayerTeam ownTeam, IAmPlayerServiceLocator spawning)
    {
        _livingEnemyPositions.Clear();

        var all = IAmPlayerServiceLocator.All;
        for (int i = 0; i < all.Count; i++)
        {
            IAmPlayerServiceLocator other = all[i];
            if (other == null || ReferenceEquals(other, spawning)) continue;

            TeamPlayer otherTeam = other.get_PlayerTeamHandler;
            if (otherTeam == null || !NetTeamRules.AreEnemies(ownTeam, otherTeam.m_PlayerTeam.Value)) continue;

            if (other.TryGetComponent(out NetHealthComponent health) && !health.IsAlive()) continue;

            _livingEnemyPositions.Add(other.transform.position);
        }
    }

    /// <summary>
    /// Count nearby enemies at spawn point
    /// </summary>
    private int CountNearbyEnemies(Vector3 spawnPosition)
    {
        int enemyCount = 0;
        Vector2 spawn = spawnPosition;

        for (int i = 0; i < _livingEnemyPositions.Count; i++)
        {
            if ((_livingEnemyPositions[i] - spawn).sqrMagnitude <= NearbyEnemyRadiusSqr) enemyCount++;
        }

        return enemyCount;
    }

    /// <summary>
    /// Calculate final spawn position with randomization
    /// </summary>
    private Vector3 CalculateSpawnPosition(Transform spawnPoint, TeamPlayer teamManager)
    {
        Vector3 basePosition = spawnPoint.position;

        // Add vertical offset to spawn above ground
        basePosition.y += 2f;

        // Add random horizontal offset within radius
        if (respawnRadius > 0)
        {
            basePosition.x += UnityEngine.Random.Range(-respawnRadius, respawnRadius);
        }

        return basePosition;
    }

    // Spawn point getters
    public List<Transform> GetBlueTeamSpawnPoints() =>
        MapRefrences.Instance?.GetSpawnTransforms(SpawnPointType.BlueTeamSpawn) ?? new List<Transform>();

    public List<Transform> GetRedTeamSpawnPoints() =>
        MapRefrences.Instance?.GetSpawnTransforms(SpawnPointType.RedTeamSpawn) ?? new List<Transform>();

    public List<Transform> GetFreeForAllSpawnPoints() =>
        MapRefrences.Instance?.GetSpawnTransforms(SpawnPointType.FreeForAllSpawn) ?? new List<Transform>();

    public List<Transform> GetHardPointLocations() =>
        MapRefrences.Instance?.GetSpawnTransforms(SpawnPointType.HardPoint) ?? new List<Transform>();

    public List<Transform> GetObjectiveLocations() =>
        MapRefrences.Instance?.GetSpawnTransforms(SpawnPointType.Objective) ?? new List<Transform>();

    public List<Transform> GetFlagDeliveryLocations() =>
        MapRefrences.Instance?.GetSpawnTransforms(SpawnPointType.FlagDelivery) ?? new List<Transform>();

    public List<Transform> GetBlueTeamFlagReturnPoints() =>
        MapRefrences.Instance?.GetSpawnTransforms(SpawnPointType.BlueTeamFlagReturn) ?? new List<Transform>();

    public List<Transform> GetRedTeamFlagReturnPoints() =>
        MapRefrences.Instance?.GetSpawnTransforms(SpawnPointType.RedTeamFlagReturn) ?? new List<Transform>();

    public List<Transform> GetSurvivalGroundSpawnPoints() =>
        MapRefrences.Instance?.GetSpawnTransforms(SpawnPointType.SurvivalGroundSpawn) ?? new List<Transform>();

    public List<Transform> GetSurvivalAirSpawnPoints() =>
        MapRefrences.Instance?.GetSpawnTransforms(SpawnPointType.SurvivalAirSpawn) ?? new List<Transform>();

    #endregion

    #region Ragdoll Spawning

    /// <summary>
    /// Spawn ragdoll for killed player
    /// Called by NetDamageHandler
    /// </summary>
    public void SpawnRagDoll(IAmPlayerServiceLocator victimRefs, bool wasBlownUp, ExplosionPoint explosion)
    {
        if (!IsServer)
        {
            RunLogError("SpawnRagDoll called on non-server", nameof(SpawnRagDoll));
            return;
        }

        try
        {
            RunLog("Spawning ragdoll", nameof(SpawnRagDoll));

            // A PSD rig player ragdolls in place, so no separate ragdoll object is spawned
            if (victimRefs != null && victimRefs.GetComponentInChildren<StickmanRigRagdoll>(true) != null)
            {
                Vector2 impulse = wasBlownUp ? explosion.explosionDirection * explosion.explosionForce : Vector2.zero;
                _damageHandler.StartRigRagdollClientRpc(
                    new NetworkObjectReference(victimRefs.GetComponent<NetworkObject>()), impulse);
                return;
            }

            var loadoutScript = victimRefs?.get_PlayerLoadoutScript;
            if (loadoutScript == null)
            {
                RunLogError("PlayerLoadoutScript is null while trying to spawn ragdoll",
                    nameof(SpawnRagDoll));
                return;
            }

            var playerSkinItem = loadoutScript.TryGetLoadoutItem(
                victimRefs.get_PlayerLoadoutScript.m_CurrentSelectedLoadout.LoadoutClassId,
                EqLoadoutItemCategory.StickmanSkin.ToString());
            var playerArmItem = loadoutScript.TryGetLoadoutItem(
                victimRefs.get_PlayerLoadoutScript.m_CurrentSelectedLoadout.LoadoutClassId,
                EqLoadoutItemCategory.StickmanHand.ToString());

            var ragDoll = Instantiate(net_RagDoll, victimRefs.transform.position, Quaternion.identity);

            if (wasBlownUp && ragDoll.TryGetComponent(out Rigidbody2D rb))
            {
                rb.AddForce(explosion.explosionDirection * explosion.explosionForce, ForceMode2D.Impulse);
            }

            ragDoll.SpawnWithOwnership(victimRefs.OwnerClientId);

            var ragDollScript = ragDoll.GetComponent<RagDollHandler>();
            ragDollScript.InitializeRagDollClientRpc(
                playerSkinItem.ToCompact(),
                playerArmItem.ToCompact(),
                victimRefs.get__MID__PlayerOrBotOwnerId,
                victimRefs.get_PlayerTeamHandler.n_IsBotPlayer.Value
            );

            RunLog("Ragdoll spawned successfully", nameof(SpawnRagDoll));
        }
        catch (Exception e)
        {
            RunLogError("Exception in SpawnRagDoll", nameof(SpawnRagDoll), e);
        }
    }

    #endregion

    #region Kill Feed Broadcasting

    /// <summary>
    /// Broadcast kill message to all clients
    /// Called by NetDamageHandler
    /// </summary>
    public void BroadcastKillMessage(IAmPlayerServiceLocator senderRefs, IAmPlayerServiceLocator receiverRefs,
        MID_WhatWeaponDamagedPlayer weaponType)
    {
        try
        {
            // Only broadcast for weapon kills
            if (weaponType != MID_WhatWeaponDamagedPlayer.Gun &&
                weaponType != MID_WhatWeaponDamagedPlayer.Melee &&
                weaponType != MID_WhatWeaponDamagedPlayer.PowerWeapon)
            {
                return;
            }

            // Get weapon sprite info from the sender's current weapon
            string weaponSpriteAtlasId = "";
            string weaponSpriteName = "";

            var weaponCategorizer = senderRefs?.get_NetWeaponCategorizer;
            if (weaponCategorizer != null)
            {
                NetworkObject currentWeapon = null;

                switch (weaponCategorizer.get_CurrentSelectedWeapon)
                {
                    case NetcodeWeaponCatigorizer.WeaponSelected.primary:
                        currentWeapon = weaponCategorizer.primaryWeapon;
                        break;
                    case NetcodeWeaponCatigorizer.WeaponSelected.secondary:
                        currentWeapon = weaponCategorizer.secondaryWeapon;
                        break;
                    case NetcodeWeaponCatigorizer.WeaponSelected.melee:
                        currentWeapon = weaponCategorizer.meleeWeapon;
                        break;
                    case NetcodeWeaponCatigorizer.WeaponSelected.powerWeapon:
                        currentWeapon = weaponCategorizer.powerWeapon;
                        break;
                }

                // Extract sprite information from weapon
                if (currentWeapon != null)
                {
                    var spriteRenderer = currentWeapon.GetComponent<SpriteRenderer>();
                    if (spriteRenderer != null && spriteRenderer.sprite != null)
                    {
                        weaponSpriteName = spriteRenderer.sprite.name;

                        // Get atlas ID from weapon type manager
                        var weaponTypeManager = currentWeapon.GetComponent<WeaponTypeManeger>();
                        if (weaponTypeManager != null)
                        {
                            weaponSpriteAtlasId = GetAtlasIdForWeapon(weaponTypeManager);
                        }
                    }
                }
            }

            var killMessage = new WhoKilledWho
            {
                weaponSpriteAtlasId = weaponSpriteAtlasId,
                weaponSpriteName = weaponSpriteName,
                killerName = senderRefs?.GetUserName() ?? "Unknown",
                victimName = receiverRefs?.GetUserName() ?? "Unknown",
                sparkEffectIndex = 1
            };

            BrodCastWhoKilledWhoClientRpc(killMessage);

            if (DebugOn) RunLog($"Broadcast kill message: {killMessage.killerName.ToString()} killed " +
                   $"{killMessage.victimName.ToString()}", nameof(BroadcastKillMessage));
        }
        catch (Exception e)
        {
            RunLogWarning($"Failed to broadcast kill message: {e.Message}",
                nameof(BroadcastKillMessage));
        }
    }

    /// <summary>
    /// Broadcast who killed who to all clients
    /// </summary>
    [ClientRpc]
    public void BrodCastWhoKilledWhoClientRpc(WhoKilledWho whoKilledWho)
    {
        try
        {
            if (DebugOn) RunLog($"BrodCastWhoKilledWhoClientRpc received on client {NetworkManager.Singleton.LocalClientId}",
                nameof(BrodCastWhoKilledWhoClientRpc));

            MID_NetcodeEventHandler.Instance.InvokeWhoKilledWhoEvent(whoKilledWho);
        }
        catch (Exception e)
        {
            RunLogError("Exception in BrodCastWhoKilledWhoClientRpc",
                nameof(BrodCastWhoKilledWhoClientRpc), e);
        }
    }

    /// <summary>
    /// Trigger camera shake for killer
    /// </summary>
    [ClientRpc]
    public void ShakeOnKillClientRpc(ulong killerClientId)
    {
        try
        {
            // Only shake camera for the player who got the kill
            if (NetworkManager.Singleton.LocalClientId == killerClientId && CameraShakeManager.HasInstance)
            {
                CameraShakeManager.Instance.ShakeOnKill();
            }
        }
        catch (Exception e)
        {
            RunLogError("Exception in ShakeOnKillClientRpc", nameof(ShakeOnKillClientRpc), e);
        }
    }

    #endregion

    #region Weapon Atlas Helpers

    /// <summary>
    /// Get atlas ID based on weapon type
    /// </summary>
    private string GetAtlasIdForWeapon(WeaponTypeManeger weaponTypeManager)
    {
        switch (weaponTypeManager.m_WeaponType)
        {
            case WeaponTypeManeger.WeaponType.PrimaryWeapon:
                if (weaponTypeManager.get_WeaponScript is GeneralGunHandler gunHandler)
                {
                    return DetermineGunAtlasId(gunHandler);
                }
                return "BASIC_SMG_SPRITE_ATLAS";

            case WeaponTypeManeger.WeaponType.SecondaryWeapon:
                if (weaponTypeManager.get_WeaponScript is GeneralGunHandler secondaryHandler)
                {
                    return DetermineSecondaryGunAtlasId(secondaryHandler);
                }
                return "BASIC_PISTOLE_SPRITE_ATLAS";

            case WeaponTypeManeger.WeaponType.MeleeWeapon:
                return "BASIC_MELEE_SPRITE_ATLAS";

            case WeaponTypeManeger.WeaponType.PowerWeapon:
                return "BASIC_POWERWEAPON_SPRITE_ATLAS";

            default:
                return "DEFAULT_ITEM_SPRITE_ATLAS";
        }
    }

    /// <summary>
    /// Determine atlas for primary weapons
    /// </summary>
    private string DetermineGunAtlasId(GeneralGunHandler gunHandler)
    {
        if (gunHandler.get_WeaponConfigSo != null)
        {
            var weaponName = gunHandler.get_WeaponConfigSo.name;

            // Check for legendary/runic variants
            if (weaponName.Contains("Hades") || weaponName.Contains("CrimsonVortex"))
                return "LEGENDARY_SMG_SPRITE_ATLAS";
            if (weaponName.Contains("BloodSmith"))
                return "LEGENDARY_LMG_SPRITE_ATLAS";
            if (weaponName.Contains("EmeraldHalo"))
                return "BUSHBABY_EMERALDHALO_SPRITE_ATLAS";
            if (weaponName.Contains("AdamsAle"))
                return "KIG88_ADAMSALE_SPRITE_ATLAS";
            if (weaponName.Contains("Discharge"))
                return "LEGENDARY_SHOTGUN_SPRITE_ATLAS";
            if (weaponName.Contains("RedRose"))
                return "LEGENDARY_SNIPER_SPRITE_ATLAS";

            // Check basic weapon types
            if (weaponName.Contains("Aliyahoo") || weaponName.Contains("Beatle") ||
                weaponName.Contains("HoodGun") || weaponName.Contains("KiG88") ||
                weaponName.Contains("Stinger") || weaponName.Contains("X39xx"))
                return "BASIC_SMG_SPRITE_ATLAS";

            if (weaponName.Contains("Ak4117") || weaponName.Contains("BushBaby") ||
                weaponName.Contains("RqPc") || weaponName.Contains("U4Q"))
                return "BASIC_LMG_SPRITE_ATLAS";

            if (weaponName.Contains("Poper") || weaponName.Contains("ReBolt") ||
                weaponName.Contains("Winfaust"))
                return "BASIC_SHOTGUN_SPRITE_ATLAS";

            if (weaponName.Contains("A60") || weaponName.Contains("BoltLock") ||
                weaponName.Contains("DragonBolt"))
                return "BASIC_SNIPER_SPRITE_ATLAS";
        }

        return "BASIC_SMG_SPRITE_ATLAS";
    }

    /// <summary>
    /// Determine atlas for secondary weapons
    /// </summary>
    private string DetermineSecondaryGunAtlasId(GeneralGunHandler gunHandler)
    {
        if (gunHandler.get_WeaponConfigSo != null)
        {
            var weaponName = gunHandler.get_WeaponConfigSo.name;

            // Check for legendary variants
            if (weaponName.Contains("Raiz") || weaponName.Contains("ApexMagnum"))
                return "LEGENDARY_PISTOLE_SPRITE_ATLAS";

            // Check weapon types
            if (weaponName.Contains("M160") || weaponName.Contains("CrossBow"))
                return "BASIC_BOW_SPRITE_ATLAS";

            if (weaponName.Contains("BkBoom"))
                return "BASIC_LUNCHER_SPRITE_ATLAS";

            if (weaponName.Contains("HitRam") || weaponName.Contains("HoodLock") ||
                weaponName.Contains("Pi57") || weaponName.Contains("PopUop"))
                return "BASIC_PISTOLE_SPRITE_ATLAS";
        }

        return "BASIC_PISTOLE_SPRITE_ATLAS";
    }

    #endregion

    #region Score Summons

    // Targets of the clairvoyance RPCs, reused. A client that has left is dropped before the send.
    private readonly List<ulong> _clairvoyanceTargets = new List<ulong>();

    /// <summary>
    /// Server only. Adds or removes one clairvoyance buff on the given human clients. The buffs are
    /// counted on the client, so two summons stack and the first one to end does not switch the other off.
    /// </summary>
    public void SetClairvoyanceForClients(IReadOnlyList<ulong> clientIds, bool active)
    {
        if (!BuildClairvoyanceTargets(clientIds)) return;

        SetClairvoyanceClientRpc(active, CreateClairvoyanceTargetParams());
    }

    /// <summary>
    /// Server only. Adds or removes one counter-clairvoyance on the given human clients. While one is
    /// on, the clairvoyance of that client is switched off.
    /// </summary>
    public void SetCounterClairvoyanceForClients(IReadOnlyList<ulong> clientIds, bool active)
    {
        if (!BuildClairvoyanceTargets(clientIds)) return;

        SetCounterClairvoyanceClientRpc(active, CreateClairvoyanceTargetParams());
    }

    private bool BuildClairvoyanceTargets(IReadOnlyList<ulong> clientIds)
    {
        _clairvoyanceTargets.Clear();
        if (!IsServer || clientIds == null) return false;

        for (int i = 0; i < clientIds.Count; i++)
        {
            if (NetworkManager.ConnectedClients.ContainsKey(clientIds[i]))
            {
                _clairvoyanceTargets.Add(clientIds[i]);
            }
        }

        return _clairvoyanceTargets.Count > 0;
    }

    private ClientRpcParams CreateClairvoyanceTargetParams()
    {
        return new ClientRpcParams
        {
            Send = new ClientRpcSendParams { TargetClientIds = _clairvoyanceTargets }
        };
    }

    [ClientRpc]
    private void SetClairvoyanceClientRpc(bool active, ClientRpcParams clientRpcParams = default)
    {
        PlayerDirectionalIndicatorSystem indicators = FindLocalIndicatorSystem();
        if (indicators == null) return;

        if (active) indicators.ActivateClairvoyance();
        else indicators.DeactivateClairvoyance();
    }

    [ClientRpc]
    private void SetCounterClairvoyanceClientRpc(bool active, ClientRpcParams clientRpcParams = default)
    {
        PlayerDirectionalIndicatorSystem indicators = FindLocalIndicatorSystem();
        if (indicators == null) return;

        if (active) indicators.ActivateCounterClairvoyance();
        else indicators.DeactivateCounterClairvoyance();
    }

    // The human of this machine. A bot owned by the host also reports IsOwner, so bots are skipped.
    private static PlayerDirectionalIndicatorSystem FindLocalIndicatorSystem()
    {
        IReadOnlyList<IAmPlayerServiceLocator> all = IAmPlayerServiceLocator.All;
        for (int i = 0; i < all.Count; i++)
        {
            IAmPlayerServiceLocator player = all[i];
            if (player == null || !player.get_IsMyPlayer || player.IsBotPlayer) continue;

            if (player.TryGetComponent(out PlayerDirectionalIndicatorSystem indicators))
            {
                indicators.EnsureInitialized(player);
                return indicators;
            }
        }

        return null;
    }

    #endregion

    #region Helper Methods

    /// <summary>
    /// Check if ID is in bot range
    /// </summary>
    private bool IsBotId(ulong id)
    {
        return id >= 100 && id <= 109;
    }

    /// <summary>
    /// Get player or bot network object
    /// </summary>
    private NetworkObject GetPlayerOrBotObject(ulong id)
    {
        if (IsBotId(id))
        {
            if (NetBotPlayerHandler.netBotHandlerSinglton.allSpawnedBots.TryGetValue(id,
                out NetworkObjectReference botRef))
            {
                if (botRef.TryGet(out NetworkObject botObj))
                {
                    return botObj;
                }
            }
            return null;
        }
        else
        {
            if (NetworkManager.Singleton.ConnectedClients.TryGetValue(id, out var client))
            {
                return client.PlayerObject;
            }
            return null;
        }
    }

    #endregion

    #region Logging Helper Methods

    private bool DebugOn => _logLevel >= MID_LogLevel.Debug;

    private void RunLog(string message, string methodName = "") =>
        MID_Logger.LogDebug(_logLevel, message, nameof(NetworkServerManeger), methodName);

    private void RunLogWarning(string message, string methodName = "") =>
        MID_Logger.LogWarning(_logLevel, message, nameof(NetworkServerManeger), methodName);

    private void RunLogError(string message, string methodName = "", Exception e = null) =>
        MID_Logger.LogError(_logLevel, message, nameof(NetworkServerManeger), methodName, e);

    #endregion
}
