﻿// ============================================================================
// NOTICE: Full documentation and design decisions for this file
// live in docs/StickToTheDeath/bots.md, section "NetTeamHandler.cs"
// ============================================================================
using System;
using System.Collections.Generic;
using UnityEngine;
using Unity.Netcode;
using Unity.Collections;
using MidManStudio.Sttd.InGame.GameItemData;
using MidManStudio.Sttd.Core.HelperFunctions;
using MidManStudio.Sttd.Services;
using MidManStudio.Netcode.Collections;

namespace MidManStudio.Sttd.InGame.Setup
{
    public enum PlayerTeam
    {
        _Observer = 0 ,
        _BlueTeam =1,
        _RedTeam =2,
        _BlackTeam =3,
        _WhiteTeam =4,
        _GrayTeam =5

    }

    /// <summary>
    /// Handles team assignments for all entities (players and bots)
    /// Teams are preset from lobby - this handler just stores and provides access
    /// Players request their assignment, bots are assigned automatically on init
    /// </summary>
    [RequireComponent(typeof(NetworkObject))]
    public class NetTeamHandler : NetworkBehaviour
    {
        [Header("Debug Settings")]
        [SerializeField] private bool _enableLogs = false;

        #region Team Management
        /// <summary>
        /// Network-synced team assignments
        /// Key: client/bot ID, Value: assigned team
        /// </summary>
        private MID_NetworkDictionary<ulong, PlayerTeam> nd_PlayerTeamsDictionary;

        /// <summary>
        /// Pre-assigned team data from lobby (set before players/bots spawn)
        /// This is the source of truth set by the game manager
        /// </summary>
        private Dictionary<ulong, PlayerTeam> _preAssignedTeams = new Dictionary<ulong, PlayerTeam>();

        private MID_GameMatchMode _currentGameMode;
        private bool _initialized = false;

        /// <summary>True once the game manager has initialized the handler for the match mode.</summary>
        public bool IsInitialized => _initialized;
        #endregion

        #region Lifecycle
        private void Awake()
        {
            // Initialize network dictionary
            nd_PlayerTeamsDictionary = new MID_NetworkDictionary<ulong, PlayerTeam>();
        }

        public override void OnNetworkSpawn()
        {
            base.OnNetworkSpawn();

            if (IsServer)
            {
                RunLog("NetTeamHandler spawned on server", nameof(OnNetworkSpawn));
            }
        }

        public override void OnNetworkDespawn()
        {
            nd_PlayerTeamsDictionary?.Clear();
            base.OnNetworkDespawn();
        }
        #endregion

        #region Initialization

        /// <summary>
        /// Initialize handler with game mode
        /// MUST be called before SetPreAssignedTeams
        /// </summary>
        public void Initialize(MID_GameMatchMode gameMatchMode)
        {
            if (!IsServer)
            {
                RunLogError("Initialize called on client!", nameof(Initialize));
                return;
            }

            _currentGameMode = gameMatchMode;
            _initialized = true;

            RunLog($"NetTeamHandler initialized for mode: {gameMatchMode}", nameof(Initialize));
        }

        /// <summary>
        /// Set pre-assigned team data from lobby
        /// Called by game manager after receiving lobby data
        /// </summary>
        public void SetPreAssignedTeams(Dictionary<ulong, PlayerTeam> teamAssignments)
        {
            if (!IsServer)
            {
                RunLogError("SetPreAssignedTeams called on client!", nameof(SetPreAssignedTeams));
                return;
            }

            _preAssignedTeams.Clear();

            foreach (var assignment in teamAssignments)
            {
                _preAssignedTeams[assignment.Key] = assignment.Value;
                RunLog($"Pre-assigned team: ID {assignment.Key} -> {assignment.Value}",
                    nameof(SetPreAssignedTeams));
            }

            RunLog($"Loaded {_preAssignedTeams.Count} pre-assigned team assignments",
                nameof(SetPreAssignedTeams));
        }

        /// <summary>
        /// Auto-assign all bots based on pre-assigned data
        /// Called after bot spawning is complete
        /// </summary>
        public void AutoAssignBots()
        {
            if (!IsServer)
            {
                RunLogError("AutoAssignBots called on client!", nameof(AutoAssignBots));
                return;
            }

            RunLog("Auto-assigning bots from pre-assigned data...", nameof(AutoAssignBots));

            int botsAssigned = 0;
            foreach (var assignment in _preAssignedTeams)
            {
                ulong id = assignment.Key;

                // Check if this is a bot ID (100-109)
                if (IsBotId(id))
                {
                    PlayerTeam team = assignment.Value;

                    // Add to network dictionary
                    if (!nd_PlayerTeamsDictionary.ContainsKey(id))
                    {
                        nd_PlayerTeamsDictionary.Add(id, team);
                        botsAssigned++;

                        // Apply to actual bot entity if it exists
                        ApplyTeamToEntity(id, team);

                        RunLog($"Bot {id} auto-assigned to {team}", nameof(AutoAssignBots));
                    }
                }
            }

            RunLog($"Auto-assigned {botsAssigned} bots to teams", nameof(AutoAssignBots));
        }

        #endregion

        #region Team Assignment - Players

        /// <summary>
        /// Player requests their team assignment from server
        /// Server looks up pre-assigned team and applies it
        /// </summary>
        [ServerRpc(RequireOwnership = false)]
        public void RequestTeamAssignmentServerRpc(ulong clientId, ServerRpcParams serverRpcParams = default)
        {
            if (!IsServer) return;

            if (!_initialized)
            {
                RunLogError($"Cannot assign team for {clientId} - handler not initialized!",
                    nameof(RequestTeamAssignmentServerRpc));
                return;
            }

            // Check if already assigned
            if (nd_PlayerTeamsDictionary.ContainsKey(clientId))
            {
                RunLogWarning($"Player {clientId} already has team assignment: {nd_PlayerTeamsDictionary[clientId]}",
                    nameof(RequestTeamAssignmentServerRpc));
                return;
            }

            // Get pre-assigned team
            PlayerTeam assignedTeam;
            if (_preAssignedTeams.TryGetValue(clientId, out PlayerTeam preAssigned))
            {
                assignedTeam = preAssigned;
                RunLog($"Using pre-assigned team for player {clientId}: {assignedTeam}",
                    nameof(RequestTeamAssignmentServerRpc));
            }
            else
            {
                // Fallback: assign based on game mode if no pre-assignment
                assignedTeam = GetFallbackTeamForGameMode(clientId);
                RunLogWarning($"No pre-assignment for player {clientId}, using fallback: {assignedTeam}",
                    nameof(RequestTeamAssignmentServerRpc));
            }

            // Add to network dictionary
            nd_PlayerTeamsDictionary.Add(clientId, assignedTeam);

            // Apply to actual player entity
            ApplyTeamToEntity(clientId, assignedTeam);

            RunLog($"Player {clientId} assigned to {assignedTeam}",
                nameof(RequestTeamAssignmentServerRpc));
        }

        #endregion

        #region Team Application

        /// <summary>
        /// Apply team assignment to the actual entity (player or bot)
        /// </summary>
        private void ApplyTeamToEntity(ulong entityId, PlayerTeam team)
        {
            if (!IsServer) return;

            // Try to get the entity from PlayerRegistry
            if (PlayerRegistry.HasInstance)
            {
                var playerRef = PlayerRegistry.Instance.GetPlayer(entityId);
                if (playerRef != null && playerRef.get_PlayerTeamHandler != null)
                {
                    playerRef.get_PlayerTeamHandler.m_PlayerTeam.Value = team;
                    RunLog($"Applied team {team} to entity {entityId} via PlayerRegistry",
                        nameof(ApplyTeamToEntity));
                    return;
                }
            }

            // Fallback: try NetworkManager
            if (IsBotId(entityId))
            {
                // Try to get bot from NetBotPlayerHandler
                if (NetBotPlayerHandler.netBotHandlerSinglton?.allSpawnedBots != null)
                {
                    if (NetBotPlayerHandler.netBotHandlerSinglton.allSpawnedBots.TryGetValue(
                        entityId, out NetworkObjectReference botRef))
                    {
                        if (botRef.TryGet(out NetworkObject botObj))
                        {
                            var teamPlayer = botObj.GetComponent<TeamPlayer>();
                            if (teamPlayer != null)
                            {
                                teamPlayer.m_PlayerTeam.Value = team;
                                RunLog($"Applied team {team} to bot {entityId}", nameof(ApplyTeamToEntity));
                                return;
                            }
                        }
                    }
                }
            }
            else
            {
                // Try to get player from NetworkManager
                if (NetworkManager.Singleton.ConnectedClients.TryGetValue(entityId, out var client))
                {
                    if (client.PlayerObject != null)
                    {
                        var teamPlayer = client.PlayerObject.GetComponent<TeamPlayer>();
                        if (teamPlayer != null)
                        {
                            teamPlayer.m_PlayerTeam.Value = team;
                            RunLog($"Applied team {team} to player {entityId}", nameof(ApplyTeamToEntity));
                            return;
                        }
                    }
                }
            }

            RunLogWarning($"Could not find entity {entityId} to apply team {team}",
                nameof(ApplyTeamToEntity));
        }

        #endregion

        #region Team Queries

        /// <summary>
        /// Get team for a specific entity
        /// </summary>
        public PlayerTeam GetEntityTeam(ulong entityId)
        {
            if (nd_PlayerTeamsDictionary.TryGetValue(entityId, out PlayerTeam team))
            {
                return team;
            }

            RunLogWarning($"No team assignment found for entity {entityId}", nameof(GetEntityTeam));
            return PlayerTeam._BlueTeam; // Default fallback
        }

        /// <summary>
        /// Check if entity has a team assignment
        /// </summary>
        public bool HasTeamAssignment(ulong entityId)
        {
            return nd_PlayerTeamsDictionary.ContainsKey(entityId);
        }

        /// <summary>
        /// Get all entities on a specific team
        /// </summary>
        public List<ulong> GetEntitiesOnTeam(PlayerTeam team)
        {
            List<ulong> entities = new List<ulong>();

            foreach (var kvp in nd_PlayerTeamsDictionary)
            {
                if (kvp.Value == team)
                {
                    entities.Add(kvp.Key);
                }
            }

            return entities;
        }

        /// <summary>
        /// Get team distribution (how many entities per team)
        /// </summary>
        public Dictionary<PlayerTeam, int> GetTeamDistribution()
        {
            Dictionary<PlayerTeam, int> distribution = new Dictionary<PlayerTeam, int>
            {
                { PlayerTeam._BlueTeam, 0 },
                { PlayerTeam._RedTeam, 0 },
                { PlayerTeam._BlackTeam, 0 },
                { PlayerTeam._WhiteTeam, 0 },
                { PlayerTeam._GrayTeam, 0 }
            };

            foreach (var kvp in nd_PlayerTeamsDictionary)
            {
                if (distribution.ContainsKey(kvp.Value))
                {
                    distribution[kvp.Value]++;
                }
            }

            return distribution;
        }

        #endregion

        #region Fallback Team Assignment

        /// <summary>
        /// Fallback team assignment when no pre-assignment exists
        /// Tries to balance teams based on current distribution
        /// </summary>
        private PlayerTeam GetFallbackTeamForGameMode(ulong entityId)
        {
            switch (_currentGameMode)
            {
                case MID_GameMatchMode._TeamDeathMatch:
                case MID_GameMatchMode._HardPoint:
                case MID_GameMatchMode._Objectives:
                case MID_GameMatchMode._IgniteSubjugation:
                    // 2-team modes - balance between blue and red
                    return BalanceBetweenTwoTeams(PlayerTeam._BlueTeam, PlayerTeam._RedTeam);

                case MID_GameMatchMode._WeekEndBrawl:
                    // 4-team mode - balance between all four teams
                    return BalanceBetweenFourTeams();

                case MID_GameMatchMode._FreeForAll:
                case MID_GameMatchMode._Survival:
                    // No real teams - assign to blue as placeholder
                    return PlayerTeam._BlueTeam;

                default:
                    return PlayerTeam._BlueTeam;
            }
        }

        private PlayerTeam BalanceBetweenTwoTeams(PlayerTeam team1, PlayerTeam team2)
        {
            int team1Count = 0;
            int team2Count = 0;

            foreach (var kvp in nd_PlayerTeamsDictionary)
            {
                if (kvp.Value == team1) team1Count++;
                else if (kvp.Value == team2) team2Count++;
            }

            // Assign to team with fewer players
            return team1Count <= team2Count ? team1 : team2;
        }

        private PlayerTeam BalanceBetweenFourTeams()
        {
            Dictionary<PlayerTeam, int> counts = new Dictionary<PlayerTeam, int>
            {
                { PlayerTeam._BlueTeam, 0 },
                { PlayerTeam._RedTeam, 0 },
                { PlayerTeam._WhiteTeam, 0 },
                { PlayerTeam._BlackTeam, 0 }
            };

            foreach (var kvp in nd_PlayerTeamsDictionary)
            {
                if (counts.ContainsKey(kvp.Value))
                {
                    counts[kvp.Value]++;
                }
            }

            // Find team with least players
            PlayerTeam smallestTeam = PlayerTeam._BlueTeam;
            int smallestCount = int.MaxValue;

            foreach (var kvp in counts)
            {
                if (kvp.Value < smallestCount)
                {
                    smallestCount = kvp.Value;
                    smallestTeam = kvp.Key;
                }
            }

            return smallestTeam;
        }

        #endregion

        #region Pre-Assignment Query (For Bots Before Spawn) - NEW

        /// <summary>
        /// CRITICAL: Query pre-assigned team WITHOUT requesting assignment
        /// Used by NetBotPlayerHandler to determine spawn location BEFORE instantiation
        /// </summary>
        public PlayerTeam GetPreAssignedTeam(ulong entityId)
        {
            if (_preAssignedTeams.TryGetValue(entityId, out PlayerTeam team))
            {
                RunLog($"Found pre-assigned team for entity {entityId}: {team}",
                    nameof(GetPreAssignedTeam));
                return team;
            }

            RunLogWarning($"No pre-assignment found for entity {entityId} - using fallback",
                nameof(GetPreAssignedTeam));

            // Fallback to automatic assignment
            return GetFallbackTeamForGameMode(entityId);
        }

        /// <summary>
        /// Check if entity has a pre-assignment (before spawning)
        /// </summary>
        public bool HasPreAssignment(ulong entityId)
        {
            return _preAssignedTeams.ContainsKey(entityId);
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// Check if ID is in bot range (100-109)
        /// </summary>
        private bool IsBotId(ulong id)
        {
            return id >= 100 && id <= 109;
        }

        #endregion

        #region Remove Entity

        /// <summary>
        /// Remove entity from team tracking (when they disconnect)
        /// </summary>
        [ServerRpc(RequireOwnership = false)]
        public void RemoveEntityServerRpc(ulong entityId)
        {
            if (!IsServer) return;

            if (nd_PlayerTeamsDictionary.ContainsKey(entityId))
            {
                PlayerTeam team = nd_PlayerTeamsDictionary[entityId];
                nd_PlayerTeamsDictionary.Remove(entityId);
                RunLog($"Removed entity {entityId} from team {team}", nameof(RemoveEntityServerRpc));
            }
        }

        #endregion

        #region Reset

        /// <summary>
        /// Reset all team assignments for next match
        /// </summary>
        public void ResetForNextMatch()
        {
            if (IsServer)
            {
                nd_PlayerTeamsDictionary.Clear();
                _preAssignedTeams.Clear();
                _initialized = false;

                RunLog("Team handler reset for next match", nameof(ResetForNextMatch));
            }
        }

        #endregion

        #region Logging

        private void RunLog(string message, string methodName = "")
        {
            if (!_enableLogs) return;
            MID_HelperFunctions.LogDebug(message, nameof(NetTeamHandler), methodName);
        }

        private void RunLogWarning(string message, string methodName = "")
        {
            if (!_enableLogs) return;
            MID_HelperFunctions.LogWarning(message, nameof(NetTeamHandler), methodName);
        }

        private void RunLogError(string message, string methodName = "", Exception e = null)
        {
            if (!_enableLogs) return;
            MID_HelperFunctions.LogError(message, nameof(NetTeamHandler), methodName, e);
        }

        #endregion
    }
}
