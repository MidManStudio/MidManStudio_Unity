﻿// ============================================================================
// NOTICE: Full documentation and design decisions for this file
// live in docs/StickToTheDeath/stickman-parts.md, section "BaseBotLoadoutGenerator.cs"
// ============================================================================
using System.Collections.Generic;
using UnityEngine;
using MidManStudio.Sttd.InGame.InGamePlayerDataStructures;
using Unity.Collections;
using MidManStudio.Sttd.InGame.StickmanParts;
using static MidManStudio.Sttd.InGame.Bot.BotLoadoutGenerator;
using static MidManStudio.Sttd.InGame.InGamePlayerDataStructures.NetworkPlayerLoadoutContainer;

namespace MidManStudio.Sttd.InGame.Bot
{
    /// <summary>
    /// Abstract base class for bot loadout generation
    /// CRITICAL FIX: Now generates TWO loadout classes (FirstLoadout and SecondLoadout)
    /// </summary>
    public abstract class BaseBotLoadoutGenerator
    {
        #region Abstract Methods - Implement in derived classes

        protected abstract List<BotPrimaryWeapon> GetAvailablePrimaryWeapons();
        protected abstract List<BotSecondaryWeapon> GetAvailableSecondaryWeapons();
        protected abstract List<BotMeleeWeapon> GetAvailableMeleeWeapons();
        protected abstract List<BotGrenade> GetAvailableGrenades();
        protected abstract List<BotPowerWeapon> GetAvailablePowerWeapons();
        protected abstract List<BotSummon> GetAvailableSummons();
        protected abstract List<BotJetpack> GetAvailableJetpacks();
        protected abstract List<BotStickmanSkin> GetAvailableStickmanSkins();
        protected abstract List<BotStickmanHand> GetAvailableStickmanHands();

        #endregion

        #region Public API

        /// <summary>
        /// Generate a random loadout using available items for this mode
        /// </summary>
        public BotLoadoutConfig GenerateRandomLoadout()
        {
            return new BotLoadoutConfig
            {
                primaryWeapon = GetRandomItem(GetAvailablePrimaryWeapons()),
                secondaryWeapon = GetRandomItem(GetAvailableSecondaryWeapons()),
                meleeWeapon = GetRandomItem(GetAvailableMeleeWeapons()),
                grenade = GetRandomItem(GetAvailableGrenades()),
                powerWeapon = GetRandomItem(GetAvailablePowerWeapons()),
                summonOne = GetRandomItem(GetAvailableSummons()),
                summonTwo = GetRandomItem(GetAvailableSummons()),
                jetpack = GetRandomItem(GetAvailableJetpacks()),
                stickmanSkin = GetRandomItem(GetAvailableStickmanSkins()),
                stickmanHand = GetRandomItem(GetAvailableStickmanHands())
            };
        }

        /// <summary>
        /// CRITICAL FIX: Create NetworkPlayerLoadoutContainer with TWO loadout classes
        /// Bots get randomly generated loadouts for both slots
        /// </summary>
        public NetworkPlayerLoadoutContainer CreateNetworkLoadout(string authPlayerId)
        {
            // Generate TWO different random loadouts
            var firstLoadoutConfig = GenerateRandomLoadout();
            var secondLoadoutConfig = GenerateRandomLoadout();

            var container = new NetworkPlayerLoadoutContainer
            {
                SourcePlayerId = authPlayerId,
                Loadouts = new List<NetworkPlayerLoadout>
                {
                    CreateLoadoutFromConfig(firstLoadoutConfig, "FirstLoadout"),
                    CreateLoadoutFromConfig(secondLoadoutConfig, "SecondLoadout")
                }
            };

            return container;
        }

        /// <summary>
        /// Create a NetworkPlayerLoadout from a BotLoadoutConfig
        /// </summary>
        private NetworkPlayerLoadout CreateLoadoutFromConfig(BotLoadoutConfig config, string loadoutClassId)
        {
            var items = new List<NetworkLoadoutItem>
            {
                BotLoadoutGenerator.CreatePrimaryWeaponItem(config.primaryWeapon),
                BotLoadoutGenerator.CreateSecondaryWeaponItem(config.secondaryWeapon),
                BotLoadoutGenerator.CreateMeleeWeaponItem(config.meleeWeapon),
                BotLoadoutGenerator.CreateGrenadeItem(config.grenade),
                BotLoadoutGenerator.CreatePowerWeaponItem(config.powerWeapon),
                BotLoadoutGenerator.CreateSummonItem(config.summonOne, "Summon_1"),
                BotLoadoutGenerator.CreateSummonItem(config.summonTwo, "Summon_2"),
                BotLoadoutGenerator.CreateJetpackItem(config.jetpack),
                BotLoadoutGenerator.CreateStickmanSkinItem(config.stickmanSkin),
                BotLoadoutGenerator.CreateStickmanHandItem(config.stickmanHand)
            };

            AddStickmanParts(items, config.stickmanSkin);

            return new NetworkPlayerLoadout
            {
                LoadoutClassId = loadoutClassId,
                LoadoutItems = items
            };
        }

        /// <summary>
        /// Adds the five part items of the PSD rig. The character is the one of the skin the bot rolled,
        /// so the old skin item and the parts agree and the pool of characters does not change. A bot
        /// prefab without the PSD applier ignores the parts and keeps the old skin.
        /// </summary>
        private static void AddStickmanParts(List<NetworkLoadoutItem> items, BotStickmanSkin skin)
        {
            if (!StickmanCatalog.IsInitialized)
            {
                StickmanCatalog.Initialize();
            }

            string characterId = FindCatalogCharacterId(skin);
            if (string.IsNullOrEmpty(characterId)) return;

            StickmanLook look = StickmanLook.CreateDefault();
            look.SetCharacter(characterId);
            StickmanLoadoutBridge.WriteLook(items, look);
        }

        // The skin names are the catalog ids with a prefix (StickmanDave and DAVE). Underscores of the
        // catalog ids are ignored (StickmanLuciusDKing and LUCIUS_D_KING). An unknown skin gets the
        // default character of the catalog.
        private static string FindCatalogCharacterId(BotStickmanSkin skin)
        {
            const string prefix = "Stickman";
            string name = skin.ToString();
            string key = name.StartsWith(prefix) ? name.Substring(prefix.Length) : name;

            IReadOnlyList<StickmanCharacterData> characters = StickmanCatalog.Characters;
            for (int i = 0; i < characters.Count; i++)
            {
                if (string.Equals(characters[i].Id.Replace("_", ""), key, System.StringComparison.OrdinalIgnoreCase))
                {
                    return characters[i].Id;
                }
            }

            return StickmanCatalog.DefaultCharacterId;
        }

        #endregion

        #region Helper Methods

        private T GetRandomItem<T>(List<T> items)
        {
            if (items == null || items.Count == 0)
            {
                Debug.LogError($"[BotLoadout] No items available for type {typeof(T).Name}");
                return default;
            }

            return items[Random.Range(0, items.Count)];
        }

        #endregion
    }

    /// <summary>
    /// Static entry point for bot loadout generation
    /// Routes to appropriate generator based on mode
    /// </summary>
    public static class BotLoadoutGeneratorFactory
    {
        private static OnlineBotLoadoutGenerator _onlineGenerator = new OnlineBotLoadoutGenerator();
        private static OfflineBotLoadoutGenerator _offlineGenerator = new OfflineBotLoadoutGenerator();

        /// <summary>
        /// Create an online bot loadout (full item pool) - TWO loadout classes
        /// </summary>
        public static NetworkPlayerLoadoutContainer CreateOnlineBotLoadout(string authPlayerId)
        {
            return _onlineGenerator.CreateNetworkLoadout(authPlayerId);
        }

        /// <summary>
        /// Create an offline bot loadout (limited item pool) - TWO loadout classes
        /// </summary>
        public static NetworkPlayerLoadoutContainer CreateOfflineBotLoadout(string authPlayerId)
        {
            return _offlineGenerator.CreateNetworkLoadout(authPlayerId);
        }
    }
}
