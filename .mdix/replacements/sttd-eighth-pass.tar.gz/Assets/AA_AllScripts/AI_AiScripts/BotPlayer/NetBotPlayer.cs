// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/StickToTheDeath/bots.md, section "NetBotPlayer.cs"
// ============================================================================
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Netcode;
using MidManStudio.Sttd.InGame.MultiplayerFramework;
using UnityEngine.U2D.IK;
using MidManStudio.Sttd.InGame.OnlineSetup;
using MidManStudio.Sttd.InGame.Setup;
using MidManStudio.Core.Logging;
using System;
using MidManStudio.InGame.SharedSetup;
using MidManStudio.Core.TickDispatcher;
/// <summary>
/// Bot AI player with simplified targeting and patrol logic.
/// Optimized with tick system, logging, and performance improvements.
/// FIXED: Always attempts to find player target first, only patrols when no target available.
/// </summary>
public class NetBotPlayer : NetworkBehaviour
{
    #region Debug Settings
    [Header("Debug Settings")]
    [SerializeField] private MID_LogLevel _logLevel = MID_LogLevel.Error;
    #endregion

    #region Enums
    private enum BotAnimationStates
    {
        ideal,
        walking,
        runing,
        jumping,
        crouching,
        crouchWalking,
        sliding,
        backwardsWalking,
        backwardsRuning,
        backwardsCrouchWalking
    }

    enum CurrentBotWeaponSelected
    {
        primary,
        secondary,
        powerWeapon
    }

    enum BotState
    {
        Initializing,
        SearchingForTarget,
        ChasingPlayer,
        PatrollingMap,
        GoingToMapPoint,
        Retreating
    }

    enum BotDifficultyLevel
    {
        basic,
        advanced,
        master,
        omoThisNaMaye,
        shegeaDanIska
    }

    enum BotUniqueBehaviours
    {
        returnToDefault,
        crouch,
        slide,
        throwGrenade,
        switchToNewWeapon,
        switchToPowerWeapon,
        summon,
        goToMapPoint
    }

    public enum BotPlayerFliptState
    {
        notFliped,
        fliped
    }
    #endregion

    #region Serialized Fields
    [Header("Player Ai With Pathfinding")]
    [SerializeField] internal NetworkVariable<ulong> n_FakeBotID = new NetworkVariable<ulong>();
    [SerializeField] bool startBotAi = false;

    [Header("Movement Components")]
    [SerializeField] private BotMovementController _movementController;
    [SerializeField] private BotAICommands _aiCommands;
    [SerializeField] private BotAnimationController _animationController;
    [SerializeField] private BotEffectsController _effectsController;

    [Header("Pathfinding Module")]
    [SerializeField] private BotPathfindingModule _pathfindingModule;

    [Header("Legacy Components")]
    [SerializeField] private Rigidbody2D m_Rigidbody;

    [Header("AiBotBehaviour")]
    [SerializeField] NetworkVariable<BotState> n_BotState = new NetworkVariable<BotState>();
    [SerializeField] NetworkVariable<BotDifficultyLevel> n_BotDifficultyLevel = new NetworkVariable<BotDifficultyLevel>();
    [SerializeField] NetworkVariable<BotUniqueBehaviours> n_CurrentBotSpecialBehaviour = new NetworkVariable<BotUniqueBehaviours>();

    [SerializeField] NetworkVariable<ArmAnimationState.State> m_ArmAnimationStates = new NetworkVariable<ArmAnimationState.State>(ArmAnimationState.State.Idle);
    [SerializeField] NetworkVariable<CurrentBotWeaponSelected> n_currentSelectedWeapon = new NetworkVariable<CurrentBotWeaponSelected>();

    [Header("Probabilities")]
    // Filled from code for the chosen difficulty, so no prefab value can change how a tier plays.
    private List<int> _uniqueBehaviouProbabilities = new List<int>();
    private List<BotUniqueBehaviours> _allPossibleUniqueBehaviours = new List<BotUniqueBehaviours>();

    // Relative weights per difficulty, in enum order: basic, advanced, master, omoThisNaMaye, shegeaDanIska
    private static readonly int[] DifficultyWeights = { 4000, 4000, 1000, 600, 400 };

    [Header("Targeting - UNIFIED SYSTEM")]
    [SerializeField] internal Transform _currentTarget;
    [SerializeField] IAmPlayerServiceLocator _currentTargetPlayerRefs;
    [SerializeField] float _maxTargetCheckRadius = 100f;
    [SerializeField] float _followTargetActiveDistance = 50f;
    [SerializeField] float _maxTargetLockDistance = 80f;

    [Header("Combat Settings")]
    [SerializeField] bool _targetIsWithinFireDistance = false;
    [SerializeField] float maxFireDistance = 20f;
    [SerializeField] float minFireDistance = 5f;
    [SerializeField] LayerMask _rayCastLayers;
    [SerializeField] Transform _currentShotPoint;

    [Header("Physics")]
    [SerializeField] float _minSpeed = 100f;
    [SerializeField] float _currentSpeed = 200f;
    [SerializeField] float _maxSpeed = 300f;
    [SerializeField] float distanceToTarget;

    [Header("Bot Retreat Behaviour")]
    [SerializeField] bool isRetreating;
    [SerializeField] Transform retreetPoint;

    [Header("Map Point Behavior - RARE")]
    [SerializeField] float _mapPointBehaviorChance = 0.05f;
    [SerializeField] float _mapPointDuration = 15f;
    [SerializeField] float _mapPointTimer = 0f;

    [Header("Arm Management")]
    [SerializeField] GameObject botPlayerArms;
    [SerializeField] Transform limitedRotator;
    [SerializeField] LimbSolver2D m_RightHandLimbSolver;
    [SerializeField] LimbSolver2D m_LeftHandLimbSolver;

    [Header("References")]
    [SerializeField] IAmPlayerServiceLocator m_InternalBotPlayerRefrences;

    [Header("Weapon Management")]
    [SerializeField] NetworkVariable<bool> fireWeapon = new NetworkVariable<bool>();
    [SerializeField] float botFireRate = 0.2f;
    [SerializeField] GeneralGunHandler _primaryGunScript;
    [SerializeField] GeneralGunHandler _secondaryGunScript;
    [SerializeField] PowerWeaponHandler _powerWeaponScript;
    bool _isUsingPowerWeapon;

    private IGameManager currentGameRunner;
    private bool gameRunnerFound = false;

    [Header("Arm Movement Integration")]
    private ArmMove _armController;
    #endregion

    #region Tick System Integration
    [Header("Tick System Configuration")]
    // Fixed in code so a serialized value on the prefab cannot push a rate below the dispatcher
    // floor. Gameplay logic stays at Tick_0_1 or slower, only the weapon loop uses Tick_0_05.
    private const TickRate TargetSearchTickRate = TickRate.Tick_0_2;
    private const TickRate DecisionTickRate = TickRate.Tick_0_1;
    private const TickRate UniqueBehaviorTickRate = TickRate.Tick_2;
    private const TickRate StuckCheckTickRate = TickRate.Tick_1;
    private const TickRate FireTickRate = TickRate.Tick_0_05;

    private bool _isTickSystemActive = false;

    // Weapon loop. A shot is tried every botFireRate seconds, rounded up to a whole fire tick.
    // The gun's own cooldown is the real limit on how fast it shoots.
    private bool _fireTickActive;
    private float _fireTimer;
    #endregion

    #region Cached Values (Performance)
    private const float TARGET_SEARCH_INTERVAL = 1f;
    private const float DISTANCE_UPDATE_INTERVAL = 0.15f;
    #endregion

    #region Bot Spatial Awareness
    [Header("Bot Collision Avoidance")]
    [SerializeField] private float _botAvoidanceRadius = 5f;
    [SerializeField] private float _minBotDistance = 3f;
    [SerializeField] private bool _isNearOtherBot = false;
    [SerializeField] private Vector2 _avoidanceDirection = Vector2.zero;

    #endregion

    #region Stuck Detection
    [SerializeField] private NetworkVariable<bool> isStuck = new NetworkVariable<bool>();
    [Header("Stuck Detection")]
    private Vector2 _stuckSamplePosition;
    private int _stuckStrikes;
    private const float StuckMinProgress = 0.5f;   // world units the bot must move between two checks
    private const int StuckStrikesNeeded = 2;       // consecutive checks without progress

    private Coroutine _initRoutine;
    private Coroutine _recoveryRoutine;

    // Single step waits use MID_TickDelay: no coroutine object, cancelled by handle.
    private TickDelayHandle? _aliveDelay;
    private TickDelayHandle? _crouchDelay;
    private Action _enableAiCb;
    private Action _standUpCb;

    private const float LoadoutWaitTimeout = 10f;
    private static readonly WaitForSeconds Wait0_1 = new WaitForSeconds(0.1f);
    private static readonly WaitForSeconds Wait0_3 = new WaitForSeconds(0.3f);
    private static readonly WaitForSeconds Wait0_5 = new WaitForSeconds(0.5f);
    private static readonly WaitForSeconds Wait1 = new WaitForSeconds(1f);
    #endregion

    #region Component Setup
    private void Awake()
    {
        RunLog("NetBotPlayer Awake", nameof(Awake));

        _enableAiCb = OnEnableAiAfterRespawn;
        _standUpCb = OnStandUp;

        if (_movementController == null) _movementController = GetComponent<BotMovementController>();
        if (_aiCommands == null) _aiCommands = GetComponent<BotAICommands>();
        if (_animationController == null) _animationController = GetComponent<BotAnimationController>();
        if (_effectsController == null) _effectsController = GetComponent<BotEffectsController>();
        if (m_Rigidbody == null) m_Rigidbody = GetComponent<Rigidbody2D>();
        if (_armController == null) _armController = GetComponentInChildren<ArmMove>();

        if (_pathfindingModule == null) _pathfindingModule = GetComponent<BotPathfindingModule>();
        if (_pathfindingModule != null)
        {
            _pathfindingModule.Initialize(m_Rigidbody, _movementController, _aiCommands);
            RunLog("Pathfinding module initialized", nameof(Awake));
        }

        FindGameRunner();
    }

    private void FindGameRunner()
    {
        var offlineRunner = OfflineGameRunner.Instance;
        if (offlineRunner != null)
        {
            currentGameRunner = offlineRunner;
            gameRunnerFound = true;
            RunLog("Found Offline Game Runner", nameof(FindGameRunner));
            return;
        }

        var onlineRunner = OnlineInGameRunner.Instance;
        if (onlineRunner != null)
        {
            currentGameRunner = onlineRunner;
            gameRunnerFound = true;
            RunLog("Found Online Game Runner", nameof(FindGameRunner));
            return;
        }

        RunLogError("No valid game runner found (Online or Offline)!", nameof(FindGameRunner));
        throw new System.Exception("NetBotPlayer: No valid game runner found!");
    }
    #endregion

    #region Network Lifecycle
    public override void OnNetworkSpawn()
    {
        if (!IsServer) return;

        RunLog("NetBotPlayer network spawned", nameof(OnNetworkSpawn));

        n_BotState.OnValueChanged += OnBotStateChanged;
        n_currentSelectedWeapon.OnValueChanged += OnBotWeaponChanged;
        fireWeapon.OnValueChanged += OnShouldFireValueChanged;
        isStuck.OnValueChanged += OnIsStuckValueChanged;
        n_BotDifficultyLevel.OnValueChanged += OnBotDifficultyChanged;

        // FIXED: Subscribe to new health component events
        if (m_InternalBotPlayerRefrences?.get_PlayerHealthScript != null)
        {
            var healthComponent = m_InternalBotPlayerRefrences.get_PlayerHealthScript.GetHealthComponent();
            if (healthComponent != null)
            {
                healthComponent.OnHealthStateChanged += OnBotHealthStateChanged;
                healthComponent.OnDeath += OnBotDeath;
                RunLog("Subscribed to health component events", nameof(OnNetworkSpawn));
            }
            else
            {
                RunLogError("Health component is null!", nameof(OnNetworkSpawn));
            }
        }

        if (gameRunnerFound)
        {
            if (currentGameRunner is OnlineInGameRunner onlineRunner)
            {
                onlineRunner.CurrentMatchTimerState.OnValueChanged += OnMatchModeAndTimerStateChanged;
            }
            else if (currentGameRunner is OfflineGameRunner offlineRunner)
            {
                offlineRunner.GetCurrentTimerStateNet().OnValueChanged += OnMatchModeAndTimerStateChanged;
            }
        }

        var currentTimerState = GetCurrentTimerState();
        if (currentTimerState == TimerState.InMatch)
        {
            InitializeBot();
        }
    }

    private void OnBotDeath()
    {
        RunLog("Bot die", nameof(OnBotDeath));

    }

    public override void OnNetworkDespawn()
    {
        if (!IsServer) return;

        RunLog("NetBotPlayer network despawning - cleaning up", nameof(OnNetworkDespawn));

        // Unsubscribe from tick system
        UnsubscribeFromAllTicks();
        StopBotRoutines();

        n_BotState.OnValueChanged -= OnBotStateChanged;
        n_currentSelectedWeapon.OnValueChanged -= OnBotWeaponChanged;
        fireWeapon.OnValueChanged -= OnShouldFireValueChanged;
        isStuck.OnValueChanged -= OnIsStuckValueChanged;
        n_BotDifficultyLevel.OnValueChanged -= OnBotDifficultyChanged;

        // FIXED: Unsubscribe from health component events
        if (m_InternalBotPlayerRefrences?.get_PlayerHealthScript != null)
        {
            var healthComponent = m_InternalBotPlayerRefrences.get_PlayerHealthScript.GetHealthComponent();
            if (healthComponent != null)
            {
                healthComponent.OnHealthStateChanged -= OnBotHealthStateChanged;
                healthComponent.OnDeath -= OnBotDeath;
            }
        }

        if (gameRunnerFound)
        {
            if (currentGameRunner is OnlineInGameRunner onlineRunner)
            {
                onlineRunner.CurrentMatchTimerState.OnValueChanged -= OnMatchModeAndTimerStateChanged;
            }
            else if (currentGameRunner is OfflineGameRunner offlineRunner)
            {
                offlineRunner.GetCurrentTimerStateNet().OnValueChanged -= OnMatchModeAndTimerStateChanged;
            }
        }

        StopFireTick();

        if (_pathfindingModule != null)
        {
            _pathfindingModule.StopPathfinding();
        }

        RunLog("Cleanup complete", nameof(OnNetworkDespawn));
    }

    private TimerState GetCurrentTimerState()
    {
        if (!gameRunnerFound) return TimerState.NullState;

        if (currentGameRunner is OnlineInGameRunner onlineRunner)
        {
            return onlineRunner.CurrentMatchTimerState.Value;
        }
        else if (currentGameRunner is OfflineGameRunner offlineRunner)
        {
            return offlineRunner.GetCurrentTimerStateNet().Value;
        }

        return TimerState.NullState;
    }
    #endregion

    #region Bot Initialization
    private void InitializeBot()
    {
        if (_initRoutine != null) return;
        _initRoutine = StartCoroutine(InitializeBotRoutine());
    }

    private IEnumerator InitializeBotRoutine()
    {
        RunLog("=== BOT INITIALIZATION START ===", nameof(InitializeBot));

        n_BotState.Value = BotState.Initializing;

        // Set difficulty first
        SetBotDifficulty();

        // Start pathfinding system
        _pathfindingModule.StartPathfinding();
        RunLog("Pathfinding started", nameof(InitializeBot));

        // Wait for loadout to be ready
        yield return WaitForLoadout();
        RunLog("Loadout ready", nameof(InitializeBot));

        // Setup weapons
        yield return SetupInitialWeapon();
        RunLog("Weapons ready", nameof(InitializeBot));

        // Subscribe to tick system for various updates
        SubscribeToTickSystem();
        RunLog("Tick system subscribed", nameof(InitializeBot));

        startBotAi = true;

        // Try to find a player target FIRST
        yield return AttemptToFindPlayerTarget();

        RunLog("=== BOT INITIALIZATION COMPLETE ===", nameof(InitializeBot));
        _initRoutine = null;
    }

    private IEnumerator WaitForLoadout()
    {
        var loadout = m_InternalBotPlayerRefrences.get_PlayerLoadoutScript;

        float waited = 0f;
        while (!loadout.get_IsInitialized && waited < LoadoutWaitTimeout)
        {
            yield return Wait0_5;
            waited += 0.5f;
        }

        if (!loadout.get_IsInitialized)
        {
            RunLogWarning("Loadout initialization timeout!", nameof(WaitForLoadout));
        }
    }
    #endregion

    #region Tick System Management
    private void SubscribeToTickSystem()
    {
        if (_isTickSystemActive)
        {
            RunLogWarning("Tick system already active", nameof(SubscribeToTickSystem));
            return;
        }

        // Subscribe to different tick rates for different operations
        MID_TickDispatcher.Subscribe(TargetSearchTickRate, OnTargetSearchTick);
        MID_TickDispatcher.Subscribe(DecisionTickRate, OnDecisionTick);
        MID_TickDispatcher.Subscribe(UniqueBehaviorTickRate, OnUniqueBehaviorTick);
        MID_TickDispatcher.Subscribe(StuckCheckTickRate, OnStuckCheckTick);

        _isTickSystemActive = true;
        RunLog("Subscribed to tick system", nameof(SubscribeToTickSystem));
    }

    private void UnsubscribeFromAllTicks()
    {
        if (!_isTickSystemActive) return;

        MID_TickDispatcher.Unsubscribe(TargetSearchTickRate, OnTargetSearchTick);
        MID_TickDispatcher.Unsubscribe(DecisionTickRate, OnDecisionTick);
        MID_TickDispatcher.Unsubscribe(UniqueBehaviorTickRate, OnUniqueBehaviorTick);
        MID_TickDispatcher.Unsubscribe(StuckCheckTickRate, OnStuckCheckTick);

        _isTickSystemActive = false;
        RunLog("Unsubscribed from tick system", nameof(UnsubscribeFromAllTicks));
    }

    // Tick callbacks
    private void OnTargetSearchTick(float deltaTime)
    {
        if (!IsServer || !startBotAi) return;

        // The arm controller follows the target transform on its own. SetTarget gives it the
        // target, and this only re-asserts it.
        if (_currentTarget != null) UpdateBotAiming();

        BotState state = n_BotState.Value;

        if (state == BotState.SearchingForTarget)
        {
            if (TryFindPlayerTarget())
            {
                TransitionToState(BotState.ChasingPlayer);
                if (DebugOn)
                    RunLog("Found player target, transitioning to CHASING", nameof(OnTargetSearchTick));
            }
            else
            {
                // CRITICAL: Don't just stay in search state forever
                // After searching, start patrolling to keep moving
                if (DebugOn)
                    RunLog("No target found, will patrol", nameof(OnTargetSearchTick));

                TransitionToState(BotState.PatrollingMap);
            }
        }
        else if (state == BotState.PatrollingMap)
        {
            // Always check for player targets while patrolling
            if (TryFindPlayerTarget())
            {
                TransitionToState(BotState.ChasingPlayer);
                if (DebugOn)
                    RunLog("Found player target while patrolling!", nameof(OnTargetSearchTick));
            }
        }
        else if (state == BotState.ChasingPlayer)
        {
            // Periodically verify we're chasing the closest/best target
            if (_currentTargetPlayerRefs != null && _currentTarget != null)
            {
                var all = IAmPlayerServiceLocator.All;
                float currentTargetDistance = Vector2.Distance(transform.position, _currentTarget.position);

                for (int i = 0; i < all.Count; i++)
                {
                    var player = all[i];
                    if (player == _currentTargetPlayerRefs || !IsValidTarget(player)) continue;

                    float distanceToOther = Vector2.Distance(transform.position, player.transform.position);

                    // Switch to significantly closer target
                    if (distanceToOther < currentTargetDistance * 0.6f)
                    {
                        if (DebugOn)
                            RunLog($"Switching to closer target: {distanceToOther:F1}m vs {currentTargetDistance:F1}m",
                                   nameof(OnTargetSearchTick));
                        SetTarget(player.transform, player);
                        break;
                    }
                }
            }
        }
    }

    private void OnUniqueBehaviorTick(float deltaTime)
    {
        if (!IsServer || !startBotAi) return;

        CheckUniqueBotBehaviour();
    }
    #endregion

    // Add to NetBotPlayer.cs

    #region Bot Spatial Awareness

    private void OnStuckCheckTick(float deltaTime)
    {
        if (!IsServer || !startBotAi) return;

        CheckBotProximity();
        CheckIfBotPlayerIsStuck();
        ValidateCurrentTarget();
    }

    private void CheckBotProximity()
    {
        _isNearOtherBot = false;
        _avoidanceDirection = Vector2.zero;

        var myTeam = m_InternalBotPlayerRefrences.get_PlayerTeamHandler.m_PlayerTeam.Value;
        var all = IAmPlayerServiceLocator.All;
        Vector2 myPosition = transform.position;

        float avoidRadiusSqr = _botAvoidanceRadius * _botAvoidanceRadius;
        float closestSqr = float.MaxValue;
        Vector2 closestDirection = Vector2.zero;

        for (int i = 0; i < all.Count; i++)
        {
            var other = all[i];

            // Only allied bots are avoided, enemies are targets
            if (other == null || other == m_InternalBotPlayerRefrences || !other.IsBotPlayer) continue;
            if (other.get_PlayerTeamHandler.m_PlayerTeam.Value != myTeam) continue;

            Vector2 away = myPosition - (Vector2)other.transform.position;
            float sqr = away.sqrMagnitude;

            if (sqr < avoidRadiusSqr && sqr < closestSqr)
            {
                closestSqr = sqr;
                closestDirection = away.normalized;
            }
        }

        if (closestSqr < _minBotDistance * _minBotDistance)
        {
            _isNearOtherBot = true;
            _avoidanceDirection = closestDirection;

            if (DebugOn)
            {
                RunLog($"Too close to ally bot! Distance: {Mathf.Sqrt(closestSqr):F1}m", nameof(CheckBotProximity));
            }
        }
    }

    // Modify ShouldFollowPath to account for bot proximity
    private bool ShouldFollowPath()
    {
        if (n_BotState.Value == BotState.Retreating) return false;
        if (_currentTarget == null) return false;

        // NEW: Don't follow path if too close to ally bot and moving backward
        if (_isNearOtherBot && n_BotState.Value == BotState.ChasingPlayer)
        {
            // Check if pathfinding direction conflicts with avoidance direction
            var pathDirection = (_currentTarget.position - transform.position).normalized;
            float dotProduct = Vector2.Dot(pathDirection, _avoidanceDirection);

            // If we need to move away from ally but path says move toward them, pause pathfinding
            if (dotProduct < -0.5f)
            {
                if (DebugOn)
                {
                    RunLog("Pausing pathfinding - avoiding ally bot collision", nameof(ShouldFollowPath));
                }
                return false;
            }
        }

        if (n_BotState.Value == BotState.ChasingPlayer)
        {
            return distanceToTarget < _followTargetActiveDistance;
        }

        return true;
    }

    // Modify MoveBackALittle to check for collisions
    private IEnumerator MoveBackALittle()
    {
        TransitionToState(BotState.Retreating);
        isRetreating = true;
        yield return Wait0_1;

        if (retreetPoint != null)
        {
            // Check if retreat path is clear
            Vector2 retreatDirection = (retreetPoint.position - transform.position).normalized;
            RaycastHit2D hit = Physics2D.Raycast(
                transform.position,
                -retreatDirection,
                2f,
                LayerMask.GetMask("Ground", "Wall")
            );

            if (hit.collider != null)
            {
                // Can't retreat - try jumping instead
                if (_aiCommands != null && _movementController.CanJump())
                {
                    _aiCommands.SetAIJumpState(true);
                    yield return Wait0_3;
                    RunLog("Jumped instead of retreating - path blocked", nameof(MoveBackALittle));
                }
            }
            else
            {
                gameObject.LeanMoveX(retreetPoint.position.x, 1f);
            }
        }

        yield return Wait1;
        isRetreating = false;

        if (_currentTargetPlayerRefs != null)
        {
            TransitionToState(BotState.ChasingPlayer);
        }
        else
        {
            TransitionToState(BotState.SearchingForTarget);
        }

        RunLog("Recovery complete", nameof(MoveBackALittle));
    }
    #endregion

    #region Decision Tick and FixedUpdate
    // One shared tick replaces the old per frame Update. The pathfinding input is only
    // read by BotAICommands every 0.1 s anyway, so the AI decisions gain nothing from
    // running every frame. Anything that has to follow the physics step stays in FixedUpdate.
    private void OnDecisionTick(float deltaTime)
    {
        // CRITICAL: Safety checks first
        if (!IsServer || !startBotAi || !gameRunnerFound) return;
        if (m_InternalBotPlayerRefrences.get_PlayerLoadoutScript.get_IsInitialized == false) return;

        // Safety net next to the health state callback: a dead bot runs no AI logic
        if (m_InternalBotPlayerRefrences?.get_PlayerHealthScript != null)
        {
            var healthComponent = m_InternalBotPlayerRefrences.get_PlayerHealthScript.GetHealthComponent();
            if (healthComponent != null && healthComponent.IsDead())
            {
                _aiCommands?.StopAllMovement();
                return;
            }
        }

        // Distance first, the state machine reads it
        if (_currentTarget != null)
        {
            UpdateDistanceToTarget();
        }

        UpdateBotStateMachine(deltaTime);
        UpdateWeaponSelection();
        UpdateWeaponSwitching();
    }

    private void FixedUpdate()
    {
        if (!IsServer || !startBotAi) return;
        if (_currentTarget == null) return;

        // Execute pathfinding movement
        if (ShouldFollowPath())
        {
            _pathfindingModule.ExecutePathFollowing();
        }
    }

    private void UpdateBotStateMachine(float deltaTime)
    {
        // CRITICAL: Don't do anything if AI is disabled
        if (!startBotAi)
        {
            return;
        }

        switch (n_BotState.Value)
        {
            case BotState.ChasingPlayer:
                HandleJetpackLogic();
                UpdateFireState();
                break;

            case BotState.PatrollingMap:
                // CRITICAL: Check if we're actually moving toward patrol point
                if (distanceToTarget <= minFireDistance)
                {
                    if (DebugOn)
                        RunLog("Reached patrol destination, finding new point", nameof(UpdateBotStateMachine));
                    SetNewPatrolPoint();
                }
                else if (_currentTarget != null)
                {
                    // Make sure we're still actively pathfinding to patrol point
                    if (!ShouldFollowPath())
                    {
                        if (DebugOn)
                            RunLog("Not following path while patrolling, resetting patrol", nameof(UpdateBotStateMachine));
                        SetNewPatrolPoint();
                    }
                }
                else
                {
                    // No target set while patrolling - this shouldn't happen
                    RunLogWarning("No target while patrolling - resetting", nameof(UpdateBotStateMachine));
                    SetNewPatrolPoint();
                }
                break;

            case BotState.GoingToMapPoint:
                _mapPointTimer -= deltaTime;
                if (_mapPointTimer <= 0 || distanceToTarget <= minFireDistance)
                {
                    RunLog("Finished map point behavior, searching for targets", nameof(UpdateBotStateMachine));
                    TransitionToState(BotState.SearchingForTarget);
                }
                break;

            case BotState.SearchingForTarget:
                // Don't just sit idle while searching - move around a bit
                if (_currentTarget == null)
                {
                    // Set a random patrol point to keep moving
                    if (DebugOn)
                        RunLog("No target while searching, setting patrol point", nameof(UpdateBotStateMachine));
                    SetNewPatrolPoint();
                    TransitionToState(BotState.PatrollingMap);
                }
                break;
        }
    }

    private void UpdateWeaponSelection()
    {
        if (_primaryGunScript != null && _secondaryGunScript != null)
        {
            switch (n_currentSelectedWeapon.Value)
            {
                case CurrentBotWeaponSelected.primary:
                    _currentShotPoint = _primaryGunScript.get_ShotPoint;
                    break;
                case CurrentBotWeaponSelected.secondary:
                    _currentShotPoint = _secondaryGunScript.get_ShotPoint;
                    break;
            }
        }
    }
    #endregion

    #region State Machine Handlers
    private void TransitionToState(BotState newState)
    {
        if (n_BotState.Value == newState) return;

        BotState oldState = n_BotState.Value;
        n_BotState.Value = newState;

        if (DebugOn) RunLog($"State Transition: {oldState} -> {newState}", nameof(TransitionToState));
    }

    private void OnBotStateChanged(BotState oldValue, BotState newValue)
    {
        // Handle state entry logic
        switch (newValue)
        {
            case BotState.SearchingForTarget:
                fireWeapon.Value = false;
                _targetIsWithinFireDistance = false;
                RunLog("Entered SEARCHING state", nameof(OnBotStateChanged));
                break;

            case BotState.ChasingPlayer:
                RunLog("Entered CHASING state", nameof(OnBotStateChanged));
                break;

            case BotState.PatrollingMap:
                fireWeapon.Value = false;
                _targetIsWithinFireDistance = false;
                SetNewPatrolPoint();
                RunLog("Entered PATROLLING state", nameof(OnBotStateChanged));
                break;

            case BotState.GoingToMapPoint:
                fireWeapon.Value = false;
                _targetIsWithinFireDistance = false;
                _mapPointTimer = _mapPointDuration;
                SetRandomMapPoint();
                RunLog("Entered GOING TO MAP POINT state", nameof(OnBotStateChanged));
                break;

            case BotState.Retreating:
                fireWeapon.Value = false;
                RunLog("Entered RETREATING state", nameof(OnBotStateChanged));
                break;
        }
    }
    #endregion

    #region Target Management - SIMPLIFIED
    private IEnumerator AttemptToFindPlayerTarget()
    {
        RunLog("Attempting to find initial player target...", nameof(AttemptToFindPlayerTarget));

        yield return Wait1;

        bool foundTarget = TryFindPlayerTarget();

        if (foundTarget)
        {
            TransitionToState(BotState.ChasingPlayer);
            RunLog("Initial target found! Starting chase.", nameof(AttemptToFindPlayerTarget));
        }
        else
        {
            TransitionToState(BotState.SearchingForTarget);
            RunLog("No initial target found, entering search mode.", nameof(AttemptToFindPlayerTarget));
        }
    }

    private bool TryFindPlayerTarget()
    {
        var all = IAmPlayerServiceLocator.All;

        float closestDistance = float.MaxValue;
        IAmPlayerServiceLocator closestTarget = null;
        int validTargetsFound = 0;

        for (int i = 0; i < all.Count; i++)
        {
            var player = all[i];
            if (!IsValidTarget(player)) continue;

            validTargetsFound++;
            float distance = Vector2.Distance(transform.position, player.transform.position);

            if (distance < closestDistance && distance <= _maxTargetCheckRadius)
            {
                closestDistance = distance;
                closestTarget = player;
            }
        }

        if (DebugOn)
        {
            RunLog($"Target search: Found {validTargetsFound} valid targets, closest: {(closestTarget != null ? closestDistance.ToString("F1") : "none")}",
                   nameof(TryFindPlayerTarget));
        }

        if (closestTarget != null)
        {
            SetTarget(closestTarget.transform, closestTarget);

            if (DebugOn)
                RunLog($"Found target: {closestTarget.name}, Distance: {closestDistance:F1}", nameof(TryFindPlayerTarget));

            return true;
        }

        // No valid targets found - go to patrol
        if (validTargetsFound == 0 && n_BotState.Value != BotState.PatrollingMap)
        {
            RunLog("No valid targets anywhere - transitioning to patrol", nameof(TryFindPlayerTarget));
            TransitionToState(BotState.PatrollingMap);
        }

        return false;
    }

    private bool IsValidTarget(IAmPlayerServiceLocator player)
    {
        if (player == null) return false;
        if (player == m_InternalBotPlayerRefrences) return false;

        // FIXED: Use new health component methods
        var healthComponent = player.get_PlayerHealthScript?.GetHealthComponent();
        if (healthComponent == null) return false;

        // Check if dead
        if (healthComponent.IsDead()) return false;

        // Check if spawning (invulnerable)
        if (healthComponent.IsSpawning()) return false;

        // Enemy check. Free For All makes everyone else a target, Survival makes nobody one.
        return NetTeamRules.AreEnemies(player, m_InternalBotPlayerRefrences);
    }

    private void SetTarget(Transform targetTransform, IAmPlayerServiceLocator playerRefs = null)
    {
        _currentTarget = targetTransform;
        _currentTargetPlayerRefs = playerRefs;

        _pathfindingModule.SetTarget(_currentTarget);

        if (_armController?.get_ArmMovmentController != null)
        {
            _armController.get_ArmMovmentController.SetBotAimTarget(_currentTarget);
        }

        if (DebugOn)
        {
            string targetType = playerRefs != null ? "PLAYER" : "MAP POINT";
            if (DebugOn) RunLog($"Set new target: {targetTransform.name} ({targetType})", nameof(SetTarget));
        }
    }

    private void ClearTarget()
    {
        _currentTarget = null;
        _currentTargetPlayerRefs = null;
        fireWeapon.Value = false;
        _targetIsWithinFireDistance = false;
        _pathfindingModule.ResetPath();

        RunLog("Cleared current target", nameof(ClearTarget));
    }

    private void ValidateCurrentTarget()
    {
        if (n_BotState.Value != BotState.ChasingPlayer) return;
        if (_currentTargetPlayerRefs == null)
        {
            // Target reference lost - search immediately
            RunLog("Target reference lost, searching for new target", nameof(ValidateCurrentTarget));
            ClearTarget();
            TransitionToState(BotState.SearchingForTarget);
            return;
        }

        // FIXED: Use new health component methods
        var healthComponent = _currentTargetPlayerRefs.get_PlayerHealthScript?.GetHealthComponent();
        if (healthComponent == null)
        {
            RunLog("Target health component missing!", nameof(ValidateCurrentTarget));
            ClearTarget();
            TransitionToState(BotState.SearchingForTarget);
            return;
        }

        bool targetDead = healthComponent.IsDead();
        bool targetSpawning = healthComponent.IsSpawning();
        bool targetTooFar = distanceToTarget >= _maxTargetLockDistance;

        if (targetDead || targetSpawning)
        {
            RunLog("Target is DEAD/SPAWNING - immediately searching for new target", nameof(ValidateCurrentTarget));
            ClearTarget();

            // Try to find new target immediately instead of just transitioning to search
            bool foundNewTarget = TryFindPlayerTarget();

            if (foundNewTarget)
            {
                RunLog("Found new target immediately after kill!", nameof(ValidateCurrentTarget));
                TransitionToState(BotState.ChasingPlayer);
            }
            else
            {
                RunLog("No immediate target found, entering search mode", nameof(ValidateCurrentTarget));
                TransitionToState(BotState.SearchingForTarget);
            }
        }
        else if (targetTooFar)
        {
            if (DebugOn) RunLog($"Target too far ({distanceToTarget:F1}m), searching for closer target", nameof(ValidateCurrentTarget));
            ClearTarget();

            // Try immediate target acquisition
            bool foundNewTarget = TryFindPlayerTarget();

            if (foundNewTarget)
            {
                TransitionToState(BotState.ChasingPlayer);
            }
            else
            {
                TransitionToState(BotState.SearchingForTarget);
            }
        }
    }

    // Add additional target validation during firing
    private void UpdateFireState()
    {
        if (n_BotState.Value != BotState.ChasingPlayer || _currentTargetPlayerRefs == null)
        {
            if (fireWeapon.Value || _targetIsWithinFireDistance)
            {
                fireWeapon.Value = false;
                _targetIsWithinFireDistance = false;
            }
            return;
        }

        // FIXED: Double-check target is still valid before firing
        var healthComponent = _currentTargetPlayerRefs.get_PlayerHealthScript?.GetHealthComponent();
        if (healthComponent == null || healthComponent.IsDead() || healthComponent.IsSpawning())
        {
            // Target just died mid-frame or is spawning
            RunLog("Target died/spawning during fire state update - stopping fire and searching", nameof(UpdateFireState));
            fireWeapon.Value = false;
            _targetIsWithinFireDistance = false;
            ClearTarget();
            TransitionToState(BotState.SearchingForTarget);
            return;
        }

        bool inRange = distanceToTarget < maxFireDistance && distanceToTarget > minFireDistance;
        bool targetAlive = healthComponent.IsAlive();

        if (inRange && targetAlive)
        {
            bool shouldFire = ShouldFireAtTarget();

            if (fireWeapon.Value != shouldFire)
            {
                fireWeapon.Value = shouldFire;
            }
            _targetIsWithinFireDistance = shouldFire;
        }
        else
        {
            if (_targetIsWithinFireDistance || fireWeapon.Value)
            {
                _targetIsWithinFireDistance = false;
                fireWeapon.Value = false;
            }
        }
    }
    #endregion

    #region Patrol System
    // Replace SetNewPatrolPoint in NetBotPlayer.cs

    private void SetNewPatrolPoint()
    {
        Transform patrolPoint = GetRandomEnemySpawnPoint();

        if (patrolPoint != null)
        {
            // CRITICAL: Make sure the patrol point isn't too close to current position
            float distanceToPatrolPoint = Vector2.Distance(transform.position, patrolPoint.position);

            if (distanceToPatrolPoint < 5f)
            {
                // Too close, get another point
                if (DebugOn)
                    RunLog($"Patrol point too close ({distanceToPatrolPoint:F1}m), getting another", nameof(SetNewPatrolPoint));

                // Try up to 3 times to get a better patrol point
                for (int i = 0; i < 3; i++)
                {
                    patrolPoint = GetRandomEnemySpawnPoint();
                    if (patrolPoint != null)
                    {
                        distanceToPatrolPoint = Vector2.Distance(transform.position, patrolPoint.position);
                        if (distanceToPatrolPoint >= 5f)
                        {
                            break;
                        }
                    }
                }
            }

            SetTarget(patrolPoint, null);
            if (DebugOn)
                RunLog($"Set patrol point: {patrolPoint.name} (Distance: {distanceToPatrolPoint:F1}m)", nameof(SetNewPatrolPoint));
        }
        else
        {
            RunLogWarning("Failed to find patrol point", nameof(SetNewPatrolPoint));

            // FALLBACK: If no patrol point found, just search for targets
            TransitionToState(BotState.SearchingForTarget);
        }
    }

    private void SetRandomMapPoint()
    {
        Transform mapPoint = UnityEngine.Random.value > 0.5f ?
            GetRandomEnemySpawnPoint() :
            _currentTarget;

        if (mapPoint != null)
        {
            SetTarget(mapPoint, null);
            if (DebugOn) RunLog($"Going to map point: {mapPoint.name} for {_mapPointDuration}s", nameof(SetRandomMapPoint));
        }
    }

    // Reused by every patrol point search
    private readonly List<Transform> _patrolCandidates = new List<Transform>();
    private readonly List<List<Transform>> _patrolLists = new List<List<Transform>>(3);

    // A point where the enemies of this bot spawn. NetTeamRules decides who the enemies are, so this
    // holds for every team: Blue goes to the Red points, Red to the Blue points, any other team and
    // Free For All to the free-for-all points, Survival to the survival ground spawns.
    private Transform GetRandomEnemySpawnPoint()
    {
        NetworkServerManeger server = NetworkServerManeger.networkServerSingleton;
        if (server == null) return null;

        _patrolCandidates.Clear();

        if (NetTeamRules.IsSurvival)
        {
            _patrolCandidates.AddRange(server.GetSurvivalGroundSpawnPoints());
        }
        else
        {
            AddEnemySpawnPoints(server);
        }

        // No enemy in the match yet, or the map has no points for them: any spawn point of the map
        if (_patrolCandidates.Count == 0)
        {
            server.CollectPlayerSpawnPoints(_patrolCandidates);
        }

        if (_patrolCandidates.Count == 0) return null;

        return _patrolCandidates[UnityEngine.Random.Range(0, _patrolCandidates.Count)];
    }

    // The spawn points of the teams of every enemy that is in the match, each list once
    private void AddEnemySpawnPoints(NetworkServerManeger server)
    {
        _patrolLists.Clear();

        IReadOnlyList<IAmPlayerServiceLocator> all = IAmPlayerServiceLocator.All;
        for (int i = 0; i < all.Count; i++)
        {
            IAmPlayerServiceLocator entity = all[i];
            if (entity == null || entity.get_PlayerTeamHandler == null) continue;
            if (!NetTeamRules.AreEnemies(m_InternalBotPlayerRefrences, entity)) continue;

            List<Transform> points = server.GetTeamSpawnPoints(entity.get_PlayerTeamHandler.m_PlayerTeam.Value);
            if (points != null && points.Count > 0 && !_patrolLists.Contains(points))
            {
                _patrolLists.Add(points);
            }
        }

        for (int i = 0; i < _patrolLists.Count; i++)
        {
            _patrolCandidates.AddRange(_patrolLists[i]);
        }
    }
    #endregion

    #region Combat and Aiming
    private void UpdateDistanceToTarget()
    {
        if (_currentTarget != null)
        {
            distanceToTarget = Vector2.Distance(transform.position, _currentTarget.position);
        }
    }

    private void UpdateBotAiming()
    {
        if (_armController?.get_ArmMovmentController == null || _currentTarget == null) return;

        _armController.get_ArmMovmentController.SetBotAimTarget(_currentTarget);
    }

    

    // The local human re-layers every entity from their own view (TeamPlayer: main 3, teammate 9,
    // enemy 10). The bot prefab mask covers only 7 and 10 to 12, so these two layers are added,
    // otherwise a human on layer 3 or 9 is invisible to the line of sight check.
    private const int HumanPlayerLayerBits = (1 << 3) | (1 << 9);

    private int LineOfSightMask => _rayCastLayers.value | HumanPlayerLayerBits;

    private bool ShouldFireAtTarget()
    {
        if (_currentShotPoint == null) return false;

        switch (n_BotDifficultyLevel.Value)
        {
            case BotDifficultyLevel.omoThisNaMaye:
            case BotDifficultyLevel.shegeaDanIska:
                // Elite bots: Only fire when direct line of sight to player
                RaycastHit2D hit = Physics2D.Raycast(_currentShotPoint.position, _currentShotPoint.right, maxFireDistance, LineOfSightMask);
                return hit.collider && hit.collider.CompareTag("Player");

            case BotDifficultyLevel.master:
                // Advanced bots: Fire if not hitting ground
                hit = Physics2D.Raycast(_currentShotPoint.position, _currentShotPoint.right, maxFireDistance, LineOfSightMask);
                return hit.collider && !hit.collider.CompareTag("Ground");

            case BotDifficultyLevel.basic:
            case BotDifficultyLevel.advanced:
            default:
                // Basic bots: Always fire when in range
                return true;
        }
    }

    private void HandleJetpackLogic()
    {
        var botMovement = _movementController;
        if (botMovement == null || distanceToTarget >= maxFireDistance)
        {
            m_InternalBotPlayerRefrences.get_JetpackHandlerScript?.StopEmmitJetpackFlameForBots();
            return;
        }

        bool shouldEmitFlame = false;
        bool isGrounded = botMovement.IsGrounded();
        bool hasJumpTime = botMovement.jumpTimeCounter.Value > 0;
        bool isJumping = botMovement.IsJumping();
        bool isSliding = botMovement.IsSliding();
        bool jetpackRefreshing = botMovement.IsJetpackRefreshing();

        if (!jetpackRefreshing && hasJumpTime)
        {
            if (isJumping && !isGrounded)
            {
                shouldEmitFlame = true;
            }
            else if (isSliding)
            {
                shouldEmitFlame = true;
            }
        }

        if (shouldEmitFlame)
        {
            m_InternalBotPlayerRefrences.get_JetpackHandlerScript?.EmmitJetpackFlameForBots();
        }
        else
        {
            m_InternalBotPlayerRefrences.get_JetpackHandlerScript?.StopEmmitJetpackFlameForBots();
        }
    }
    #endregion

    #region Weapon Management
    private void UpdateWeaponSwitching()
    {
        if (_isUsingPowerWeapon || _primaryGunScript == null || _secondaryGunScript == null) return;

        switch (n_currentSelectedWeapon.Value)
        {
            case CurrentBotWeaponSelected.primary:
                if (_primaryGunScript.get_CurrentAmmo <= 0 && _primaryGunScript.get_CurrentMaxAmmo <= 0)
                {
                    n_currentSelectedWeapon.Value = CurrentBotWeaponSelected.secondary;
                }
                break;
            case CurrentBotWeaponSelected.secondary:
                if (_secondaryGunScript.get_CurrentAmmo <= 0 && _secondaryGunScript.get_CurrentMaxAmmo <= 0)
                {
                    n_currentSelectedWeapon.Value = CurrentBotWeaponSelected.primary;
                }
                break;
        }
    }

    private IEnumerator SetupInitialWeapon()
    {
        if (m_InternalBotPlayerRefrences?.get_NetWeaponCategorizer == null)
        {
            yield return Wait1;
            if (m_InternalBotPlayerRefrences?.get_NetWeaponCategorizer == null)
            {
                RunLogError("WeaponCategorizer not found!", nameof(SetupInitialWeapon));
                yield break;
            }
        }

        var weaponCategorizer = m_InternalBotPlayerRefrences.get_NetWeaponCategorizer;

        int attempts = 0;
        while (weaponCategorizer.currentSelectedWeapon == null && attempts < 10)
        {
            yield return Wait0_5;
            attempts++;
        }

        if (weaponCategorizer.currentSelectedWeapon == null)
        {
            RunLogWarning("Current weapon still null after waiting", nameof(SetupInitialWeapon));
            yield break;
        }

        switch (weaponCategorizer.get_CurrentSelectedWeapon)
        {
            case NetcodeWeaponCatigorizer.WeaponSelected.primary:
                weaponCategorizer.currentSelectedWeapon.TryGetComponent(out GeneralGunHandler primaryGun);
                if (primaryGun == null) yield break;
                _primaryGunScript = primaryGun;
                RunLog("Primary weapon setup complete", nameof(SetupInitialWeapon));
                break;
            case NetcodeWeaponCatigorizer.WeaponSelected.secondary:
                weaponCategorizer.currentSelectedWeapon.TryGetComponent(out GeneralGunHandler secondaryGun);
                if (secondaryGun == null) yield break;
                _secondaryGunScript = secondaryGun;
                RunLog("Secondary weapon setup complete", nameof(SetupInitialWeapon));
                break;
            case NetcodeWeaponCatigorizer.WeaponSelected.powerWeapon:
                weaponCategorizer.currentSelectedWeapon.TryGetComponent(out PowerWeaponHandler powerWeapon);
                if (powerWeapon == null) yield break;
                _powerWeaponScript = powerWeapon;
                RunLog("Power weapon setup complete", nameof(SetupInitialWeapon));
                break;
        }
    }

    internal void PutPrimaryWeaponInPlace(GeneralGunHandler pS)
    {
        _primaryGunScript = pS;
        if (DebugOn) RunLog($"Primary weapon set: {pS.name}", nameof(PutPrimaryWeaponInPlace));
    }

    internal void PutSecondaryWeaponInPlace(GeneralGunHandler sS)
    {
        _secondaryGunScript = sS;
        if (DebugOn) RunLog($"Secondary weapon set: {sS.name}", nameof(PutSecondaryWeaponInPlace));
    }

    internal void PutPowerWeaponInPlace(PowerWeaponHandler pWS)
    {
        _powerWeaponScript = pWS;
        if (DebugOn) RunLog($"Power weapon set: {pWS.name}", nameof(PutPowerWeaponInPlace));
    }

    private void OnBotWeaponChanged(CurrentBotWeaponSelected oldValue, CurrentBotWeaponSelected newValue)
    {
        switch (n_currentSelectedWeapon.Value)
        {
            case CurrentBotWeaponSelected.primary:
                _isUsingPowerWeapon = false;
                m_InternalBotPlayerRefrences.get_NetWeaponCategorizer.SendWeaponSwapRequestToServerRpc(0);
                RunLog("Switched to PRIMARY", nameof(OnBotWeaponChanged));
                break;
            case CurrentBotWeaponSelected.secondary:
                _isUsingPowerWeapon = false;
                m_InternalBotPlayerRefrences.get_NetWeaponCategorizer.SendWeaponSwapRequestToServerRpc(1);
                RunLog("Switched to SECONDARY", nameof(OnBotWeaponChanged));
                break;
            case CurrentBotWeaponSelected.powerWeapon:
                _isUsingPowerWeapon = true;
                m_InternalBotPlayerRefrences.get_NetWeaponCategorizer.SendWeaponSwapRequestToServerRpc(3);
                RunLog("Switched to POWER WEAPON", nameof(OnBotWeaponChanged));
                break;
        }
    }
    #endregion

    #region AI Behavior Methods
    void CheckUniqueBotBehaviour()
    {
        if (!startBotAi) return;

        int count = Mathf.Min(_allPossibleUniqueBehaviours.Count, _uniqueBehaviouProbabilities.Count);
        int total = 0;
        for (int i = 0; i < count; i++) total += _uniqueBehaviouProbabilities[i];
        if (total <= 0) return;

        // The weights are relative, so every entry of a list can be reached whatever it adds up to
        int random = UnityEngine.Random.Range(0, total);
        int cumulative = 0;

        for (int i = 0; i < count; i++)
        {
            cumulative += _uniqueBehaviouProbabilities[i];
            if (random < cumulative)
            {
                // The variable only records the behaviour. It raises no change when the same behaviour
                // is rolled twice, so the behaviour runs here, on every roll.
                BotUniqueBehaviours chosen = _allPossibleUniqueBehaviours[i];
                n_CurrentBotSpecialBehaviour.Value = chosen;
                ExecuteUniqueBehaviour(chosen);
                break;
            }
        }
    }

    void SetBotDifficulty()
    {
        int total = 0;
        for (int i = 0; i < DifficultyWeights.Length; i++) total += DifficultyWeights[i];

        int random = UnityEngine.Random.Range(0, total);
        int cumulative = 0;

        for (int i = 0; i < DifficultyWeights.Length; i++)
        {
            cumulative += DifficultyWeights[i];
            if (random < cumulative)
            {
                BotDifficultyLevel previous = n_BotDifficultyLevel.Value;
                BotDifficultyLevel chosen = (BotDifficultyLevel)i;
                n_BotDifficultyLevel.Value = chosen;

                // The change callback configures the bot. A roll equal to the current value (basic is
                // the default) raises no change, so the settings are applied here instead.
                if (chosen == previous) ConfigureDifficultySettings();

                if (DebugOn) RunLog($"Bot difficulty set to: {chosen}", nameof(SetBotDifficulty));
                break;
            }
        }
    }

    void ExecuteUniqueBehaviour(BotUniqueBehaviours behaviour)
    {
        if (DebugOn) RunLog($"Executing unique behavior: {behaviour}", nameof(ExecuteUniqueBehaviour));

        switch (behaviour)
        {
            case BotUniqueBehaviours.returnToDefault:
                break;

            case BotUniqueBehaviours.crouch:
                if (_movementController != null && _movementController.IsGrounded())
                {
                    CancelDelay(ref _crouchDelay);
                    _aiCommands?.SetAICrouchState(true);
                    _crouchDelay = MID_TickDelay.After(2f, _standUpCb);
                }
                break;

            case BotUniqueBehaviours.slide:
                if (_movementController != null && _movementController.IsGrounded())
                {
                    _aiCommands?.TriggerAISlide();
                }
                break;

            case BotUniqueBehaviours.throwGrenade:
                if (_targetIsWithinFireDistance && _currentShotPoint != null && _currentTarget != null)
                {
                    Vector2 throwDirection = (_currentTarget.position - _currentShotPoint.position).normalized;
                    float throwForce = UnityEngine.Random.Range(15f, 25f);

                    m_InternalBotPlayerRefrences.get_PlayerGrenadeHandler.ExecuteBotGrenadeSequence(
                        _currentShotPoint.position,
                        Quaternion.LookRotation(Vector3.forward, throwDirection),
                        throwForce
                    );
                }
                break;

            case BotUniqueBehaviours.switchToNewWeapon:
                SwitchToAlternativeWeapon();
                break;

            case BotUniqueBehaviours.switchToPowerWeapon:
                if (_powerWeaponScript != null && m_InternalBotPlayerRefrences.get_NetWeaponCategorizer.get_CanUsePowerWeapon)
                {
                    n_currentSelectedWeapon.Value = CurrentBotWeaponSelected.powerWeapon;
                }
                break;

            case BotUniqueBehaviours.summon:
                m_InternalBotPlayerRefrences.get_SummonsHandler.CallSummonForBots();
                break;

            case BotUniqueBehaviours.goToMapPoint:
                if (UnityEngine.Random.value < _mapPointBehaviorChance)
                {
                    TransitionToState(BotState.GoingToMapPoint);
                    RunLog("Going to map point instead of chasing!", nameof(ExecuteUniqueBehaviour));
                }
                break;
        }
    }

    private void OnStandUp()
    {
        _crouchDelay = null;
        _aiCommands?.SetAICrouchState(false);
    }

    private void SwitchToAlternativeWeapon()
    {
        switch (n_currentSelectedWeapon.Value)
        {
            case CurrentBotWeaponSelected.primary:
                n_currentSelectedWeapon.Value = CurrentBotWeaponSelected.secondary;
                break;
            case CurrentBotWeaponSelected.secondary:
                n_currentSelectedWeapon.Value = CurrentBotWeaponSelected.primary;
                break;
            case CurrentBotWeaponSelected.powerWeapon:
                n_currentSelectedWeapon.Value = CurrentBotWeaponSelected.primary;
                break;
        }
    }

    void OnBotDifficultyChanged(BotDifficultyLevel oldValue, BotDifficultyLevel newValue)
    {
        if (!IsServer) return;

        ConfigureDifficultySettings();
        CheckUniqueBotBehaviour();
    }

    private void ConfigureDifficultySettings()
    {
        switch (n_BotDifficultyLevel.Value)
        {
            case BotDifficultyLevel.basic:
                _uniqueBehaviouProbabilities = new List<int> { 5000, 4000, 1000 };
                _allPossibleUniqueBehaviours = new List<BotUniqueBehaviours> {
                    BotUniqueBehaviours.returnToDefault,
                    BotUniqueBehaviours.crouch,
                    BotUniqueBehaviours.slide
                };
                botFireRate = 0.2f;
                _maxSpeed = 300f;
                _pathfindingModule?.SetConfiguration(3f, 0.8f, -0.8f, 0.7f);
                break;

            case BotDifficultyLevel.advanced:
                _uniqueBehaviouProbabilities = new List<int> { 5000, 4500, 300, 200 };
                _allPossibleUniqueBehaviours = new List<BotUniqueBehaviours> {
                    BotUniqueBehaviours.returnToDefault,
                    BotUniqueBehaviours.crouch,
                    BotUniqueBehaviours.slide,
                    BotUniqueBehaviours.throwGrenade
                };
                botFireRate = 0.15f;
                _maxSpeed = 350f;
                _pathfindingModule?.SetConfiguration(3f, 0.8f, -0.8f, 0.5f);
                break;

            case BotDifficultyLevel.master:
                _uniqueBehaviouProbabilities = new List<int> { 5000, 3800, 600, 400, 200 };
                _allPossibleUniqueBehaviours = new List<BotUniqueBehaviours> {
                    BotUniqueBehaviours.returnToDefault,
                    BotUniqueBehaviours.crouch,
                    BotUniqueBehaviours.slide,
                    BotUniqueBehaviours.throwGrenade,
                    BotUniqueBehaviours.switchToNewWeapon
                };
                botFireRate = 0.1f;
                _maxSpeed = 400f;
                _pathfindingModule?.SetConfiguration(3f, 0.8f, -0.8f, 0.4f);
                break;

            case BotDifficultyLevel.omoThisNaMaye:
                _uniqueBehaviouProbabilities = new List<int> { 5000, 3000, 1000, 600, 200, 200, 100 };
                _allPossibleUniqueBehaviours = new List<BotUniqueBehaviours> {
                    BotUniqueBehaviours.returnToDefault,
                    BotUniqueBehaviours.crouch,
                    BotUniqueBehaviours.slide,
                    BotUniqueBehaviours.throwGrenade,
                    BotUniqueBehaviours.switchToNewWeapon,
                    BotUniqueBehaviours.switchToPowerWeapon,
                    BotUniqueBehaviours.goToMapPoint
                };
                botFireRate = 0.05f;
                _maxSpeed = 432f;
                _pathfindingModule?.SetConfiguration(3f, 0.8f, -0.8f, 0.35f);
                break;

            case BotDifficultyLevel.shegeaDanIska:
                _uniqueBehaviouProbabilities = new List<int> { 3000, 2000, 1500, 1000, 900, 800, 800, 100 };
                _allPossibleUniqueBehaviours = new List<BotUniqueBehaviours> {
                    BotUniqueBehaviours.returnToDefault,
                    BotUniqueBehaviours.crouch,
                    BotUniqueBehaviours.slide,
                    BotUniqueBehaviours.throwGrenade,
                    BotUniqueBehaviours.switchToNewWeapon,
                    BotUniqueBehaviours.switchToPowerWeapon,
                    BotUniqueBehaviours.summon,
                    BotUniqueBehaviours.goToMapPoint
                };
                botFireRate = 0.01f;
                _maxSpeed = 450f;
                _pathfindingModule?.SetConfiguration(3f, 0.8f, -0.8f, 0.3f);
                break;
        }

        if (DebugOn) RunLog($"Configured settings for {n_BotDifficultyLevel.Value}", nameof(ConfigureDifficultySettings));
    }
    #endregion

    #region Combat Tick
    void OnShouldFireValueChanged(bool oldValue, bool newValue)
    {
        if (!IsServer) return;

        if (fireWeapon.Value) StartFireTick();
        else StopFireTick();
    }

    private void StartFireTick()
    {
        if (_fireTickActive) return;

        _fireTimer = 0f;
        _fireTickActive = true;
        MID_TickDispatcher.Subscribe(FireTickRate, OnFireTick);
    }

    private void StopFireTick()
    {
        if (!_fireTickActive) return;

        _fireTickActive = false;
        MID_TickDispatcher.Unsubscribe(FireTickRate, OnFireTick);

        // BotShoot keeps the power weapon firing until it is told to stop
        if (_powerWeaponScript != null) _powerWeaponScript.StopBotShoot();
    }

    private void OnFireTick(float deltaTime)
    {
        if (!IsServer) return;

        if (!fireWeapon.Value)
        {
            StopFireTick();
            return;
        }

        // Check if bot is alive before firing
        if (m_InternalBotPlayerRefrences?.get_PlayerHealthScript != null)
        {
            var healthComponent = m_InternalBotPlayerRefrences.get_PlayerHealthScript.GetHealthComponent();
            if (healthComponent != null && healthComponent.IsDead())
            {
                if (DebugOn) RunLog("Bot is dead, stopping fire", nameof(OnFireTick));
                fireWeapon.Value = false;
                StopFireTick();
                return;
            }
        }

        // The AI has to be active
        if (!startBotAi)
        {
            if (DebugOn) RunLog("AI disabled, stopping fire", nameof(OnFireTick));
            fireWeapon.Value = false;
            StopFireTick();
            return;
        }

        // Tiers faster than the tick still shoot once per tick, the gun cooldown limits the rest.
        float interval = Mathf.Max(botFireRate, deltaTime);
        _fireTimer += deltaTime;
        if (_fireTimer + 0.001f < interval) return;
        _fireTimer = 0f;

        if (m_InternalBotPlayerRefrences?.get_NetWeaponCategorizer == null) return;

        switch (m_InternalBotPlayerRefrences.get_NetWeaponCategorizer.get_CurrentSelectedWeapon)
        {
            case NetcodeWeaponCatigorizer.WeaponSelected.primary:
                if (_primaryGunScript != null && !_primaryGunScript.get_IsReloading)
                {
                    _primaryGunScript.ShootForBots();
                }
                break;

            case NetcodeWeaponCatigorizer.WeaponSelected.secondary:
                if (_secondaryGunScript != null && !_secondaryGunScript.get_IsReloading)
                {
                    _secondaryGunScript.ShootForBots();
                }
                break;

            case NetcodeWeaponCatigorizer.WeaponSelected.powerWeapon:
                if (_powerWeaponScript != null)
                {
                    _powerWeaponScript.BotShoot();
                }
                break;
        }
    }
    #endregion

    #region Stuck Detection and Recovery
    // Stuck means no real progress over consecutive checks while the bot is meant to
    // be walking to a target that is still out of its comfortable fire range. The old
    // check stored the position and compared it with itself in the same call, so it
    // reported stuck on every check.
    public void CheckIfBotPlayerIsStuck()
    {
        if (!IsServer || !IsSpawned || _currentTarget == null || !startBotAi)
        {
            _stuckStrikes = 0;
            return;
        }

        Vector2 position = transform.position;
        bool progressed = (position - _stuckSamplePosition).sqrMagnitude >= StuckMinProgress * StuckMinProgress;
        _stuckSamplePosition = position;

        if (progressed || distanceToTarget <= minFireDistance || !ShouldFollowPath())
        {
            _stuckStrikes = 0;
            if (isStuck.Value) isStuck.Value = false;
            return;
        }

        _stuckStrikes++;
        if (_stuckStrikes >= StuckStrikesNeeded && !isStuck.Value)
        {
            isStuck.Value = true;
        }
    }

    private void OnIsStuckValueChanged(bool oldValue, bool newValue)
    {
        if (!newValue || _recoveryRoutine != null) return;
        if (!(_movementController?.IsGrounded() ?? false)) return;
        if (!ShouldFollowPath()) return;

        _recoveryRoutine = StartCoroutine(RecoverFromStuck());
    }

    private IEnumerator RecoverFromStuck()
    {
        RunLog("Bot is stuck! Attempting recovery...", nameof(RecoverFromStuck));

        if (_aiCommands != null && _movementController.CanJump())
        {
            _aiCommands.SetAIJumpState(true);
            yield return Wait0_3;
        }

        if (isStuck.Value)
        {
            yield return MoveBackALittle();
        }

        _recoveryRoutine = null;
    }

    
    #endregion


    #region Event Handlers
    private void OnMatchModeAndTimerStateChanged(TimerState oldValue, TimerState newValue)
    {
        switch (newValue)
        {
            case TimerState.InMatch:
                InitializeBot();
                RunLog("Match started, initializing bot", nameof(OnMatchModeAndTimerStateChanged));
                break;
        }
    }

    // Replace OnBotHealthStateChanged in NetBotPlayer.cs

    /// <summary>
    /// Called when bot's health state changes (Spawning -> Alive -> Dead)
    /// </summary>
    private void OnBotHealthStateChanged(NetHealthComponent.HealthState newState)
    {
        if (DebugOn) RunLog($"Bot health state changed to: {newState}", nameof(OnBotHealthStateChanged));

        switch (newState)
        {
            case NetHealthComponent.HealthState.Spawning:
                // Bot is spawning/respawning - disable AI
                RunLog("Bot spawning, disabling AI temporarily", nameof(OnBotHealthStateChanged));
                CancelDelay(ref _aliveDelay);
                startBotAi = false;

                // Stop all movement
                if (_aiCommands != null)
                {
                    _aiCommands.StopAllMovement();
                }

                // Stop firing
                fireWeapon.Value = false;
                StopFireTick();

                // Disable weapons
                if (m_InternalBotPlayerRefrences?.get_NetWeaponCategorizer != null)
                {
                    m_InternalBotPlayerRefrences.get_NetWeaponCategorizer.TunOffAllWeapons();
                }

                // Clear target
                ClearTarget();
                break;

            case NetHealthComponent.HealthState.Alive:
                // Bot became alive - re-enable AI once its position has synced.
                // A later Spawning or Dead state cancels the wait.
                RunLog("Bot now alive, re-enabling AI", nameof(OnBotHealthStateChanged));
                CancelDelay(ref _aliveDelay);
                _aliveDelay = MID_TickDelay.After(1f, _enableAiCb);
                break;

            case NetHealthComponent.HealthState.Dead:
                // Bot died - AI already disabled by health component
                RunLog("Bot died", nameof(OnBotHealthStateChanged));
                CancelDelay(ref _aliveDelay);
                startBotAi = false;

                // Ensure everything is stopped
                if (_aiCommands != null)
                {
                    _aiCommands.StopAllMovement();
                }

                fireWeapon.Value = false;
                StopFireTick();

                ClearTarget();
                ResetBotState();
                break;
        }
    }

    // Runs one second after the bot became alive, so its position has synced.
    private void OnEnableAiAfterRespawn()
    {
        _aliveDelay = null;
        if (!IsServer || !IsSpawned) return;

        // Re-enable AI
        startBotAi = true;

        // Re-enable weapons
        if (m_InternalBotPlayerRefrences?.get_NetWeaponCategorizer != null)
        {
            m_InternalBotPlayerRefrences.get_NetWeaponCategorizer.ReEnableCurrentWeapon();
        }

        // Force immediate target search
        RunLog("Searching for targets after becoming alive", nameof(OnEnableAiAfterRespawn));

        if (TryFindPlayerTarget())
        {
            TransitionToState(BotState.ChasingPlayer);
            RunLog("Found target immediately after respawn!", nameof(OnEnableAiAfterRespawn));
        }
        else
        {
            TransitionToState(BotState.SearchingForTarget);
            RunLog("No immediate target, entering search mode", nameof(OnEnableAiAfterRespawn));
        }
    }
    // Replace ResetBotState in NetBotPlayer.cs

    private void ResetBotState()
    {
        RunLog("=== RESETTING BOT STATE ===", nameof(ResetBotState));

        // Clear target
        ClearTarget();

        // Reset animation
        m_ArmAnimationStates.Value = ArmAnimationState.State.Idle;

        // Stop firing
        StopFireTick();
        fireWeapon.Value = false;
        _targetIsWithinFireDistance = false;

        // Stop all movement commands
        if (_aiCommands != null)
        {
            _aiCommands.StopAllMovement();
        }

        // Reset pathfinding
        if (_pathfindingModule != null)
        {
            _pathfindingModule.ResetPath();
        }

        // Reset stuck detection and any recovery in progress
        StopRoutine(ref _recoveryRoutine);
        CancelDelay(ref _crouchDelay);
        isStuck.Value = false;
        isRetreating = false;
        _stuckStrikes = 0;

        // Reset spatial awareness
        _isNearOtherBot = false;
        _avoidanceDirection = Vector2.zero;

        RunLog("Bot state reset complete", nameof(ResetBotState));
    }

    private void StopBotRoutines()
    {
        StopRoutine(ref _initRoutine);
        StopRoutine(ref _recoveryRoutine);
        CancelDelay(ref _aliveDelay);
        CancelDelay(ref _crouchDelay);
        isRetreating = false;
    }

    private static void CancelDelay(ref TickDelayHandle? handle)
    {
        if (!handle.HasValue) return;
        handle.Value.Cancel();
        handle = null;
    }

    private void StopRoutine(ref Coroutine routine)
    {
        if (routine == null) return;
        StopCoroutine(routine);
        routine = null;
    }
    #endregion

    #region Debug Utilities
    [ContextMenu("Print Bot State")]
    private void PrintBotState()
    {
        string targetInfo = _currentTarget != null ?
            $"{_currentTarget.name} ({distanceToTarget:F1}m)" :
            "NONE";
        string targetType = _currentTargetPlayerRefs != null ? "PLAYER" : "MAP POINT";

        MID_Logger.LogInfo(MID_LogLevel.Info,
            $"State: {n_BotState.Value}\n" +
            $"Difficulty: {n_BotDifficultyLevel.Value}\n" +
            $"Target: {targetInfo} ({targetType})\n" +
            $"Fire State: {fireWeapon.Value}\n" +
            $"Weapon: {n_currentSelectedWeapon.Value}\n" +
            $"Is Stuck: {isStuck.Value}\n" +
            $"AI Active: {startBotAi}\n" +
            $"Tick System Active: {_isTickSystemActive}",
            nameof(NetBotPlayer), nameof(PrintBotState));
    }

    [ContextMenu("Force Find Target")]
    private void ForceFindTarget()
    {
        if (!IsServer)
        {
            MID_Logger.LogInfo(MID_LogLevel.Info, "Must be server to force find target",
                nameof(NetBotPlayer), nameof(ForceFindTarget));
            return;
        }

        if (TryFindPlayerTarget())
        {
            MID_Logger.LogInfo(MID_LogLevel.Info, $"Target found: {_currentTarget.name}",
                nameof(NetBotPlayer), nameof(ForceFindTarget));
            TransitionToState(BotState.ChasingPlayer);
        }
        else
        {
            MID_Logger.LogInfo(MID_LogLevel.Info, "No target found",
                nameof(NetBotPlayer), nameof(ForceFindTarget));
        }
    }
    #endregion

    #region Logging Helper Methods (Always at bottom of script)
    // Debug messages that build an interpolated string are guarded with DebugOn at
    // the call site, so the string is not built while logging is below Debug.
    private bool DebugOn => _logLevel >= MID_LogLevel.Debug;

    private void RunLog(string message, string methodName = "") =>
        MID_Logger.LogDebug(_logLevel, message, nameof(NetBotPlayer), methodName);

    private void RunLogWarning(string message, string methodName = "") =>
        MID_Logger.LogWarning(_logLevel, message, nameof(NetBotPlayer), methodName);

    private void RunLogError(string message, string methodName = "", Exception e = null) =>
        MID_Logger.LogError(_logLevel, message, nameof(NetBotPlayer), methodName, e);
    #endregion
}
