﻿// ============================================================================
// NOTICE: Full documentation and design decisions for this file
// live in docs/StickToTheDeath/bots.md, section "Summons"
// ============================================================================
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;
using MidManStudio.Sttd.InGame.EquipableItemConfigs;
using MidManStudio.Core.Logging;
using MidManStudio.Core.Pools;
using MidManStudio.Sttd.InGame.AI;
using MidManStudio.Netcode.Pools;

namespace MidManStudio.Sttd.InGame.Summons
{
    /// <summary>
    /// Swarm summon (BookOfSwarm) - periodically spawns fly minions
    /// Minions use NetAiSummon for AI
    /// </summary>
    public class SwarmBehavior : MonoBehaviour, ISummonBehavior
    {
        [SerializeField] private MID_LogLevel _logLevel = MID_LogLevel.Error;

        private static readonly WaitForSeconds SpawnPoll = new WaitForSeconds(0.5f);

        private SummonBlueprint _owner;
        private ScoreSummonsConfigScriptableObject _config;
        private float _nextTimeToSpawn = 0f;
        private Coroutine _spawnCoroutine;

        public void Initialize(SummonBlueprint owner, ScoreSummonsConfigScriptableObject config)
        {
            _owner = owner;
            _config = config;

            // Start spawning flies
            if (_owner.IsServer)
            {
                _spawnCoroutine = StartCoroutine(SpawnSwarmFlies());
            }

            // Play spawn effect
            if (_owner.GetExtraItems() != null &&
                _owner.GetExtraItems().HasItem(SummonExtraItemType.SpawnEffect))
            {
                var spawnEffect = _owner.GetExtraItems().GetParticleSystem(SummonExtraItemType.SpawnEffect);
                if (spawnEffect != null)
                {
                    spawnEffect.Play();
                }
            }

            // Play idle aura
            if (_owner.GetExtraItems() != null &&
                _owner.GetExtraItems().HasItem(SummonExtraItemType.IdleAura))
            {
                var aura = _owner.GetExtraItems().GetParticleSystem(SummonExtraItemType.IdleAura);
                if (aura != null)
                {
                    aura.Play();
                }
            }

            RunLog("Swarm spawner initialized", nameof(Initialize));
        }

        public void OnUpdate()
        {
            // Spawning handled by coroutine
        }

        public void OnCleanup()
        {
            if (_spawnCoroutine != null)
            {
                StopCoroutine(_spawnCoroutine);
            }

            RunLog("Swarm cleanup complete", nameof(OnCleanup));
        }

        private IEnumerator SpawnSwarmFlies()
        {
            while (_owner.IsSpawned)
            {
                yield return SpawnPoll;

                if (Time.time >= _nextTimeToSpawn)
                {
                    _nextTimeToSpawn = Time.time + 1f / _config.get_ProjectileSpawnRate;
                    SpawnFly();
                }
            }
        }

        private void SpawnFly()
        {
            // Random spawn position around swarm spawner
            Vector2 randomOffset = new Vector2(
                Random.Range(0f, 5f),
                Random.Range(0f, 10f)
            );
            Vector2 spawnPosition = (Vector2)_owner.transform.position + randomOffset;

            // Get minion from pool
            var flyNetObj = MID_NetworkObjectPool.Instance.GetNetworkObject(
                PoolableNetworkObjectType.SummonMinion_Blueprint,
                spawnPosition,
                Quaternion.identity
            );

            if (flyNetObj == null)
            {
                RunLogError("Failed to get swarm fly from pool", nameof(SpawnFly));
                return;
            }

            // CRITICAL: Move to gameplay scene
            Scene gameplayScene = _owner.GetGameplayScene();
            if (gameplayScene.IsValid() && gameplayScene.isLoaded)
            {
                SceneManager.MoveGameObjectToScene(flyNetObj.gameObject, gameplayScene);
            }

            // Setup fly AI
            var flyAI = flyNetObj.GetComponent<NetAiSummon>();
            if (flyAI != null)
            {
                flyAI.SetOwner(_owner.GetOwnerClientId());
                flyAI.SetOwnerRefs(GetOwnerPlayerRefs());
            }

            // Spawn on network
            flyNetObj.Spawn();

            RunLog("Spawned swarm fly from pool", nameof(SpawnFly));
        }

        private IAmPlayerServiceLocator GetOwnerPlayerRefs()
        {
            ulong ownerId = _owner.GetOwnerClientId();
            IReadOnlyList<IAmPlayerServiceLocator> all = IAmPlayerServiceLocator.All;
            for (int i = 0; i < all.Count; i++)
            {
                IAmPlayerServiceLocator player = all[i];
                if (player != null && player.get__MID__PlayerOrBotOwnerId == ownerId)
                {
                    return player;
                }
            }
            return null;
        }

        private void RunLog(string message, string methodName = "") =>
            MID_Logger.LogDebug(_logLevel, message, nameof(SwarmBehavior), methodName);

        private void RunLogError(string message, string methodName = "") =>
            MID_Logger.LogError(_logLevel, message, nameof(SwarmBehavior), methodName);
    }
}
