﻿// ============================================================================
// NOTICE: Full documentation and design decisions for this file
// live in docs/StickToTheDeath/bots.md, section "Summons"
// ============================================================================
using UnityEngine;
using UnityEngine.SceneManagement;
using Pathfinding;
using MidManStudio.Sttd.InGame.EquipableItemConfigs;
using MidManStudio.Sttd.InGame.NetworkDataStructures;
using MidManStudio.Core.Logging;
using MidManStudio.Core.Pools;
using MidManStudio.Sttd.InGame.AI;
using MidManStudio.Sttd.InGame.Setup;
using MidManStudio.Sttd.InGame.GameItemData;
using MidManStudio.Netcode.Pools;

namespace MidManStudio.Sttd.InGame.Summons
{
    /// <summary>
    /// Hunter summon - seeks enemies, explodes on contact, spawns minions
    /// Uses NetAiPathfindingModule for movement
    /// </summary>
    [RequireComponent(typeof(NetAiPathfindingModule))]
    [RequireComponent(typeof(Seeker))]
    public class HunterBehavior : MonoBehaviour, ISummonBehavior
    {
        [SerializeField] private MID_LogLevel _logLevel = MID_LogLevel.Error;

        private SummonBlueprint _owner;
        private ScoreSummonsConfigScriptableObject _config;
        private NetAiPathfindingModule _pathfinding;
        private Seeker _seeker;
        private Transform _target;
        private IAmPlayerServiceLocator _targetRefs;
        private float _nextTargetSearchTime;
        private bool _hasExploded = false;

        // A hunter without a valid target looks again at this interval, not every frame
        private const float TargetSearchInterval = 0.2f;

        public void Initialize(SummonBlueprint owner, ScoreSummonsConfigScriptableObject config)
        {
            _owner = owner;
            _config = config;

            // Get pathfinding module
            _pathfinding = _owner.GetComponent<NetAiPathfindingModule>();
            _seeker = _owner.GetComponent<Seeker>();

            if (_pathfinding == null)
            {
                RunLogError("NetAiPathfindingModule missing on Hunter!", nameof(Initialize));
                return;
            }

            // Initialize pathfinding
            _pathfinding.Initialize(_owner.GetRigidbody());
            _pathfinding.SetSpeed(_config.get_MaxSpeed);

            // Find target
            FindTarget();

            if (_target != null)
            {
                _pathfinding.SetTarget(_target);
                _pathfinding.StartPathfinding();
            }

            // Visual: rotate animation
            LeanTween.rotateZ(_owner.gameObject, 360f, 2f).setLoopPingPong();

            // Play spawn effect
            if (_owner.GetExtraItems() != null &&
                _owner.GetExtraItems().HasItem(SummonExtraItemType.SpawnEffect))
            {
                var spawnEffect = _owner.GetExtraItems().GetParticleSystem(SummonExtraItemType.SpawnEffect);
                if (spawnEffect != null)
                {
                    spawnEffect.Play();
                }
            }

            RunLog("Hunter initialized and seeking target", nameof(Initialize));
        }

        public void OnUpdate()
        {
            if (_hasExploded) return;

            // Pathfinding module handles movement automatically in FixedUpdate
            // Just need to update target if it's lost
            if (IsTargetValid()) return;

            if (Time.time < _nextTargetSearchTime) return;
            _nextTargetSearchTime = Time.time + TargetSearchInterval;

            FindTarget();

            if (_target != null)
            {
                _pathfinding.SetTarget(_target);
            }
        }

        public void OnCleanup()
        {
            CancelInvoke();

            if (_pathfinding != null)
            {
                _pathfinding.StopPathfinding();
            }

            LeanTween.cancel(_owner.gameObject);

            RunLog("Hunter cleanup complete", nameof(OnCleanup));
        }

        private void OnCollisionEnter2D(Collision2D collision)
        {
            if (_hasExploded) return;
            if (!_owner.IsServer) return;

            // Check if hit enemy. Free For All makes everyone but the owner an enemy.
            if (collision.gameObject.TryGetComponent(out IAmPlayerServiceLocator targetRefs))
            {
                var ownerRefs = GetOwnerPlayerRefs();
                if (ownerRefs != null && MidManStudio.Sttd.InGame.Setup.NetTeamRules.AreEnemies(targetRefs, ownerRefs))
                {
                    // Hit enemy - explode!
                    Explode();
                    SpawnMinions();
                }
            }
        }

        private void FindTarget()
        {
            var ownerRefs = GetOwnerPlayerRefs();
            if (ownerRefs == null)
            {
                RunLogWarning("Cannot find target - owner refs null", nameof(FindTarget));
                return;
            }

            var allPossibleTargets = IAmPlayerServiceLocator.All;
            float closestSqrDistance = float.MaxValue;
            IAmPlayerServiceLocator closestRefs = null;

            for (int i = 0; i < allPossibleTargets.Count; i++)
            {
                var targetRef = allPossibleTargets[i];
                if (targetRef == null) continue;

                // Skip the owner and its allies. In Free For All everyone but the owner is a target.
                if (!MidManStudio.Sttd.InGame.Setup.NetTeamRules.AreEnemies(targetRef, ownerRefs))
                    continue;

                // Skip dead
                var targetHealth = targetRef.get_PlayerHealthScript;
                if (targetHealth == null || targetHealth.GetHealthComponent().GetCurrentHealth() <= 0)
                    continue;

                float sqrDistance = ((Vector2)transform.position - (Vector2)targetRef.transform.position).sqrMagnitude;
                if (sqrDistance < closestSqrDistance)
                {
                    closestSqrDistance = sqrDistance;
                    closestRefs = targetRef;
                }
            }

            if (closestRefs != null)
            {
                _targetRefs = closestRefs;
                _target = closestRefs.transform;
                if (DebugOn) RunLog($"Target acquired: {closestRefs.name}", nameof(FindTarget));
            }
        }

        // The locator of the target is kept, so the check costs no component lookup
        private bool IsTargetValid()
        {
            if (_target == null || _targetRefs == null) return false;

            var playerHealth = _targetRefs.get_PlayerHealthScript;
            return playerHealth != null && playerHealth.GetHealthComponent().GetCurrentHealth() > 0;
        }

        private void Explode()
        {
            if (_hasExploded) return;
            _hasExploded = true;

            RunLog("Hunter exploding!", nameof(Explode));

            // Play explosion effect
            SpawnExplosionEffect(transform.position);
            SpawnExplosionEffectClientRpc(transform.position);

            // Deal damage in radius
            Collider2D[] colliders = Physics2D.OverlapCircleAll(
                transform.position,
                _config.get_ExplosionRadius
            );

            var explosionOwnerRefs = GetOwnerPlayerRefs();

            foreach (Collider2D collider in colliders)
            {
                if (!collider.TryGetComponent(out IAmPlayerServiceLocator targetRefs)) continue;

                var playerHealth = targetRefs.get_PlayerHealthScript;
                if (playerHealth == null) continue;

                // Check teams. The owner and its allies are never damaged.
                if (explosionOwnerRefs != null && !MidManStudio.Sttd.InGame.Setup.NetTeamRules.AreEnemies(targetRefs, explosionOwnerRefs))
                    continue;

                // Apply explosion force
                var targetRb = collider.attachedRigidbody;
                if (targetRb != null)
                {
                    Vector2 explosionDirection = collider.transform.position - transform.position;
                    targetRb.AddForce(explosionDirection.normalized * _config.get_ExplosionForce,
                        ForceMode2D.Impulse);
                }

                // Deal damage
                if (playerHealth.GetHealthComponent().CanTakeDamage())
                {
                    // The id of the entity, not the network owner: every bot is owned by the host
                    ulong targetId = targetRefs.get__MID__PlayerOrBotOwnerId;
                    ulong senderId = _owner.GetOwnerClientId();

                    DoDamageRequest damageRequest = new DoDamageRequest(
                        _config.get_ExplosionDamage,
                        senderId,
                        targetId,
                        true,
                        NetDamageHandler.GetRegularDamageType(senderId, targetId),
                        new MID_PlayerKillTypeAndPoints
                        {
                            _playerKillType = MID_PlayerKillType.Killer,
                            _valueInPoints = 100
                        },
                        MID_WhatWeaponDamagedPlayer.ScoreSummon,
                        new ExplosionPoint()
                    );

                    NetworkServerManeger.networkServerSingleton.DoDamageRequestServerRpc(damageRequest);
                }
            }

            // Stop pathfinding
            if (_pathfinding != null)
            {
                _pathfinding.StopPathfinding();
            }
        }

        private void SpawnMinions()
        {
            if (!_owner.IsServer) return;

            if (DebugOn) RunLog($"Spawning {_config.get_MaxMininonAmmount} minions", nameof(SpawnMinions));

            var minionOwnerRefs = GetOwnerPlayerRefs();

            for (int i = 0; i < _config.get_MaxMininonAmmount; i++)
            {
                Vector2 randomOffset = new Vector2(
                    Random.Range(-2f, 2f),
                    Random.Range(-2f, 2f)
                );
                Vector2 spawnPosition = (Vector2)transform.position + randomOffset;

                // Get minion from pool
                var minionNetObj = MID_NetworkObjectPool.Instance.GetNetworkObject(
                    PoolableNetworkObjectType.SummonMinion_Blueprint,
                    spawnPosition,
                    Quaternion.identity
                );

                if (minionNetObj == null)
                {
                    RunLogError("Failed to get minion from pool", nameof(SpawnMinions));
                    continue;
                }

                // CRITICAL: Move to gameplay scene
                Scene gameplayScene = _owner.GetGameplayScene();
                if (gameplayScene.IsValid() && gameplayScene.isLoaded)
                {
                    SceneManager.MoveGameObjectToScene(minionNetObj.gameObject, gameplayScene);
                }

                // Setup minion
                var minionAI = minionNetObj.GetComponent<NetAiSummon>();
                if (minionAI != null)
                {
                    minionAI.SetOwner(_owner.GetOwnerClientId());
                    minionAI.SetOwnerRefs(minionOwnerRefs);
                }

                // Spawn on network
                minionNetObj.Spawn();
            }

            if (DebugOn) RunLog($"Spawned {_config.get_MaxMininonAmmount} minions from pool", nameof(SpawnMinions));
        }

        private void SpawnExplosionEffect(Vector3 position)
        {
            if (_owner.GetExtraItems() != null &&
                _owner.GetExtraItems().HasItem(SummonExtraItemType.DeathEffect))
            {
                var deathEffect = _owner.GetExtraItems().GetItemObject(SummonExtraItemType.DeathEffect);
                if (deathEffect != null)
                {
                    Instantiate(deathEffect, position, Quaternion.identity);
                }
            }
        }

        [Unity.Netcode.ClientRpc]
        private void SpawnExplosionEffectClientRpc(Vector3 position)
        {
            if (_owner.IsOwner) return;
            SpawnExplosionEffect(position);
        }

        private IAmPlayerServiceLocator GetOwnerPlayerRefs()
        {
            // The entity list is kept by IAmPlayerServiceLocator, so no scene search is needed
            var allPlayers = IAmPlayerServiceLocator.All;
            ulong ownerId = _owner.GetOwnerClientId();
            for (int i = 0; i < allPlayers.Count; i++)
            {
                if (allPlayers[i].get__MID__PlayerOrBotOwnerId == ownerId)
                {
                    return allPlayers[i];
                }
            }
            return null;
        }

        private bool DebugOn => _logLevel >= MID_LogLevel.Debug;

        private void RunLog(string message, string methodName = "") =>
            MID_Logger.LogDebug(_logLevel, message, nameof(HunterBehavior), methodName);

        private void RunLogWarning(string message, string methodName = "") =>
            MID_Logger.LogWarning(_logLevel, message, nameof(HunterBehavior), methodName);

        private void RunLogError(string message, string methodName = "") =>
            MID_Logger.LogError(_logLevel, message, nameof(HunterBehavior), methodName);
    }
}
