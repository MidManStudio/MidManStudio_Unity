// ============================================================================
// NOTICE: Full documentation and design decisions for this file
// live in docs/StickToTheDeath/bots.md, section "Summons"
// ============================================================================
using UnityEngine;
using System.Collections;
using MidManStudio.Core.Logging;
using MidManStudio.Sttd.InGame.EquipableItemConfigs;
namespace MidManStudio.Sttd.InGame.Summons
{
    /// <summary>
    /// Bomber summon (BlackPhoenix) - flies in straight line and drops bombs
    /// Uses rigidbody velocity for movement
    /// </summary>
    public class BomberBehavior : MonoBehaviour, ISummonBehavior
    {
        [SerializeField] private MID_LogLevel _logLevel = MID_LogLevel.Error;

        private static readonly WaitForSeconds DropPoll = new WaitForSeconds(0.2f);

        private SummonBlueprint _owner;
        private ScoreSummonsConfigScriptableObject _config;
        private Transform _shotPoint;
        private float _currentSpeed;
        private float _nextTimeToSpawn = 0f;
        private Coroutine _bombDropCoroutine;

        public void Initialize(SummonBlueprint owner, ScoreSummonsConfigScriptableObject config)
        {
            _owner = owner;
            _config = config;

            // Create shot point for bomb drops
            GameObject shotPointObj = new GameObject("ShotPoint");
            shotPointObj.transform.SetParent(_owner.transform);
            shotPointObj.transform.localPosition = _config.get_ShotPointLocation;
            shotPointObj.transform.localRotation = Quaternion.identity;
            _shotPoint = shotPointObj.transform;

            // Set random speed
            _currentSpeed = Random.Range(_config.get_MinSpeed, _config.get_MaxSpeed);

            // Set velocity
            var rb = _owner.GetRigidbody();
            if (rb != null)
            {
                rb.velocity = _owner.transform.right * _currentSpeed;
            }

            // Start dropping bombs
            if (_owner.IsServer)
            {
                _bombDropCoroutine = StartCoroutine(DropBombs());
            }

            // Play spawn effect
            if (_owner.GetExtraItems() != null &&
                _owner.GetExtraItems().HasItem(SummonExtraItemType.SpawnEffect))
            {
                var spawnEffect = _owner.GetExtraItems().GetParticleSystem(SummonExtraItemType.SpawnEffect);
                if (spawnEffect != null)
                {
                    spawnEffect.Play();
                }
            }

            if (DebugOn) RunLog($"Bomber initialized - flying at speed {_currentSpeed}", nameof(Initialize));
        }

        public void OnUpdate()
        {
            // Movement handled by rigidbody velocity set in Initialize
        }

        public void OnCleanup()
        {
            if (_bombDropCoroutine != null)
            {
                StopCoroutine(_bombDropCoroutine);
            }

            if (_shotPoint != null)
            {
                Destroy(_shotPoint.gameObject);
            }

            RunLog("Bomber cleanup complete", nameof(OnCleanup));
        }

        private IEnumerator DropBombs()
        {
            while (_owner.IsSpawned)
            {
                yield return DropPoll;

                if (Time.time >= _nextTimeToSpawn)
                {
                    _nextTimeToSpawn = Time.time + 1f / _config.get_ProjectileSpawnRate;
                    DropBomb();
                }
            }
        }

        private void DropBomb()
        {
            if (_shotPoint == null) return;

            // The manager pools, launches and owns the bomb, like for a gun. It belongs to the owner of
            // the summon, so a hit is credited to the owner.
            if (!SummonProjectiles.Fire(_owner, _config, _shotPoint.position, _shotPoint.rotation * Vector2.right))
            {
                return;
            }

            if (DebugOn) RunLog("Dropped bomb", nameof(DropBomb));
        }

        private bool DebugOn => _logLevel >= MID_LogLevel.Debug;

        private void RunLog(string message, string methodName = "")
        {
            MID_Logger.LogDebug(_logLevel, message, nameof(BomberBehavior), methodName);
        }

        private void RunLogError(string message, string methodName = "")
        {
            MID_Logger.LogError(_logLevel, message, nameof(BomberBehavior), methodName);
        }
    }
}
