// ============================================================================
// NOTICE: Full documentation and design decisions for this file
// live in docs/StickToTheDeath/bots.md, section "Summons"
// ============================================================================
using System.Collections.Generic;
using UnityEngine;
using MidManStudio.Core.Logging;
using MidManStudio.Sttd.InGame.EquipableItemConfigs;
using MidManStudio.Sttd.InGame.Setup;

namespace MidManStudio.Sttd.InGame.Summons
{
    /// <summary>
    /// Clairvoyance summon - reveals enemy positions to team via directional indicators
    /// Static summon that activates team-wide vision buff
    /// </summary>
    public class ClairvoyanceBehavior : MonoBehaviour, ISummonBehavior
    {
        private SummonBlueprint _owner;
        private ScoreSummonsConfigScriptableObject _config;
        private bool _isActive = false;

        [SerializeField] private MID_LogLevel _logLevel = MID_LogLevel.Error;

        public void Initialize(SummonBlueprint owner, ScoreSummonsConfigScriptableObject config)
        {
            _owner = owner;
            _config = config;

            // Activate clairvoyance for team
            ActivateClairvoyanceForTeam();

            // A human who joins while the summon is alive gets the effect too
            if (_owner.IsServer)
            {
                TeamPlayer.OnHumanTeamKnownServer += OnHumanTeamKnown;
            }

            // Play spawn effect
            if (_owner.GetExtraItems() != null &&
                _owner.GetExtraItems().HasItem(SummonExtraItemType.SpawnEffect))
            {
                var spawnEffect = _owner.GetExtraItems().GetParticleSystem(SummonExtraItemType.SpawnEffect);
                if (spawnEffect != null)
                {
                    spawnEffect.Play();
                }
            }

            // Play idle aura
            if (_owner.GetExtraItems() != null &&
                _owner.GetExtraItems().HasItem(SummonExtraItemType.IdleAura))
            {
                var aura = _owner.GetExtraItems().GetParticleSystem(SummonExtraItemType.IdleAura);
                if (aura != null)
                {
                    aura.Play();
                }
            }

            _isActive = true;

            RunLog("Clairvoyance activated for team", nameof(Initialize));
        }

        public void OnUpdate()
        {
            // Static summon - no update logic needed
        }

        public void OnCleanup()
        {
            TeamPlayer.OnHumanTeamKnownServer -= OnHumanTeamKnown;

            if (_isActive)
            {
                DeactivateClairvoyanceForTeam();
                _isActive = false;
            }

            RunLog("Clairvoyance cleanup complete", nameof(OnCleanup));
        }

        // Client ids of the humans that got the buff, so the same ones lose it again.
        private readonly List<ulong> _affectedClientIds = new List<ulong>();

        private void ActivateClairvoyanceForTeam()
        {
            if (!_owner.IsServer) return;

            IAmPlayerServiceLocator ownerRefs = GetOwnerPlayerRefs();
            if (ownerRefs == null || ownerRefs.get_PlayerTeamHandler == null) return;

            NetworkServerManeger server = NetworkServerManeger.networkServerSingleton;
            if (server == null)
            {
                RunLogError("NetworkServerManeger singleton is null, clairvoyance is not sent", nameof(ActivateClairvoyanceForTeam));
                return;
            }

            _affectedClientIds.Clear();
            IReadOnlyList<IAmPlayerServiceLocator> all = IAmPlayerServiceLocator.All;
            for (int i = 0; i < all.Count; i++)
            {
                if (!IsHumanTeammate(ownerRefs, all[i])) continue;

                _affectedClientIds.Add(all[i].get_PlayerTeamHandler.OwnerClientId);
            }

            server.SetClairvoyanceForClients(_affectedClientIds, true);

            if (DebugOn) RunLog($"Clairvoyance sent to {_affectedClientIds.Count} player(s)", nameof(ActivateClairvoyanceForTeam));
        }

        private void DeactivateClairvoyanceForTeam()
        {
            if (!_owner.IsServer || _affectedClientIds.Count == 0) return;

            NetworkServerManeger server = NetworkServerManeger.networkServerSingleton;
            if (server != null)
            {
                server.SetClairvoyanceForClients(_affectedClientIds, false);
            }

            _affectedClientIds.Clear();
        }

        // A human on the owner's side. The owner counts as its own teammate. In Free For All nobody
        // else is on the owner's side, in Survival every player is.
        private static bool IsHumanTeammate(IAmPlayerServiceLocator ownerRefs, IAmPlayerServiceLocator entity)
        {
            if (entity == null || entity.get_PlayerTeamHandler == null) return false;
            if (entity.get_PlayerTeamHandler.n_IsBotPlayer.Value) return false;

            return !NetTeamRules.AreEnemies(ownerRefs, entity);
        }

        private readonly List<ulong> _lateJoinTarget = new List<ulong>(1);

        // A human whose team becomes known while the summon is alive: the same rule as at the start
        private void OnHumanTeamKnown(TeamPlayer joiner)
        {
            if (!_isActive || !_owner.IsServer || joiner == null) return;

            ulong clientId = joiner.OwnerClientId;
            if (_affectedClientIds.Contains(clientId)) return;

            IAmPlayerServiceLocator ownerRefs = GetOwnerPlayerRefs();
            if (ownerRefs == null || !joiner.TryGetComponent(out IAmPlayerServiceLocator joinerRefs)) return;
            if (!IsHumanTeammate(ownerRefs, joinerRefs)) return;

            NetworkServerManeger server = NetworkServerManeger.networkServerSingleton;
            if (server == null) return;

            _affectedClientIds.Add(clientId);
            _lateJoinTarget.Clear();
            _lateJoinTarget.Add(clientId);
            server.SetClairvoyanceForClients(_lateJoinTarget, true);

            if (DebugOn) RunLog($"Late joiner {clientId} got the effect", nameof(OnHumanTeamKnown));
        }

        private IAmPlayerServiceLocator GetOwnerPlayerRefs()
        {
            ulong ownerId = _owner.GetOwnerClientId();
            IReadOnlyList<IAmPlayerServiceLocator> all = IAmPlayerServiceLocator.All;
            for (int i = 0; i < all.Count; i++)
            {
                IAmPlayerServiceLocator player = all[i];
                if (player != null && player.get__MID__PlayerOrBotOwnerId == ownerId)
                {
                    return player;
                }
            }
            return null;
        }

        private bool DebugOn => _logLevel >= MID_LogLevel.Debug;

        private void RunLog(string message, string methodName = "") =>
            MID_Logger.LogDebug(_logLevel, message, nameof(ClairvoyanceBehavior), methodName);

        private void RunLogError(string message, string methodName = "", System.Exception e = null) =>
            MID_Logger.LogError(_logLevel, message, nameof(ClairvoyanceBehavior), methodName, e);
    }
}
