// ============================================================================
// NOTICE: Full documentation and design decisions for this file
// live in docs/StickToTheDeath/bots.md, section "Summons"
// ============================================================================
using System;
using UnityEngine;
using MidManStudio.Core.Logging;
using MidManStudio.Projectiles.Config;
using MidManStudio.Sttd.InGame.EquipableItemConfigs;
using MidManStudio.Sttd.InGame.GameItemData;
using MidManStudio.Sttd.InGame.ProjectileSystem;

namespace MidManStudio.Sttd.InGame.Summons
{
    /// <summary>
    /// Fires the projectile of a summon (the turret, the bomber) through UnifiedProjectileManager, the
    /// way the guns do. The manager pools, launches and owns the projectile, so a hit is credited to
    /// the owner of the summon.
    /// </summary>
    internal static class SummonProjectiles
    {
        // The summon configs still store the old name enum, the manager takes the generated
        // ProjectileConfigType. Five names are spelled differently in the two enums.
        internal static bool TryGetConfigType(MID_AllProjectileNames name, out ProjectileConfigType type)
        {
            switch (name)
            {
                case MID_AllProjectileNames.none:
                    type = ProjectileConfigType.Default;
                    return false;
                case MID_AllProjectileNames.BlackPhoenix:
                    type = ProjectileConfigType.BlackPheonix;
                    return true;
                case MID_AllProjectileNames.Poper:
                    type = ProjectileConfigType.Popper;
                    return true;
                case MID_AllProjectileNames.ApexMagnum:
                    type = ProjectileConfigType.MagnumApex;
                    return true;
                case MID_AllProjectileNames.ApexMagnum_Raiz:
                    type = ProjectileConfigType.MagnumApex_Raiz;
                    return true;
                default:
                    return Enum.TryParse(name.ToString(), out type);
            }
        }

        /// <summary>
        /// Server only. Fires one projectile of the summon config from the origin in the direction.
        /// </summary>
        internal static bool Fire(SummonBlueprint owner, ScoreSummonsConfigScriptableObject config, Vector2 origin, Vector2 direction)
        {
            if (!TryGetConfigType(config.get_ProjectileUniqueName, out ProjectileConfigType type))
            {
                MID_Logger.LogError(MID_LogLevel.Info, $"No projectile type for {config.get_ProjectileUniqueName}",
                    nameof(SummonProjectiles), nameof(Fire));
                return false;
            }

            // The projectile belongs to the owner of the summon, so the kill and the team rules follow it
            ulong ownerId = owner.GetOwnerClientId();

            UnifiedProjectileManager.FireProjectile(
                type,
                origin,
                direction,
                ownerId,
                owner.NetworkObjectId,
                NetBotPlayerHandler.IsSpawnedBot(ownerId),
                0,
                config.get_ProjectileSpawnRate);

            return true;
        }
    }
}
