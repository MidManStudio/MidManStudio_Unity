﻿// ============================================================================
// NOTICE: Full documentation and design decisions for this file
// live in docs/StickToTheDeath/bots.md, section "Summons"
// ============================================================================
using UnityEngine;
using UnityEngine.SceneManagement;
using MidManStudio.Sttd.InGame.EquipableItemConfigs;
using MidManStudio.Core.Logging;
using MidManStudio.Core.Pools;
using MidManStudio.Sttd.InGame.Managers;
using MidManStudio.Sttd.InGame.NetworkSync;
using MidManStudio.Netcode.Pools;
using MidManStudio.Sttd.InGame.ProjectileSystem;
namespace MidManStudio.Sttd.InGame.Summons
{
    /// <summary>
    /// Turret summon (DragonEyeTorrent) - stays in place and shoots at enemies
    /// Aims and fires projectiles from pool
    /// </summary>
    public class TurretBehavior : MonoBehaviour, ISummonBehavior
    {
        [SerializeField] private MID_LogLevel _logLevel = MID_LogLevel.Error;

        private SummonBlueprint _owner;
        private ScoreSummonsConfigScriptableObject _config;
        private Transform _currentTarget;
        private Transform _shotPoint;
        private float _nextTimeToFire = 0f;
        private bool _targetDetected = false;

        public void Initialize(SummonBlueprint owner, ScoreSummonsConfigScriptableObject config)
        {
            _owner = owner;
            _config = config;

            // Create shot point
            GameObject shotPointObj = new GameObject("ShotPoint");
            shotPointObj.transform.SetParent(_owner.transform);
            shotPointObj.transform.localPosition = _config.get_ShotPointLocation;
            shotPointObj.transform.localRotation = Quaternion.identity;
            _shotPoint = shotPointObj.transform;

            // Play spawn effect
            if (_owner.GetExtraItems() != null &&
                _owner.GetExtraItems().HasItem(SummonExtraItemType.SpawnEffect))
            {
                var spawnEffect = _owner.GetExtraItems().GetParticleSystem(SummonExtraItemType.SpawnEffect);
                if (spawnEffect != null)
                {
                    spawnEffect.Play();
                }
            }

            RunLog("Turret initialized and scanning for targets", nameof(Initialize));
        }

        public void OnUpdate()
        {
            if (!_owner.IsServer) return;

            // Check for enemies in range
            if (!_targetDetected || _currentTarget == null)
            {
                CheckForEnemiesInRange();
            }

            if (_currentTarget != null)
            {
                float distanceToTarget = Vector2.Distance(_owner.transform.position, _currentTarget.position);

                if (distanceToTarget < _config.get_TurrentAttackDistance)
                {
                    _targetDetected = true;
                    AimAtTarget();
                    TryFire();
                }
                else
                {
                    _targetDetected = false;
                }
            }
        }

        public void OnCleanup()
        {
            if (_shotPoint != null)
            {
                Destroy(_shotPoint.gameObject);
            }

            RunLog("Turret cleanup complete", nameof(OnCleanup));
        }

        // Picks the nearest living enemy inside the targeting radius. The entity list is read directly,
        // so no physics query or per-collider GetComponent is needed. Free For All makes everyone but
        // the owner an enemy.
        private void CheckForEnemiesInRange()
        {
            var ownerRefs = GetOwnerPlayerRefs();
            if (ownerRefs == null) return;

            var all = IAmPlayerServiceLocator.All;
            Vector2 origin = _owner.transform.position;
            float radius = _config.get_TargetingRadius;
            float closestSqr = radius * radius;
            Transform closest = null;

            for (int i = 0; i < all.Count; i++)
            {
                var other = all[i];
                if (!MidManStudio.Sttd.InGame.Setup.NetTeamRules.AreEnemies(other, ownerRefs)) continue;
                if (other.get_PlayerHealthScript.GetHealthComponent().GetCurrentHealth() <= 0) continue;

                float sqr = ((Vector2)other.transform.position - origin).sqrMagnitude;
                if (sqr > closestSqr) continue;

                closestSqr = sqr;
                closest = other.transform;
            }

            if (closest != null)
            {
                _currentTarget = closest;
                if (DebugOn) RunLog($"Target acquired: {closest.name}", nameof(CheckForEnemiesInRange));
            }
        }

        private void AimAtTarget()
        {
            if (_currentTarget == null) return;

            Vector2 direction = _currentTarget.position - _owner.transform.position;
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            _owner.transform.right = direction;
        }

        private void TryFire()
        {
            if (Time.time < _nextTimeToFire) return;

            _nextTimeToFire = Time.time + 1f / _config.get_ProjectileSpawnRate;
            FireProjectile();
        }

        private void FireProjectile()
        {
            if (_shotPoint == null) return;

            // The manager pools, launches and owns the projectile, like for a gun
            if (!SummonProjectiles.Fire(_owner, _config, _shotPoint.position, _shotPoint.rotation * Vector2.right))
            {
                return;
            }

            // Play muzzle flash effect
            if (_owner.GetExtraItems() != null &&
                _owner.GetExtraItems().HasItem(SummonExtraItemType.AttackEffect))
            {
                var attackEffect = _owner.GetExtraItems().GetParticleSystem(SummonExtraItemType.AttackEffect);
                if (attackEffect != null)
                {
                    attackEffect.Play();
                }
            }

            if (DebugOn) RunLog($"Fired projectile at {_currentTarget?.name}", nameof(FireProjectile));
        }

        private IAmPlayerServiceLocator GetOwnerPlayerRefs()
        {
            // The entity list is kept by IAmPlayerServiceLocator, so no scene search is needed
            var allPlayers = IAmPlayerServiceLocator.All;
            ulong ownerId = _owner.GetOwnerClientId();
            for (int i = 0; i < allPlayers.Count; i++)
            {
                if (allPlayers[i].get__MID__PlayerOrBotOwnerId == ownerId)
                {
                    return allPlayers[i];
                }
            }
            return null;
        }

        private bool DebugOn => _logLevel >= MID_LogLevel.Debug;

        private void RunLog(string message, string methodName = "") =>
            MID_Logger.LogDebug(_logLevel, message, nameof(TurretBehavior), methodName);

        private void RunLogError(string message, string methodName = "") =>
            MID_Logger.LogError(_logLevel, message, nameof(TurretBehavior), methodName);
    }
}
