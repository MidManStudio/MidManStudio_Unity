// ============================================================================
// NOTICE: Full documentation and design decisions for this file
// live in docs/StickToTheDeath/weapons.md, section "GrenadeScriptMain.cs"
// ============================================================================
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Unity.Netcode;
using MidManStudio.Sttd.Core.Utilities;
using MidManStudio.Sttd.InGame.GameItemData;
using UnityEngine.Animations;
using MidManStudio.Sttd.InGame.EquipableItemConfigs;
using MidManStudio.Sttd.InGame.NetworkDataStructures;
using MidManStudio.Core.Logging;
using UnityEngine.SceneManagement;
using MidManStudio.Core.Audio;
using MidManStudio.Sttd.Vfx;
using MidManStudio.Core.TickDispatcher;
using MidManStudio.Core.Pools; // FIX: was implicitly resolving PoolableObjectType via the old global-namespace enum
/// <summary>
/// Main grenade script attached to grenade prefab
/// REFACTORED: Uses LocalObjectPool for extra items and proper scene management
/// NOTE: Grenades do NOT use dissolve effects
/// </summary>
public class GrenadeScriptMain : NetworkBehaviour
{
    #region Enums & Structs

    private enum GrenadeState
    {
        nullState,
        InActive,
        Active,
        Destroyed
    }

    [Serializable]
    public struct GrnadeConfigList : IArrayElementTitle
    {
        public string key;
        public GrenadeConfigScriptableObject Variable;
        public string Name => key;
    }

    #endregion

    #region Fields

    [Header("Debug Settings")]
    [SerializeField] private MID_LogLevel _logLevel = MID_LogLevel.Error;

    [Header("Config Lists")]
    [MID_NamedList]
    [SerializeField] List<GrnadeConfigList> m_AllRegularGrenadeConfigList = new List<GrnadeConfigList>();
    [MID_NamedList]
    [SerializeField] List<GrnadeConfigList> m_AllLegendaryGrenadeConfigList = new List<GrnadeConfigList>();

    [SerializeField] GrenadeConfigScriptableObject m_GrenadeConfig;

    [Header("Current Visual")]
    [SerializeField] MID_WeaponSkins _currentWeaponVisual;

    [Header("Grenade Variables")]
    [SerializeField] private NetworkVariable<GrenadeState> m_GrenadeState = new NetworkVariable<GrenadeState>(GrenadeState.nullState);
    public float explosionDelay;

    [Header("References")]
    public IAmPlayerServiceLocator m_GrenadeOwnerPlayerRefrence;

    [Header("Deterministic Variables")]
    [SerializeField] ExplosionPoint _currentExplosionPoint;
    [SerializeField] MID_PlayerKillTypeAndPoints _currentPlayerKillType = new MID_PlayerKillTypeAndPoints { _playerKillType = MID_PlayerKillType.Boom, _valueInPoints = 75 };
    [SerializeField] MID_PlayerAndBotDamageType _currentPlayerAndBotDamageType;
    [SerializeField] MID_WhatWeaponDamagedPlayer _currentWhatWeaponDamagedPlayer;

    [Header("Components")]
    [SerializeField] private Rigidbody2D m_RigidBody2d;
    [SerializeField] private Collider2D m_Collider2d;
    [SerializeField] internal ParentConstraint m_ParentConstraint;

    [Header("Audio")]
    public AudioClip m_ThrowingSound;
    public AudioClip m_ExplosionSound;

    [Header("Synchronizing Variables")]
    public MID_AllGrenadeNames internalGrenadeName;
    [SerializeField] private NetworkVariable<MID_AllGrenadeNames> _currentGrenadeName = new NetworkVariable<MID_AllGrenadeNames>();

    [HideInInspector] public ulong internalOwnerClientId;
    [HideInInspector] public bool internalIsBotOwned;
    public ulong internalFiredByNetworkObjectId;

    [SerializeField] private NetworkVariable<ulong> n_GrenadeOwnerClientId = new NetworkVariable<ulong>();
    [SerializeField] private NetworkVariable<ulong> n_FiredByNetObjId = new NetworkVariable<ulong>();
    [SerializeField] private NetworkVariable<bool> n_IsBotOwned = new NetworkVariable<bool>();
    [SerializeField] NetworkVariable<byte> n_MaxNumOfCollisionsPossible = new NetworkVariable<byte>(1);

    [Tooltip("Grenade lifetime before expiring")]
    public float _totalLifeTime = 8.0f;

    public SpriteRenderer m_SpriteRend;
    public TrailRenderer m_TrailRend;

    bool enableSpecialBehaviour = false;

    [Header("Extra SatBlocker")]
    [SerializeField] GameObject _collisionWithSatBlockerDestroyEffect;

    [Header("Spawnable Audio Source")]

    [Header("Cover Detection")]
    [SerializeField] LayerMask _coverLayerMask;
    [SerializeField] LayerMask _playerLayerMask;

    // Explosion and proximity mine queries reuse these, nothing is allocated per explosion
    private const int TargetBufferSize = 32;
    private const float CoverRayInset = 0.1f;   // part of the target height kept off the feet and head rays
    private const float CoverHitEpsilon = 0.01f;

    private Collider2D[] _targetBuffer;
    private readonly RaycastHit2D[] _coverHits = new RaycastHit2D[8];
    private readonly HashSet<IAmPlayerServiceLocator> _explosionTargets = new HashSet<IAmPlayerServiceLocator>();
    private ContactFilter2D _playerFilter;
    private ContactFilter2D _coverFilter;
    private bool _filtersReady;

    #endregion

    #region Extra Items - REFACTORED

    [Header("Extra Items - Pooled")]
    private GameObject _extraItemsInstance;
    private GrenadeExtraItems _grenadeExtraItems;
    private bool _extraItemsInitialized = false;

    #endregion

    #region Scene Management

    private Scene _gameplayScene;

    #endregion

    #region Tick System

    private TickRate _proximityCheckTickRate = TickRate.Tick_0_2; // 5Hz for proximity checks
    private bool _isSubscribedToTicks = false;

    #endregion

    #region Initialization State

    private bool _isActive = false;
    private bool _initialized = false;

    #endregion

    #region Unity Lifecycle

    private void Awake()
    {
        // Cache the gameplay scene
        _gameplayScene = gameObject.scene;
        RunLog($"Grenade in scene: {_gameplayScene.name}", nameof(Awake));
    }

    private void OnEnable()
    {
        _isActive = true;
    }

    private void OnDisable()
    {
        _isActive = false;

        // Stop any active effects
        if (_grenadeExtraItems != null)
        {
            _grenadeExtraItems.StopAllParticles();
            _grenadeExtraItems.DisableAllTrails();
        }
    }

    #endregion

    #region Network Lifecycle

    public override void OnNetworkSpawn()
    {
        m_GrenadeState.OnValueChanged += OnGrenadeStateChanged;

        if (IsServer)
        {
            m_GrenadeState.Value = GrenadeState.nullState;
            m_GrenadeState.Value = GrenadeState.InActive;
            n_GrenadeOwnerClientId.Value = internalOwnerClientId;
            n_FiredByNetObjId.Value = internalFiredByNetworkObjectId;
            n_IsBotOwned.Value = internalIsBotOwned;

            FindOwnersPlayerStuffRefrence();

            n_MaxNumOfCollisionsPossible.OnValueChanged += OnMaxCollisionsNumChanged;
        }

        GetGrenadeInfo();

        // Initialize extra items from pool
        InitializeExtraItemsFromPool();

        _isActive = true;
        _initialized = true;

        RunLog($"Grenade spawned: {_currentGrenadeName.Value}", nameof(OnNetworkSpawn));
    }

    public override void OnNetworkDespawn()
    {
        if (IsServer)
        {
            n_MaxNumOfCollisionsPossible.OnValueChanged -= OnMaxCollisionsNumChanged;
        }
        m_GrenadeState.OnValueChanged -= OnGrenadeStateChanged;

        // Unsubscribe from tick system
        if (_isSubscribedToTicks)
        {
            MID_TickDispatcher.Unsubscribe(_proximityCheckTickRate, OnProximityCheckTick);
            _isSubscribedToTicks = false;
            RunLog("Unsubscribed from proximity checks", nameof(OnNetworkDespawn));
        }

        // Force cleanup
        ForceStopAllActivities();

        // Return extra items to pool
        CleanupForPoolReturn();

        _isActive = false;
        _initialized = false;
    }

    private void OnMaxCollisionsNumChanged(byte previousValue, byte newValue)
    {
        if (!IsServer) { return; }
        if (n_MaxNumOfCollisionsPossible.Value <= 0)
        {
            if (m_GrenadeConfig == null) { return; }
            RunLog("Max collisions reached, exploding grenade", nameof(OnMaxCollisionsNumChanged));
            Explode();
        }
    }

    #endregion

    #region Extra Items Initialization - REFACTORED

    /// <summary>
    /// Initialize extra items from LocalObjectPool
    /// </summary>
    private void InitializeExtraItemsFromPool()
    {
        if (m_GrenadeConfig == null)
        {
            RunLogWarning("No grenade config - skipping extra items", nameof(InitializeExtraItemsFromPool));
            return;
        }

        // Get pool type from config
        PoolableObjectType poolType = m_GrenadeConfig.get_SpawnableExtraItemType;

        // Validate pool type
        if (poolType != PoolableObjectType.GrenadeExtraItems)
        {
            RunLogWarning($"Unexpected pool type for grenade: {poolType}", nameof(InitializeExtraItemsFromPool));
        }

        // Check if pool has this type registered
        if (!LocalObjectPool.Instance.IsRegistered(poolType))
        {
            RunLogError($"Pool type {poolType} not registered in LocalObjectPool!", nameof(InitializeExtraItemsFromPool));
            return;
        }

        // Get extra items from pool
        _extraItemsInstance = LocalObjectPool.Instance.GetObject(
            poolType,
            transform.position,
            transform.rotation
        );

        if (_extraItemsInstance == null)
        {
            RunLogError("Failed to get grenade extra items from pool", nameof(InitializeExtraItemsFromPool));
            return;
        }

        // Parent to grenade
        _extraItemsInstance.transform.SetParent(transform);
        _extraItemsInstance.transform.localPosition = Vector3.zero;
        _extraItemsInstance.transform.localRotation = Quaternion.identity;

        // Get GrenadeExtraItems component
        _grenadeExtraItems = _extraItemsInstance.GetComponent<GrenadeExtraItems>();

        if (_grenadeExtraItems == null)
        {
            RunLogError("Extra items prefab missing GrenadeExtraItems component!", nameof(InitializeExtraItemsFromPool));
            LocalObjectPool.Instance.ReturnObject(_extraItemsInstance, poolType);
            _extraItemsInstance = null;
            return;
        }

        _extraItemsInitialized = true;

        RunLog($"Grenade extra items spawned from pool: {poolType}", nameof(InitializeExtraItemsFromPool));
    }

    #endregion

    #region Tick System Integration

    /// <summary>
    /// Tick-based proximity checks for performance
    /// </summary>
    private void OnProximityCheckTick(float deltaTime)
    {
        if (!IsServer || !enableSpecialBehaviour || m_GrenadeConfig == null || !_isActive)
        {
            return;
        }

        switch (m_GrenadeConfig.get_GrenadeType)
        {
            case GrenadeType.proximityMine:
                CheckForPlayerInExplosionRange();
                break;

            case GrenadeType.satBlocker:
                CheckForGrenadesInRange();
                break;
        }
    }

    void CheckForPlayerInExplosionRange()
    {
        if (m_GrenadeOwnerPlayerRefrence == null) { return; }
        if (m_GrenadeConfig == null) { return; }

        EnsurePhysicsFilters();

        int targetCount = Physics2D.OverlapCircle(transform.position, m_GrenadeConfig.get_TrapActivationRadius, _playerFilter, _targetBuffer);

        for (int i = 0; i < targetCount; i++)
        {
            if (!_targetBuffer[i].TryGetComponent(out IAmPlayerServiceLocator otherRefs)) continue;

            // The owner is never an enemy of its own mine, also in Free For All
            if (MidManStudio.Sttd.InGame.Setup.NetTeamRules.AreEnemies(otherRefs, m_GrenadeOwnerPlayerRefrence))
            {
                RunLog("Enemy player detected in proximity mine radius, exploding", nameof(CheckForPlayerInExplosionRange));
                Explode();
                return;
            }
        }
    }

    void CheckForGrenadesInRange()
    {
        if (m_GrenadeOwnerPlayerRefrence == null) { return; }
        if (m_GrenadeConfig == null) { return; }

        Collider2D[] hitCast = Physics2D.OverlapCircleAll(transform.position, m_GrenadeConfig.get_SatBlockerBlockRadius);

        if (hitCast != null && hitCast.Length > 0)
        {
            foreach (Collider2D grenade in hitCast)
            {
                grenade.TryGetComponent(out GrenadeScriptMain grenadeScript);

                if (grenadeScript != null && grenadeScript != this)
                {
                    n_MaxNumOfCollisionsPossible.Value -= 1;
                    grenadeScript.DestroyGrenadeOnCollisionWithSatBlocker();

                    RunLog($"Sat blocker intercepted grenade", nameof(CheckForGrenadesInRange));
                }
            }
        }
    }

    #endregion

    #region Debug Gizmos

    private void OnDrawGizmosSelected()
    {
        if (m_GrenadeConfig == null) { return; }
        if (m_GrenadeOwnerPlayerRefrence == null) { return; }

        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, m_GrenadeConfig.get_ExplosionRadius);

        if (m_GrenadeConfig.get_GrenadeType == GrenadeType.proximityMine)
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(transform.position, m_GrenadeConfig.get_TrapActivationRadius);
        }
    }

    #endregion

    #region OnValueChangedEvents

    void OnGrenadeStateChanged(GrenadeState oldValue, GrenadeState newValue)
    {
        RunLog($"Grenade state changed: {oldValue} -> {newValue}", nameof(OnGrenadeStateChanged));

        switch (m_GrenadeState.Value)
        {
            case GrenadeState.InActive:
                m_RigidBody2d.isKinematic = true;
                m_RigidBody2d.simulated = false;
                break;

            case GrenadeState.Active:
                m_RigidBody2d.isKinematic = false;
                m_RigidBody2d.simulated = true;
                PlayThrowSoundLocally();

                // Enable throw trail effect if available
                if (_extraItemsInitialized && _grenadeExtraItems != null)
                {
                    if (_grenadeExtraItems.HasItem(GrenadeExtraItemType.ThrowTrail))
                    {
                        var trail = _grenadeExtraItems.GetTrailRenderer(GrenadeExtraItemType.ThrowTrail);
                        if (trail != null)
                        {
                            trail.emitting = true;
                        }
                    }
                }

                if (IsServer)
                {
                    StartCoroutine(SetExTime());
                }
                break;

            case GrenadeState.Destroyed:
                // Unsubscribe from ticks when destroyed
                if (_isSubscribedToTicks)
                {
                    MID_TickDispatcher.Unsubscribe(_proximityCheckTickRate, OnProximityCheckTick);
                    _isSubscribedToTicks = false;
                }

                // Stop all extra item effects
                if (_extraItemsInitialized && _grenadeExtraItems != null)
                {
                    _grenadeExtraItems.StopAllParticles();
                    _grenadeExtraItems.DisableAllTrails();
                }

                // Pooled sound through SttdFxManager. It no longer creates an object per sound and it
                // outlives the grenade, which is despawned right after.
                if (m_GrenadeConfig != null && m_GrenadeConfig.i_ThrowableAudio.hitSound != null)
                {
                    SttdFxManager.PlaySound(m_GrenadeConfig.i_ThrowableAudio.hitSound,
                        AudioCategory.GrenadeExplosion, transform.position);
                }

                if (IsServer)
                {
                    if (m_GrenadeConfig.get_GrenadeType != GrenadeType.sparker)
                    {
                        NetworkObject.Despawn();
                    }
                    else
                    {
                        StartCoroutine(DespawnSparkerAfterDelay());
                    }
                }
                break;
        }
    }

    private static readonly WaitForSeconds ExplosionTimerSetupWait = new WaitForSeconds(0.5f);
    private static readonly WaitForSeconds SparkerDespawnWait = new WaitForSeconds(5f);

    IEnumerator SetExTime()
    {
        yield return ExplosionTimerSetupWait;

        if (m_GrenadeConfig.get_GrenadeType == GrenadeType.frag)
        {
            RunLog($"Frag grenade explosion timer started: {_totalLifeTime}s", nameof(SetExTime));
            StartCoroutine(ExplodeDelayed(_totalLifeTime));
        }
    }

    // A sparker stays in the scene for a few seconds after its last state change.
    private IEnumerator DespawnSparkerAfterDelay()
    {
        yield return SparkerDespawnWait;

        if (IsSpawned)
            NetworkObject.Despawn();
    }

    #endregion

    #region Force and Collision

    public void AddForce(Vector2 force)
    {
        m_RigidBody2d.velocity = force;
        RunLog($"Force applied to grenade: {force}", nameof(AddForce));
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (m_GrenadeConfig == null) { return; }
        if (m_GrenadeOwnerPlayerRefrence == null) { return; }

        collision.gameObject.TryGetComponent(out IAmPlayerServiceLocator collisionsPlayerRefs);
        if (collisionsPlayerRefs != null)
        {
            // Don't collide with owner
            if (collisionsPlayerRefs.OwnerClientId == n_GrenadeOwnerClientId.Value) { return; }
        }

        if (!IsServer) { return; }

        if (m_GrenadeState.Value != GrenadeState.Active)
        {
            RunLogWarning("Collision while grenade inactive", nameof(OnCollisionEnter2D));
            return;
        }

        // Play bounce effect if available
        if (_extraItemsInitialized && _grenadeExtraItems != null)
        {
            if (_grenadeExtraItems.HasItem(GrenadeExtraItemType.BounceEffect))
            {
                var bounceEffect = _grenadeExtraItems.GetParticleSystem(GrenadeExtraItemType.BounceEffect);
                if (bounceEffect != null)
                {
                    bounceEffect.Play();
                }
            }
        }

        RunLog($"Grenade collision: {m_GrenadeConfig.get_GrenadeType}", nameof(OnCollisionEnter2D));

        switch (m_GrenadeConfig.get_GrenadeType)
        {
            case GrenadeType.frag:
                // Frag grenades don't explode on collision
                break;

            case GrenadeType.hydraGas:
                Explode();
                break;

            case GrenadeType.proximityMine:
                m_RigidBody2d.drag = 1000f;
                m_RigidBody2d.gravityScale = 0;
                enableSpecialBehaviour = true;

                // Show indicator marker if available
                if (_extraItemsInitialized && _grenadeExtraItems != null)
                {
                    _grenadeExtraItems.SetItemActive(GrenadeExtraItemType.IndicatorMarker, true);
                }

                // Subscribe to tick-based proximity checks
                if (!_isSubscribedToTicks)
                {
                    MID_TickDispatcher.Subscribe(_proximityCheckTickRate, OnProximityCheckTick);
                    _isSubscribedToTicks = true;
                    RunLog("Proximity mine armed, subscribed to proximity checks", nameof(OnCollisionEnter2D));
                }
                break;

            case GrenadeType.sticky:
                StickToTarget(collision.gameObject);
                m_RigidBody2d.drag = 1000f;
                m_RigidBody2d.gravityScale = 0;
                break;

            case GrenadeType.moltove:
                Explode();
                break;

            case GrenadeType.satBlocker:
                m_RigidBody2d.drag = 1000f;
                enableSpecialBehaviour = true;

                // Subscribe to tick-based grenade detection
                if (!_isSubscribedToTicks)
                {
                    MID_TickDispatcher.Subscribe(_proximityCheckTickRate, OnProximityCheckTick);
                    _isSubscribedToTicks = true;
                    RunLog("Sat blocker armed, subscribed to grenade checks", nameof(OnCollisionEnter2D));
                }
                break;

            case GrenadeType.sparker:
                StickToTarget(collision.gameObject);
                m_RigidBody2d.drag = 1000f;
                m_RigidBody2d.gravityScale = 0;
                ExplodeSparker();
                break;
        }
    }

    #endregion

    #region Getting Grenade Info

    void GetGrenadeInfo()
    {
        if (IsOwner)
        {
            if (IsServer)
            {
                _currentGrenadeName.Value = internalGrenadeName;
            }
            else
            {
                ChangeGrenadeNameServerRpc();
            }
        }

        switch (_currentGrenadeName.Value)
        {
            case MID_AllGrenadeNames.Frag:
                m_GrenadeConfig = m_AllRegularGrenadeConfigList[0].Variable;
                break;
            case MID_AllGrenadeNames.HydraGas:
                m_GrenadeConfig = m_AllRegularGrenadeConfigList[1].Variable;
                break;
            case MID_AllGrenadeNames.ProximityMine:
                m_GrenadeConfig = m_AllRegularGrenadeConfigList[2].Variable;
                break;
            case MID_AllGrenadeNames.Sticky:
                m_GrenadeConfig = m_AllRegularGrenadeConfigList[3].Variable;
                break;
            case MID_AllGrenadeNames.Moltove:
                m_GrenadeConfig = m_AllRegularGrenadeConfigList[4].Variable;
                break;
            case MID_AllGrenadeNames.SatBlocker:
                m_GrenadeConfig = m_AllRegularGrenadeConfigList[5].Variable;
                break;
            case MID_AllGrenadeNames.Sparker:
                m_GrenadeConfig = m_AllRegularGrenadeConfigList[6].Variable;
                break;
            case MID_AllGrenadeNames.Frag_GoldHalo:
                m_GrenadeConfig = m_AllLegendaryGrenadeConfigList[0].Variable;
                break;
            case MID_AllGrenadeNames.HydraGas_White:
                m_GrenadeConfig = m_AllLegendaryGrenadeConfigList[1].Variable;
                break;
            case MID_AllGrenadeNames.ProximityMine_RedRose:
                m_GrenadeConfig = m_AllLegendaryGrenadeConfigList[2].Variable;
                break;
            case MID_AllGrenadeNames.Moltove_Helhime:
                m_GrenadeConfig = m_AllLegendaryGrenadeConfigList[3].Variable;
                break;
            case MID_AllGrenadeNames.Sparker_RoaringLightning:
                m_GrenadeConfig = m_AllLegendaryGrenadeConfigList[4].Variable;
                break;
        }

        if (m_GrenadeConfig != null)
        {
            _totalLifeTime = m_GrenadeConfig.get_ActualGrnadeLifeTime;
            m_TrailRend.material = m_GrenadeConfig.get_GrenadeTrailMat;
            m_TrailRend.colorGradient = m_GrenadeConfig.get_TrailGrad;
            m_ThrowingSound = m_GrenadeConfig.i_ThrowableAudio.throwSound;
            m_ExplosionSound = m_GrenadeConfig.i_ThrowableAudio.hitSound;
            explosionDelay = m_GrenadeConfig.get_ExplosionDelay;

            if (IsServer)
            {
                ChangeWeaponSkinServerRpc(n_GrenadeOwnerClientId.Value, n_IsBotOwned.Value);
                n_MaxNumOfCollisionsPossible.Value = m_GrenadeConfig.get_MaxCollisionsNum;
            }

            RunLog($"Grenade config loaded: {m_GrenadeConfig.get_CurrentGrenadeName}", nameof(GetGrenadeInfo));
        }
    }

    [ServerRpc]
    void ChangeWeaponSkinServerRpc(ulong actualOwnerId, bool isBotOwned)
    {
        if (!isBotOwned)
        {
            var sendersPlayerObject = NetworkManager.Singleton.ConnectedClients[actualOwnerId].PlayerObject;
            ChangeWeaponSkinClientRpc(sendersPlayerObject);
        }
        else
        {
            if (NetBotPlayerHandler.netBotHandlerSinglton.allSpawnedBots.ContainsKey(actualOwnerId))
            {
                NetBotPlayerHandler.netBotHandlerSinglton.allSpawnedBots[actualOwnerId].TryGet(out NetworkObject botNetObj);
                ChangeWeaponSkinClientRpc(botNetObj);
            }
            else
            {
                RunLogError($"Bot {actualOwnerId} not found in bot handler", nameof(ChangeWeaponSkinServerRpc));
            }
        }
    }

    [ClientRpc]
    void ChangeWeaponSkinClientRpc(NetworkObjectReference ownerPlayerRef)
    {
        ownerPlayerRef.TryGet(out NetworkObject networkObject);
        if (networkObject == null)
        {
            RunLogError("Failed to get network object for grenade skin", nameof(ChangeWeaponSkinClientRpc));
            return;
        }

        networkObject.TryGetComponent(out IAmPlayerServiceLocator actualOwnersPlayerRefs);
        if (actualOwnersPlayerRefs == null || m_GrenadeConfig == null)
        {
            RunLogError("Missing player refs or grenade config", nameof(ChangeWeaponSkinClientRpc));
            return;
        }

        var loadoutScript = actualOwnersPlayerRefs.get_PlayerLoadoutScript;
        if (loadoutScript == null)
        {
            RunLogError("PlayerLoadoutScript is null", nameof(ChangeWeaponSkinClientRpc));
            return;
        }

        var loadoutItem = loadoutScript.TryGetLoadoutItem(
            loadoutScript.m_CurrentSelectedLoadout.LoadoutClassId,
            m_GrenadeConfig.get_ItemClassCategory.ToString());

        if (loadoutItem.ItemId.Length == 0)
        {
            RunLogError("No loadout item found for grenade", nameof(ChangeWeaponSkinClientRpc));
            return;
        }

        _currentWeaponVisual = m_GrenadeConfig.GetCurrentVisual(loadoutItem.ItemSelectedCamoId);

        if (_currentWeaponVisual.skinSprite == null)
        {
            RunLogWarning($"No visual for camo ID: {loadoutItem.ItemSelectedCamoId}, using default", nameof(ChangeWeaponSkinClientRpc));
            if (m_GrenadeConfig.get_WeaponVisuals != null && m_GrenadeConfig.get_WeaponVisuals.Count > 0)
            {
                _currentWeaponVisual = m_GrenadeConfig.get_WeaponVisuals[0];
            }
        }

        m_SpriteRend.sprite = _currentWeaponVisual.skinSprite;
    }

    void FindOwnersPlayerStuffRefrence()
    {
        if (!IsServer) { return; }

        if (!n_IsBotOwned.Value)
        {
            NetworkObject ownersObj = NetworkManager.ConnectedClients[n_GrenadeOwnerClientId.Value].PlayerObject;
            ownersObj.TryGetComponent(out IAmPlayerServiceLocator ownersRef);
            m_GrenadeOwnerPlayerRefrence = ownersRef;
        }
        else
        {
            if (NetBotPlayerHandler.netBotHandlerSinglton.allSpawnedBots.ContainsKey(n_GrenadeOwnerClientId.Value))
            {
                NetBotPlayerHandler.netBotHandlerSinglton.allSpawnedBots[n_GrenadeOwnerClientId.Value].TryGet(out NetworkObject botNetObj);
                botNetObj.TryGetComponent(out IAmPlayerServiceLocator ownersRef);
                m_GrenadeOwnerPlayerRefrence = ownersRef;
            }
            else
            {
                RunLogError($"Bot {n_GrenadeOwnerClientId.Value} not found", nameof(FindOwnersPlayerStuffRefrence));
            }
        }
    }

    public void ChangeGrenadeStateToActive()
    {
        if (IsServer)
        {
            m_GrenadeState.Value = GrenadeState.Active;
            RunLog("Grenade activated", nameof(ChangeGrenadeStateToActive));
        }
    }

    public void StickToTarget(GameObject target)
    {
        if (!IsServer) { return; }

        if (m_GrenadeState.Value == GrenadeState.Active)
        {
            NetworkObject.TrySetParent(target.transform);

            if (m_GrenadeConfig.get_GrenadeType != GrenadeType.sparker &&
                m_GrenadeConfig.get_GrenadeType != GrenadeType.frag)
            {
                StartCoroutine(ExplodeDelayed(explosionDelay));
            }

            RunLog($"Grenade stuck to target: {target.name}", nameof(StickToTarget));
        }
    }

    #endregion

    #region Changing NetworkVariables

    [ServerRpc]
    void ChangeGrenadeNameServerRpc()
    {
        _currentGrenadeName.Value = internalGrenadeName;
    }

    #endregion

    #region Exploding

    private IEnumerator ExplodeDelayed(float delay)
    {
        RunLog($"Explosion scheduled in {delay}s", nameof(ExplodeDelayed));
        yield return new WaitForSeconds(delay);

        if (m_GrenadeState.Value == GrenadeState.Active)
        {
            if (this == null)
            {
                RunLogWarning("Grenade destroyed before delayed explosion", nameof(ExplodeDelayed));
                yield break;
            }
            Explode();
        }
    }

    void ExplodeSparker()
    {
        if (m_GrenadeConfig == null) { return; }

        var sparkerEffect = Instantiate(m_GrenadeConfig.get_SparkerEffect, transform.position, Quaternion.identity);

        // CRITICAL: Move to gameplay scene
        if (_gameplayScene.IsValid() && _gameplayScene.isLoaded)
        {
            SceneManager.MoveGameObjectToScene(sparkerEffect, _gameplayScene);
        }

        Explode();
        RunLog("Sparker explosion triggered", nameof(ExplodeSparker));
    }

    /// <summary>
    /// Main explosion logic with distance-based damage falloff and cover detection
    /// </summary>
    private void Explode()
    {
        if (this == null)
        {
            RunLogWarning("Explosion called on null grenade", nameof(Explode));
            return;
        }

        RunLog($"Grenade exploding: {m_GrenadeConfig?.get_CurrentGrenadeName}", nameof(Explode));

        // Trigger camera shake
        if (CameraShakeManager.HasInstance)
        {
            TriggerGrenadeExplosionShake();
        }

        // Spawn appropriate explosion effect
        switch (m_GrenadeConfig.get_GrenadeDamageType)
        {
            case GrenadeConfigScriptableObject.GrenadeDamageType.basicExploder:
                SpawnPlayerDestroyEffectNoRpc(transform.position);
                SpawnPlayerDestroylEffectServerRpc(transform.position);
                break;

            case GrenadeConfigScriptableObject.GrenadeDamageType.triggerStayDamager:
                var grenadeExplosionEffect = Instantiate(m_GrenadeConfig.get_ExplosionEffect, transform.position, Quaternion.identity);

                // CRITICAL: Move to gameplay scene
                if (_gameplayScene.IsValid() && _gameplayScene.isLoaded)
                {
                    SceneManager.MoveGameObjectToScene(grenadeExplosionEffect, _gameplayScene);
                }

                grenadeExplosionEffect.TryGetComponent(out NetworkObject explosionEffectNetObj);
                grenadeExplosionEffect.TryGetComponent(out TrigerStayDamager triggerStayDmageScript);
                triggerStayDmageScript.ReciveNetworkIfo(n_GrenadeOwnerClientId.Value, n_IsBotOwned.Value, n_FiredByNetObjId.Value, m_GrenadeOwnerPlayerRefrence);
                explosionEffectNetObj.Spawn();
                break;

            case GrenadeConfigScriptableObject.GrenadeDamageType.particleSystemDamager:
                var grenadeExplosionEffect2 = Instantiate(m_GrenadeConfig.get_ExplosionEffect, transform.position, Quaternion.identity);

                // CRITICAL: Move to gameplay scene
                if (_gameplayScene.IsValid() && _gameplayScene.isLoaded)
                {
                    SceneManager.MoveGameObjectToScene(grenadeExplosionEffect2, _gameplayScene);
                }

                grenadeExplosionEffect2.TryGetComponent(out NetworkObject explosionEffectNetObj2);
                grenadeExplosionEffect2.TryGetComponent(out ParticleDamager particleDmageScript);
                particleDmageScript.ReciveNetworkInfo(n_GrenadeOwnerClientId.Value, n_IsBotOwned.Value, n_FiredByNetObjId.Value, m_GrenadeOwnerPlayerRefrence);
                explosionEffectNetObj2.Spawn();
                break;
        }

        // Play explosion sound
        SttdFxManager.PlaySound(m_ExplosionSound, AudioCategory.GrenadeExplosion, transform.position);

        // Process damage to nearby entities
        if (m_GrenadeState.Value == GrenadeState.Active)
        {
            ProcessExplosionDamage();
        }

        // Set grenade state to destroyed
        m_GrenadeState.Value = GrenadeState.Destroyed;
    }

    private void EnsurePhysicsFilters()
    {
        if (_filtersReady) return;

        _targetBuffer = new Collider2D[TargetBufferSize];

        // Triggers stay included, like the plain overlap and ray calls that these replace
        _playerFilter = new ContactFilter2D { useTriggers = true };
        _playerFilter.SetLayerMask(_playerLayerMask);

        _coverFilter = new ContactFilter2D { useTriggers = true };
        _coverFilter.SetLayerMask(_coverLayerMask);

        _filtersReady = true;
    }

    /// <summary>
    /// Process explosion damage with distance falloff and cover detection.
    /// One overlap query finds the candidates. Distance is measured to the nearest point of the
    /// target, cover only blocks damage and never scales it.
    /// </summary>
    private void ProcessExplosionDamage()
    {
        EnsurePhysicsFilters();

        Vector2 origin = transform.position;
        int targetCount = Physics2D.OverlapCircle(origin, m_GrenadeConfig.get_ExplosionRadius, _playerFilter, _targetBuffer);

        if (DebugOn) RunLog($"Explosion detected {targetCount} potential targets", nameof(ProcessExplosionDamage));
        if (targetCount == _targetBuffer.Length)
        {
            RunLogWarning("Explosion target buffer is full, some targets may be missed", nameof(ProcessExplosionDamage));
        }

        _explosionTargets.Clear();

        for (int i = 0; i < targetCount; i++)
        {
            Collider2D targetCollider = _targetBuffer[i];
            if (!targetCollider.TryGetComponent(out IAmPlayerServiceLocator targetRefs)) continue;

            // One hit per entity, also when it has more than one collider on the player layers
            if (!_explosionTargets.Add(targetRefs)) continue;

            PlayerHealthAndDamageHandler targetHealth = targetRefs.get_PlayerHealthScript;
            if (targetHealth == null) continue;

            ulong targetId = targetRefs.get__MID__PlayerOrBotOwnerId;

            // Skip if can't take damage
            if (!targetHealth.GetHealthComponent().CanTakeDamage())
            {
                if (DebugOn) RunLog($"Target {targetId} can't take damage, skipping", nameof(ProcessExplosionDamage));
                continue;
            }

            // Cover between the grenade and the target blocks the damage
            if (!IsTargetExposed(origin, targetCollider))
            {
                if (DebugOn) RunLog($"Target {targetId} behind cover, no damage", nameof(ProcessExplosionDamage));
                continue;
            }

            // Distance to the nearest point of the target, not to its pivot
            float distance = Vector2.Distance(origin, targetCollider.ClosestPoint(origin));
            float damageMultiplier = CalculateDamageFalloff(distance);
            float finalDamage = m_GrenadeConfig.get_ExplosionDamage * damageMultiplier;

            if (DebugOn) RunLog($"Target {targetId} - Distance: {distance:F2}, Multiplier: {damageMultiplier:F2}, Damage: {finalDamage:F1}", nameof(ProcessExplosionDamage));

            // Set player/bot damage type
            SetPlayerBotDamageType(targetRefs);

            // Apply explosion force
            Rigidbody2D targetRigidBody = targetCollider.attachedRigidbody;
            if (targetRigidBody != null)
            {
                Vector2 explosionDirection = targetCollider.transform.position - transform.position;
                targetRigidBody.AddForce(explosionDirection.normalized * m_GrenadeConfig.get_ExplosionForce, ForceMode2D.Impulse);
                _currentExplosionPoint.explosionDirection = explosionDirection;
                _currentExplosionPoint.explosionForce = m_GrenadeConfig.get_ExplosionForce;
            }

            // Send damage request to server
            DoDamageRequest doDamageRequest = new DoDamageRequest(
                finalDamage,
                n_GrenadeOwnerClientId.Value,
                targetId,
                false,
                _currentPlayerAndBotDamageType,
                _currentPlayerKillType,
                _currentWhatWeaponDamagedPlayer,
                _currentExplosionPoint
            );

            NetworkServerManeger.networkServerSingleton.DoDamageRequestServerRpc(doDamageRequest);
        }
    }

    /// <summary>
    /// A target is exposed when at least one of three rays from the grenade reaches it: body centre,
    /// feet, head. The first clear ray decides, so a target in the open costs one ray.
    /// </summary>
    private bool IsTargetExposed(Vector2 origin, Collider2D target)
    {
        Bounds bounds = target.bounds;
        Vector2 center = bounds.center;
        float inset = bounds.size.y * CoverRayInset;

        if (HasClearLine(origin, center)) return true;
        if (HasClearLine(origin, new Vector2(center.x, bounds.min.y + inset))) return true;

        return HasClearLine(origin, new Vector2(center.x, bounds.max.y - inset));
    }

    // A collider that already contains the grenade centre (a grenade resting in the floor) returns a
    // hit at distance 0 because queries start inside colliders. That is not cover between the two points.
    private bool HasClearLine(Vector2 origin, Vector2 point)
    {
        Vector2 toPoint = point - origin;
        float distance = toPoint.magnitude;
        if (distance <= CoverHitEpsilon) return true;

        int hitCount = Physics2D.Raycast(origin, toPoint / distance, _coverFilter, _coverHits, distance);
        for (int i = 0; i < hitCount; i++)
        {
            if (_coverHits[i].distance > CoverHitEpsilon)
            {
                if (DebugOn) RunLog($"Cover detected between grenade and target: {_coverHits[i].collider.name}", nameof(HasClearLine));
                return false;
            }
        }

        return true;
    }

    /// <summary>
    /// Calculate damage falloff based on distance from explosion center
    /// Uses damage profile approach for smooth falloff
    /// </summary>
    private float CalculateDamageFalloff(float distance)
    {
        if (m_GrenadeConfig == null) return 0f;

        float explosionRadius = m_GrenadeConfig.get_ExplosionRadius;

        // If damage profile exists in config, use it
        if (m_GrenadeConfig.get_ProjectileDamageProfile != null && m_GrenadeConfig.get_ProjectileDamageProfile.Count > 0)
        {
            // Find the two points to interpolate between
            for (int i = 0; i < m_GrenadeConfig.get_ProjectileDamageProfile.Count - 1; i++)
            {
                Vector2 current = m_GrenadeConfig.get_ProjectileDamageProfile[i];
                Vector2 next = m_GrenadeConfig.get_ProjectileDamageProfile[i + 1];

                if (distance >= current.x && distance <= next.x)
                {
                    // Interpolate between the two points
                    float t = (distance - current.x) / (next.x - current.x);
                    return Mathf.Lerp(current.y, next.y, t);
                }
            }

            // If beyond last point, use last damage value
            if (m_GrenadeConfig.get_ProjectileDamageProfile.Count > 0)
            {
                return m_GrenadeConfig.get_ProjectileDamageProfile[m_GrenadeConfig.get_ProjectileDamageProfile.Count - 1].y;
            }
        }

        // Fallback: Use inverse square falloff if no damage profile
        float normalizedDistance = distance / explosionRadius;

        if (normalizedDistance <= 0.2f) // Within 20% of center
        {
            return 1.0f; // Full damage - instant kill zone
        }
        else if (normalizedDistance <= 0.5f) // 20-50% of radius
        {
            return Mathf.Lerp(1.0f, 0.75f, (normalizedDistance - 0.2f) / 0.3f);
        }
        else if (normalizedDistance <= 0.8f) // 50-80% of radius
        {
            return Mathf.Lerp(0.75f, 0.4f, (normalizedDistance - 0.5f) / 0.3f);
        }
        else // 80-100% of radius
        {
            return Mathf.Lerp(0.4f, 0.25f, (normalizedDistance - 0.8f) / 0.2f);
        }
    }

    /// <summary>
    /// Set player/bot damage type for proper kill credit
    /// </summary>
    private void SetPlayerBotDamageType(IAmPlayerServiceLocator _collisionPlayerRefs)
    {
        if (m_GrenadeOwnerPlayerRefrence == null || _collisionPlayerRefs == null)
        {
            RunLogWarning("Missing references for damage type determination", nameof(SetPlayerBotDamageType));
            return;
        }

        bool ownerIsBot = m_GrenadeOwnerPlayerRefrence.get_PlayerTeamHandler.n_IsBotPlayer.Value;
        bool targetIsBot = _collisionPlayerRefs.get_PlayerTeamHandler.n_IsBotPlayer.Value;

        if (!ownerIsBot && !targetIsBot)
        {
            _currentPlayerAndBotDamageType = MID_PlayerAndBotDamageType.Player_Damage_Player;
        }
        else if (!ownerIsBot && targetIsBot)
        {
            _currentPlayerAndBotDamageType = MID_PlayerAndBotDamageType.Player_Damage_Bot;
        }
        else if (ownerIsBot && !targetIsBot)
        {
            _currentPlayerAndBotDamageType = MID_PlayerAndBotDamageType.Bot_Damage_Player;
        }
        else if (ownerIsBot && targetIsBot)
        {
            _currentPlayerAndBotDamageType = MID_PlayerAndBotDamageType.Bot_Damage_Bot;
        }
    }

    [ServerRpc(RequireOwnership = false)]
    public void SpawnPlayerDestroylEffectServerRpc(Vector2 Position)
    {
        SpawnPlayerDestroyEffectClientRpc(Position);
    }

    [ClientRpc]
    public void SpawnPlayerDestroyEffectClientRpc(Vector2 Position)
    {
        if (IsOwner) { return; }
        var effect = Instantiate(m_GrenadeConfig.get_ExplosionEffect, Position, Quaternion.identity);

        // CRITICAL: Move to gameplay scene
        if (_gameplayScene.IsValid() && _gameplayScene.isLoaded)
        {
            SceneManager.MoveGameObjectToScene(effect, _gameplayScene);
        }
    }

    public void SpawnPlayerDestroyEffectNoRpc(Vector2 Position)
    {
        var effect = Instantiate(m_GrenadeConfig.get_ExplosionEffect, Position, Quaternion.identity);

        // CRITICAL: Move to gameplay scene
        if (_gameplayScene.IsValid() && _gameplayScene.isLoaded)
        {
            SceneManager.MoveGameObjectToScene(effect, _gameplayScene);
        }
    }

    #endregion

    #region Camera Shake

    private void TriggerGrenadeExplosionShake()
    {
        if (m_GrenadeConfig == null) return;

        float intensity = m_GrenadeConfig.get_CameraShakeIntensity;
        TriggerGrenadeShakeClientRpc(transform.position, intensity);
    }

    [ClientRpc]
    private void TriggerGrenadeShakeClientRpc(Vector3 explosionPosition, float intensityMultiplier)
    {
        if (CameraShakeManager.HasInstance)
        {
            CameraShakeManager.Instance.ShakeOnGrenadeExplosion(explosionPosition, intensityMultiplier);
        }
    }

    #endregion

    #region SatBlocker Collision

    void DestroyGrenadeOnCollisionWithSatBlocker()
    {
        if (_collisionWithSatBlockerDestroyEffect == null)
        {
            return;
        }
        if (!IsServer) { return; }

        SpawnSatBlockerExplosionEffectServerRpc(transform.position);
        SpawnSatBlockerExplosionEffectNoRpc(transform.position);

        m_GrenadeState.Value = GrenadeState.Destroyed;
        RunLog("Grenade destroyed by sat blocker", nameof(DestroyGrenadeOnCollisionWithSatBlocker));
    }

    [ServerRpc(RequireOwnership = false)]
    public void SpawnSatBlockerExplosionEffectServerRpc(Vector2 Position)
    {
        SpawnSatBlockerExplosionEffectClientRpc(Position);
    }

    [ClientRpc]
    public void SpawnSatBlockerExplosionEffectClientRpc(Vector2 Position)
    {
        if (IsServer) { return; }
        var effect = Instantiate(_collisionWithSatBlockerDestroyEffect, Position, Quaternion.identity);

        // CRITICAL: Move to gameplay scene
        if (_gameplayScene.IsValid() && _gameplayScene.isLoaded)
        {
            SceneManager.MoveGameObjectToScene(effect, _gameplayScene);
        }
    }

    public void SpawnSatBlockerExplosionEffectNoRpc(Vector2 Position)
    {
        if (!IsServer) { return; }
        var effect = Instantiate(_collisionWithSatBlockerDestroyEffect, Position, Quaternion.identity);

        // CRITICAL: Move to gameplay scene
        if (_gameplayScene.IsValid() && _gameplayScene.isLoaded)
        {
            SceneManager.MoveGameObjectToScene(effect, _gameplayScene);
        }
    }

    #endregion

    #region Sound

    void PlayThrowSoundLocally()
    {
        if (m_GrenadeConfig == null) { return; }
        if (m_GrenadeConfig.i_ThrowableAudio.throwSound == null) { return; }

        SttdFxManager.PlaySound(m_GrenadeConfig.i_ThrowableAudio.throwSound, AudioCategory.GrenadeThrow, transform.position);
    }

    #endregion

    #region Cleanup & Pool Management

    /// <summary>
    /// Cleanup for pool return
    /// </summary>
    public void CleanupForPoolReturn()
    {
        RunLog($"Cleaning up grenade for pool return: {gameObject.name}", nameof(CleanupForPoolReturn));

        // Return extra items to pool
        if (_extraItemsInstance != null && m_GrenadeConfig != null)
        {
            PoolableObjectType poolType = m_GrenadeConfig.get_SpawnableExtraItemType;

            if (LocalObjectPool.Instance != null && LocalObjectPool.Instance.IsRegistered(poolType))
            {
                LocalObjectPool.Instance.ReturnObject(_extraItemsInstance, poolType);
                RunLog($"Returned grenade extra items to pool: {poolType}", nameof(CleanupForPoolReturn));
            }

            _extraItemsInstance = null;
            _grenadeExtraItems = null;
            _extraItemsInitialized = false;
        }

        // Reset grenade state
        enableSpecialBehaviour = false;
        _isActive = false;

        // Reset physics
        if (m_RigidBody2d != null)
        {
            m_RigidBody2d.velocity = Vector2.zero;
            m_RigidBody2d.angularVelocity = 0f;
        }

        // Clear references
        m_GrenadeOwnerPlayerRefrence = null;

        // Reset transform
        transform.localPosition = Vector3.zero;
        transform.localRotation = Quaternion.identity;
        transform.localScale = Vector3.one;

        // Clear parent
        if (transform.parent != null)
        {
            transform.SetParent(null);
        }

        RunLog($"Grenade cleanup complete: {gameObject.name}", nameof(CleanupForPoolReturn));
    }

    /// <summary>
    /// Force stop all activities
    /// </summary>
    public void ForceStopAllActivities()
    {
        RunLog("Force stopping all grenade activities", nameof(ForceStopAllActivities));

        // Stop effects
        if (_extraItemsInitialized && _grenadeExtraItems != null)
        {
            _grenadeExtraItems.StopAllParticles();
            _grenadeExtraItems.DisableAllTrails();
        }

        // Stop coroutines
        StopAllCoroutines();

        RunLog("All grenade activities stopped", nameof(ForceStopAllActivities));
    }

    /// <summary>
    /// Check if grenade is ready for use
    /// </summary>
    public bool IsReadyForUse()
    {
        return _initialized &&
               _isActive &&
               m_GrenadeConfig != null;
    }

    #endregion

    #region Logging Helper Methods

    private bool DebugOn => _logLevel >= MID_LogLevel.Debug;

    private void RunLog(string message, string methodName = "")
    {
        MID_Logger.LogDebug(_logLevel, message, nameof(GrenadeScriptMain), methodName);
    }

    private void RunLogWarning(string message, string methodName = "")
    {
        MID_Logger.LogWarning(MID_LogLevel.Info, message, nameof(GrenadeScriptMain), methodName);
    }

    private void RunLogError(string message, string methodName = "", Exception e = null)
    {
        MID_Logger.LogError(MID_LogLevel.Info, message, nameof(GrenadeScriptMain), methodName, e);
    }

    #endregion
}
