﻿// ============================================================================
// NOTICE: Full documentation and design decisions for this file
// live in docs/StickToTheDeath/bots.md, section "PlayerDirectionalIndicatorSystem.cs"
// ============================================================================
using UnityEngine;
using MidManStudio.Core.Logging;
using MidManStudio.Core.TickDispatcher;
using System.Collections.Generic;
using MidManStudio.Sttd.InGame.Setup;
/// <summary>
/// World-space directional indicators for teammates and enemies
/// Only shown while a clairvoyance is on and no counter-clairvoyance is on
/// Clairvoyance and counter-clairvoyance are counted, so two summons stack
/// </summary>
public class PlayerDirectionalIndicatorSystem : MonoBehaviour
{
    #region Serialized Fields

    [Header("Indicator Settings")]
    [SerializeField] private GameObject _teammateIndicatorPrefab;
    [SerializeField] private GameObject _enemyIndicatorPrefab;
    [SerializeField] private float _indicatorDistance = 3f; // Distance from player
    [SerializeField] private float _verticalOffset = 1.5f; // Height above player
    [SerializeField] private float _rotationSpeed = 10f;
    [SerializeField] private float _spriteAngleOffset = 0f; // Degrees, 0 when the arrow sprite points right

    [Header("Visibility Settings")]
    [SerializeField] private float _maxIndicatorRange = 50f; // Don't show if too far
    [SerializeField] private float _minIndicatorRange = 5f; // Don't show if too close

    [Header("Debug")]
    [SerializeField] private MID_LogLevel _logLevel = MID_LogLevel.Error;

    #endregion

    #region Private Variables

    // The dispatcher floor for gameplay is Tick_0_1. The rate is fixed in code, a serialized rate
    // on a prefab overrides a default.
    private const TickRate IndicatorTickRate = TickRate.Tick_0_1;

    private IAmPlayerServiceLocator _localPlayerRef;
    private Transform _playerTransform;
    private ulong _localPlayerId;

    // Indicator tracking
    private Dictionary<ulong, DirectionalIndicator> _activeIndicators = new Dictionary<ulong, DirectionalIndicator>();

    // Reused every tick
    private readonly HashSet<ulong> _seenPlayerIds = new HashSet<ulong>();
    private readonly List<ulong> _stalePlayerIds = new List<ulong>();

    // State
    private bool _isInitialized = false;
    private bool _isSubscribedToTicker = false;

    // Active clairvoyance and counter-clairvoyance buffs. Indicators show while there is a clairvoyance
    // and no counter-clairvoyance.
    private int _clairvoyanceSources = 0;
    private int _counterSources = 0;
    private bool _isShowing = false;

    // Object pools
    private Queue<GameObject> _teammateIndicatorPool = new Queue<GameObject>();
    private Queue<GameObject> _enemyIndicatorPool = new Queue<GameObject>();
    private const int POOL_SIZE = 10;

    #endregion

    #region Indicator Data

    private class DirectionalIndicator
    {
        public GameObject IndicatorObject;
        public Transform IndicatorTransform;
        public SpriteRenderer SpriteRenderer;
        public ulong TargetPlayerId;
        public bool IsTeammate;
        public Vector3 LastKnownPosition;

        public DirectionalIndicator(GameObject obj, ulong targetId, bool isTeammate)
        {
            IndicatorObject = obj;
            IndicatorTransform = obj.transform;
            SpriteRenderer = obj.GetComponent<SpriteRenderer>();
            TargetPlayerId = targetId;
            IsTeammate = isTeammate;
        }
    }

    #endregion

    #region Initialization

    public void Initialize(ulong localPlayerId, IAmPlayerServiceLocator playerRef)
    {
        if (_isInitialized)
        {
            LogWarning("Already initialized", nameof(Initialize));
            return;
        }

        _localPlayerId = localPlayerId;
        _localPlayerRef = playerRef;
        _playerTransform = playerRef.transform;

        InitializePools();

        _isInitialized = true;
        if (DebugOn) LogDebug($"Initialized for player {localPlayerId}", nameof(Initialize));
    }

    /// <summary>
    /// Initializes on first use. The server manager calls this on the local player before the first
    /// activation, so the pools are only built for the player who can see indicators.
    /// </summary>
    public void EnsureInitialized(IAmPlayerServiceLocator playerRef)
    {
        if (_isInitialized || playerRef == null) return;

        Initialize(playerRef.get__MID__PlayerOrBotOwnerId, playerRef);
    }

    private void InitializePools()
    {
        for (int i = 0; i < POOL_SIZE; i++)
        {
            if (_teammateIndicatorPrefab != null)
            {
                GameObject indicator = Instantiate(_teammateIndicatorPrefab, transform);
                indicator.SetActive(false);
                _teammateIndicatorPool.Enqueue(indicator);
            }

            if (_enemyIndicatorPrefab != null)
            {
                GameObject indicator = Instantiate(_enemyIndicatorPrefab, transform);
                indicator.SetActive(false);
                _enemyIndicatorPool.Enqueue(indicator);
            }
        }
    }

    #endregion

    #region Clairvoyance Control

    /// <summary>
    /// One more clairvoyance on this player. Indicators show while at least one is on and no
    /// counter-clairvoyance is on.
    /// </summary>
    public void ActivateClairvoyance()
    {
        _clairvoyanceSources++;
        RefreshState();
    }

    /// <summary>
    /// One clairvoyance less. Indicators hide when the last one ends.
    /// </summary>
    public void DeactivateClairvoyance()
    {
        if (_clairvoyanceSources > 0) _clairvoyanceSources--;
        RefreshState();
    }

    /// <summary>
    /// One more counter-clairvoyance on this player. While one is on, the clairvoyance of this
    /// player is switched off, whatever its source.
    /// </summary>
    public void ActivateCounterClairvoyance()
    {
        _counterSources++;
        RefreshState();
    }

    /// <summary>
    /// One counter-clairvoyance less. A clairvoyance that is still on shows again when the last one ends.
    /// </summary>
    public void DeactivateCounterClairvoyance()
    {
        if (_counterSources > 0) _counterSources--;
        RefreshState();
    }

    private void RefreshState()
    {
        bool shouldShow = _clairvoyanceSources > 0 && _counterSources == 0;
        if (shouldShow == _isShowing) return;

        if (shouldShow)
        {
            if (!_isInitialized)
            {
                LogWarning("Clairvoyance requested before the indicator system was initialized", nameof(RefreshState));
                return;
            }

            _isShowing = true;
            SubscribeToTicker();
        }
        else
        {
            _isShowing = false;
            UnsubscribeFromTicker();
            HideAllIndicators();
        }

        if (DebugOn) LogDebug($"Indicators {(_isShowing ? "shown" : "hidden")} (clairvoyance {_clairvoyanceSources}, counter {_counterSources})", nameof(RefreshState));
    }

    #endregion

    #region Tick Subscription

    private void SubscribeToTicker()
    {
        if (_isSubscribedToTicker) return;

        MID_TickDispatcher.Subscribe(IndicatorTickRate, OnIndicatorTick);
        _isSubscribedToTicker = true;
    }

    private void UnsubscribeFromTicker()
    {
        if (!_isSubscribedToTicker) return;

        MID_TickDispatcher.Unsubscribe(IndicatorTickRate, OnIndicatorTick);
        _isSubscribedToTicker = false;
    }

    #endregion

    #region Update Tick

    private void OnIndicatorTick(float deltaTime)
    {
        if (!_isInitialized || _playerTransform == null) return;

        if (!_isShowing)
        {
            HideAllIndicators();
            return;
        }

        UpdateIndicators(deltaTime);
    }

    // Walks the entity list of IAmPlayerServiceLocator. Nothing is allocated and no component is searched.
    private void UpdateIndicators(float deltaTime)
    {
        if (_localPlayerRef == null || _localPlayerRef.get_PlayerTeamHandler == null) return;

        PlayerTeam localTeam = _localPlayerRef.get_PlayerTeamHandler.m_PlayerTeam.Value;
        Vector3 localPosition = _playerTransform.position;
        float maxSqrRange = _maxIndicatorRange * _maxIndicatorRange;
        float minSqrRange = _minIndicatorRange * _minIndicatorRange;

        _seenPlayerIds.Clear();
        IReadOnlyList<IAmPlayerServiceLocator> all = IAmPlayerServiceLocator.All;

        for (int i = 0; i < all.Count; i++)
        {
            IAmPlayerServiceLocator other = all[i];
            if (other == null || other.get_PlayerTeamHandler == null) continue;

            ulong playerId = other.get__MID__PlayerOrBotOwnerId;

            // Skip self
            if (playerId == _localPlayerId) continue;

            _seenPlayerIds.Add(playerId);

            if (other.get_PlayerHealthScript.GetHealthComponent().IsDead())
            {
                HideIndicator(playerId);
                continue;
            }

            Vector3 otherPosition = other.transform.position;
            float sqrDistance = (otherPosition - localPosition).sqrMagnitude;
            if (sqrDistance > maxSqrRange || sqrDistance < minSqrRange)
            {
                HideIndicator(playerId);
                continue;
            }

            if (!_activeIndicators.TryGetValue(playerId, out DirectionalIndicator indicator))
            {
                bool isTeammate = !NetTeamRules.AreEnemies(localTeam, other.get_PlayerTeamHandler.m_PlayerTeam.Value);
                indicator = CreateIndicator(playerId, isTeammate);
                if (indicator == null) continue;
                _activeIndicators[playerId] = indicator;
            }
            else if (indicator.IndicatorObject != null && !indicator.IndicatorObject.activeSelf)
            {
                // Hidden earlier (dead, out of range or clairvoyance switched off), in range again
                indicator.IndicatorObject.SetActive(true);
            }

            UpdateIndicatorTransform(indicator, otherPosition, deltaTime);
        }

        // Remove indicators for entities that are gone
        _stalePlayerIds.Clear();
        foreach (KeyValuePair<ulong, DirectionalIndicator> kvp in _activeIndicators)
        {
            if (!_seenPlayerIds.Contains(kvp.Key))
            {
                _stalePlayerIds.Add(kvp.Key);
            }
        }

        for (int i = 0; i < _stalePlayerIds.Count; i++)
        {
            RemoveIndicator(_stalePlayerIds[i]);
        }
    }

    private void UpdateIndicatorTransform(DirectionalIndicator indicator, Vector3 targetPosition, float deltaTime)
    {
        if (_playerTransform == null || indicator.IndicatorTransform == null) return;

        Vector3 directionToTarget = (targetPosition - _playerTransform.position).normalized;

        // Position indicator around player
        Vector3 indicatorPosition = _playerTransform.position +
            (directionToTarget * _indicatorDistance) +
            (Vector3.up * _verticalOffset);

        indicator.IndicatorTransform.position = indicatorPosition;

        // The game is 2D: the arrow turns around Z, toward the target in the XY plane
        if (directionToTarget.x != 0f || directionToTarget.y != 0f)
        {
            float angle = Mathf.Atan2(directionToTarget.y, directionToTarget.x) * Mathf.Rad2Deg + _spriteAngleOffset;
            indicator.IndicatorTransform.rotation = Quaternion.Slerp(
                indicator.IndicatorTransform.rotation,
                Quaternion.Euler(0f, 0f, angle),
                _rotationSpeed * deltaTime
            );
        }

        indicator.LastKnownPosition = targetPosition;
    }

    #endregion

    #region Indicator Management

    private DirectionalIndicator CreateIndicator(ulong playerId, bool isTeammate)
    {
        GameObject indicatorObj = isTeammate
            ? GetIndicatorFromPool(_teammateIndicatorPool, _teammateIndicatorPrefab)
            : GetIndicatorFromPool(_enemyIndicatorPool, _enemyIndicatorPrefab);

        if (indicatorObj == null) return null;

        indicatorObj.SetActive(true);
        indicatorObj.transform.SetParent(transform);

        return new DirectionalIndicator(indicatorObj, playerId, isTeammate);
    }

    private void HideIndicator(ulong playerId)
    {
        if (_activeIndicators.TryGetValue(playerId, out DirectionalIndicator indicator))
        {
            if (indicator.IndicatorObject != null)
            {
                indicator.IndicatorObject.SetActive(false);
            }
        }
    }

    private void RemoveIndicator(ulong playerId)
    {
        if (_activeIndicators.TryGetValue(playerId, out DirectionalIndicator indicator))
        {
            ReturnIndicatorToPool(indicator);
            _activeIndicators.Remove(playerId);
        }
    }

    private void HideAllIndicators()
    {
        foreach (var kvp in _activeIndicators)
        {
            if (kvp.Value.IndicatorObject != null)
            {
                kvp.Value.IndicatorObject.SetActive(false);
            }
        }
    }

    private GameObject GetIndicatorFromPool(Queue<GameObject> pool, GameObject prefab)
    {
        if (pool.Count > 0)
        {
            GameObject indicator = pool.Dequeue();
            if (indicator != null) return indicator;
        }

        return Instantiate(prefab, transform);
    }

    private void ReturnIndicatorToPool(DirectionalIndicator indicator)
    {
        if (indicator.IndicatorObject == null) return;

        indicator.IndicatorObject.SetActive(false);

        Queue<GameObject> targetPool = indicator.IsTeammate
            ? _teammateIndicatorPool
            : _enemyIndicatorPool;

        targetPool.Enqueue(indicator.IndicatorObject);
    }

    #endregion

    #region Cleanup

    private void OnEnable()
    {
        // A disable removes the tick subscription, so an active clairvoyance subscribes again here.
        if (_isShowing) SubscribeToTicker();
    }

    private void OnDisable()
    {
        UnsubscribeFromTicker();
    }

    private void OnDestroy()
    {
        UnsubscribeFromTicker();

        // Clean up indicators
        foreach (var kvp in _activeIndicators)
        {
            if (kvp.Value.IndicatorObject != null)
            {
                Destroy(kvp.Value.IndicatorObject);
            }
        }
        _activeIndicators.Clear();

        // Clean up pools
        while (_teammateIndicatorPool.Count > 0)
        {
            var obj = _teammateIndicatorPool.Dequeue();
            if (obj != null) Destroy(obj);
        }

        while (_enemyIndicatorPool.Count > 0)
        {
            var obj = _enemyIndicatorPool.Dequeue();
            if (obj != null) Destroy(obj);
        }
    }

    #endregion

    #region Logging

    private bool DebugOn => _logLevel >= MID_LogLevel.Debug;

    private void LogDebug(string message, string method) =>
        MID_Logger.LogDebug(_logLevel, message, nameof(PlayerDirectionalIndicatorSystem), method);

    private void LogWarning(string message, string method) =>
        MID_Logger.LogWarning(_logLevel, message, nameof(PlayerDirectionalIndicatorSystem), method);

    #endregion
}
