﻿// ============================================================================
// NOTICE: Full documentation and design decisions for this file
// live in docs/StickToTheDeath/bots.md, section "NetAiSummon.cs"
// ============================================================================
using System.Collections.Generic;
using UnityEngine;
using Unity.Netcode;
using MidManStudio.Sttd.InGame.NetworkDataStructures;
using Pathfinding;
using MidManStudio.Core.Pools;
using MidManStudio.Netcode.Pools;
using MidManStudio.Sttd.InGame.Setup;
using MidManStudio.Sttd.InGame.GameItemData;

namespace MidManStudio.Sttd.InGame.AI
{
    /// <summary>
    /// AI of the minions of a player summon (the Hunter's minions, the flies of the swarm).
    /// Targets the enemies of its owner, follows the owner when there is none.
    /// </summary>
    [RequireComponent(typeof(NetAiPathfindingModule))]
    [RequireComponent(typeof(NetAiHealthHandler))]
    [RequireComponent(typeof(Rigidbody2D))]
    [RequireComponent(typeof(Collider2D))]
    [RequireComponent(typeof(Seeker))]
    public class NetAiSummon : NetAiBase
    {
        #region Summon Types
        public enum SummonType
        {
            Combat,         // Attacks enemies (Hunter, BlackPhoenix)
            Utility,        // Provides vision/support (Clairvoyance)
            Defensive       // Protects owner (CounterClairvoyance)
        }
        #endregion

        #region Configuration
        [Header("Summon Specific")]
        [SerializeField] private SummonType summonType = SummonType.Combat;
        [SerializeField] private float targetSearchInterval = 1f;
        [SerializeField] private float attackRange = 5f;
        [SerializeField] private float attackCooldown = 1f;
        [SerializeField] private int attackDamage = 15;
        [SerializeField] private float followDistance = 3f;

        [Header("Projectile Settings")]
        [SerializeField] private bool usesProjectiles = false;
        [SerializeField] private GameObject projectilePrefab;
        [SerializeField] private Transform projectileSpawnPoint;
        [SerializeField] private float projectileSpeed = 10f;

        [Header("Lifetime")]
        [SerializeField] private bool hasLifetime = false;
        [SerializeField] private float lifetime = 30f;
        #endregion

        #region State
        private Transform _owner;
        private IAmPlayerServiceLocator _ownerRefs;
        private IAmPlayerServiceLocator _currentTargetRefs;
        private float _lastTargetSearchTime;
        private float _lastAttackTime;
        private float _spawnTime;
        #endregion

        #region Initialization
        // Runs on the server when the minion spawns. The minion comes from a pool, so everything of
        // the previous life is reset here.
        protected override void InitializeModules()
        {
            base.InitializeModules();

            if (entityType != AiEntityType.PlayerSummon)
            {
                RunLogWarning($"NetAiSummon used with entityType: {entityType}. Should be PlayerSummon.", nameof(InitializeModules));
            }

            _spawnTime = Time.time;
            _lastTargetSearchTime = -targetSearchInterval;
            _lastAttackTime = -attackCooldown;
            _currentTarget = null;
            _currentTargetRefs = null;

            // The owner is set before the spawn, when IsServer is not valid yet, so the owner id is
            // taken from the owner here and not from SetOwner.
            if (_ownerRefs != null)
            {
                n_OwnerClientId.Value = _ownerRefs.get__MID__PlayerOrBotOwnerId;
            }

            // A dead minion goes back to the pool of the minions
            _healthHandler.SetPoolType(PoolableNetworkObjectType.SummonMinion_Blueprint);

            // Summons are never activated by a spawn manager, they run as soon as they spawn
            ActivateAI();
        }

        public void SetOwnerRefs(IAmPlayerServiceLocator ownerRefs)
        {
            _ownerRefs = ownerRefs;
            _owner = ownerRefs != null ? ownerRefs.transform : null;

            if (_enableLogs && _owner != null) RunLog($"Owner set to: {_owner.name}", nameof(SetOwnerRefs));
        }

        public void SetOwnerTransform(Transform owner)
        {
            if (owner != null && owner.TryGetComponent(out IAmPlayerServiceLocator ownerRefs))
            {
                SetOwnerRefs(ownerRefs);
                return;
            }

            _owner = owner;
            _ownerRefs = null;
        }
        #endregion

        #region Update Loop
        protected override void UpdateAI()
        {
            base.UpdateAI();

            if (hasLifetime && Time.time - _spawnTime >= lifetime)
            {
                DespawnSummon();
            }
        }

        private void DespawnSummon()
        {
            RunLog("Summon lifetime expired", nameof(DespawnSummon));

            if (!IsServer || NetworkObject == null || !NetworkObject.IsSpawned) return;

            // Stop the AI, a despawn is not instant
            _isActive = false;

            if (MID_NetworkObjectPool.Instance != null)
            {
                MID_NetworkObjectPool.Instance.ReturnNetworkObject(NetworkObject, PoolableNetworkObjectType.SummonMinion_Blueprint);
            }

            NetworkObject.Despawn();
        }
        #endregion

        #region Targeting
        protected override void UpdateTargeting()
        {
            if (Time.time - _lastTargetSearchTime < targetSearchInterval)
                return;

            _lastTargetSearchTime = Time.time;

            if (summonType == SummonType.Utility || summonType == SummonType.Defensive)
            {
                FollowOwner();
                return;
            }

            // _currentTargetRefs is only set for an enemy, so a minion that follows its owner looks again
            if (_currentTargetRefs == null || !IsValidEnemyTarget(_currentTargetRefs))
            {
                FindNearestEnemy();
            }
            else if (_owner != null)
            {
                // Too far from the owner, come back
                float leash = followDistance * 2f;
                if (SqrDistanceTo(_owner.position) > leash * leash)
                {
                    FollowOwner();
                }
            }
        }

        private void FollowOwner()
        {
            _currentTargetRefs = null;
            if (_owner == null) return;

            if (SqrDistanceTo(_owner.position) > followDistance * followDistance)
            {
                SetTarget(_owner);
            }
            else
            {
                SetTarget(null);
            }
        }

        // The nearest living enemy of the owner. The list of players and bots is walked, nothing is
        // searched in the scene.
        private void FindNearestEnemy()
        {
            if (_owner == null || _ownerRefs == null)
            {
                _currentTarget = null;
                _currentTargetRefs = null;
                return;
            }

            IAmPlayerServiceLocator nearest = null;
            float nearestSqrDistance = float.MaxValue;

            IReadOnlyList<IAmPlayerServiceLocator> all = IAmPlayerServiceLocator.All;
            for (int i = 0; i < all.Count; i++)
            {
                IAmPlayerServiceLocator entity = all[i];
                if (!IsValidEnemyTarget(entity)) continue;

                float sqrDistance = SqrDistanceTo(entity.transform.position);
                if (sqrDistance < nearestSqrDistance)
                {
                    nearestSqrDistance = sqrDistance;
                    nearest = entity;
                }
            }

            if (nearest != null)
            {
                _currentTargetRefs = nearest;
                SetTarget(nearest.transform);
                if (_enableLogs) RunLog($"Acquired enemy target: {nearest.name}", nameof(FindNearestEnemy));
            }
            else
            {
                FollowOwner();
            }
        }

        // An enemy of the owner that is alive. NetTeamRules decides who is an enemy: the other teams,
        // everyone but the owner in Free For All, nobody in Survival.
        private bool IsValidEnemyTarget(IAmPlayerServiceLocator entity)
        {
            if (entity == null || _ownerRefs == null || entity == _ownerRefs) return false;
            if (!NetTeamRules.AreEnemies(_ownerRefs, entity)) return false;

            PlayerHealthAndDamageHandler health = entity.get_PlayerHealthScript;
            if (health == null) return false;

            NetHealthComponent healthComponent = health.GetHealthComponent();
            return healthComponent != null && !healthComponent.IsDead() && !healthComponent.IsSpawning();
        }

        private float SqrDistanceTo(Vector3 position)
        {
            return ((Vector2)transform.position - (Vector2)position).sqrMagnitude;
        }
        #endregion

        #region Combat
        protected override void UpdateCombat()
        {
            if (summonType != SummonType.Combat) return;
            if (_currentTargetRefs == null) return;

            float distanceToTarget = _pathfindingModule.GetDistanceToTarget();

            if (distanceToTarget <= attackRange && Time.time - _lastAttackTime >= attackCooldown)
            {
                Attack();
            }
        }

        private void Attack()
        {
            _lastAttackTime = Time.time;

            if (_animationController != null)
            {
                _animationController.PlayAttackAnimation();
            }

            if (usesProjectiles)
            {
                FireProjectile();
            }
            else
            {
                MeleeAttack();
            }
        }

        // Not networked: the projectile is a plain instance on the server. No summon prefab uses it.
        private void FireProjectile()
        {
            if (projectilePrefab == null || _currentTarget == null) return;

            Vector3 spawnPosition = projectileSpawnPoint != null ? projectileSpawnPoint.position : transform.position;
            Vector2 direction = (_currentTarget.position - spawnPosition).normalized;

            GameObject projectile = Instantiate(projectilePrefab, spawnPosition, Quaternion.identity);

            var rb = projectile.GetComponent<Rigidbody2D>();
            if (rb != null)
            {
                rb.velocity = direction * projectileSpeed;
            }

            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            projectile.transform.rotation = Quaternion.Euler(0, 0, angle);

            if (_enableLogs) RunLog($"Fired projectile at {_currentTarget.name}", nameof(FireProjectile));
        }

        // Hits every living enemy of the owner within the attack range. The damage is sent in the name
        // of the owner, so the owner gets the kill and the team rules of the server apply.
        private void MeleeAttack()
        {
            if (_ownerRefs == null) return;

            ulong ownerId = n_OwnerClientId.Value;
            float sqrRange = attackRange * attackRange;

            IReadOnlyList<IAmPlayerServiceLocator> all = IAmPlayerServiceLocator.All;
            for (int i = 0; i < all.Count; i++)
            {
                IAmPlayerServiceLocator entity = all[i];
                if (!IsValidEnemyTarget(entity)) continue;
                if (SqrDistanceTo(entity.transform.position) > sqrRange) continue;

                ulong targetId = entity.get__MID__PlayerOrBotOwnerId;

                DoDamageRequest damageRequest = new DoDamageRequest(
                    attackDamage,
                    ownerId,
                    targetId,
                    false,
                    NetDamageHandler.GetRegularDamageType(ownerId, targetId),
                    new MID_PlayerKillTypeAndPoints
                    {
                        _playerKillType = MID_PlayerKillType.Killer,
                        _valueInPoints = 100
                    },
                    MID_WhatWeaponDamagedPlayer.ScoreSummon,
                    null
                );

                NetworkServerManeger.networkServerSingleton.DoDamageRequestServerRpc(damageRequest);
                if (_enableLogs) RunLog($"Dealt {attackDamage} damage to {entity.name}", nameof(MeleeAttack));
            }
        }
        #endregion

        #region Death Handling
        protected override void OnEntityDeath(DoDamageRequest damageRequest)
        {
            RunLog("Summon destroyed", nameof(OnEntityDeath));
            // No points awarded for summon deaths. The health handler returns the minion to its pool.
        }
        #endregion

        #region Debug
        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.blue;
            Gizmos.DrawWireSphere(transform.position, attackRange);

            Gizmos.color = Color.cyan;
            Gizmos.DrawWireSphere(transform.position, followDistance);

            if (_owner != null)
            {
                Gizmos.color = Color.green;
                Gizmos.DrawLine(transform.position, _owner.position);
            }
        }
        #endregion
    }
}
