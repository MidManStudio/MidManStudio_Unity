// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/com.midmanstudio.utilities/fx.md, section "GlobalFXManager.cs"
// ============================================================================
using System.Collections.Generic;
using UnityEngine;
using MidManStudio.Core.Logging;
using MidManStudio.Core.Singleton;
using MidManStudio.Core.EditorUtils;
using MidManStudio.Core.Pools;

namespace MidManStudio.Core.FX
{
    /// <summary>
    /// Plays CPU-driven particle and flipbook effects by category and type, with a spatial throttle and
    /// per-category frame caps. Raises <see cref="CategoryAudioRequested"/> for each effect so an audio
    /// component can react without this package depending on it.
    /// </summary>
    public class GlobalFXManager : Singleton<GlobalFXManager>
    {
        // ── Inspector ─────────────────────────────────────────────────────────

        [SerializeField] private MID_LogLevel _logLevel = MID_LogLevel.Info;

        [Header("Effects  —  set Simulation Space = World on every ParticleSystem")]
        [MID_NamedList]
        [SerializeField] private List<FXEntry> _effects = new();

        [Header("Spatial Throttling")]
        [Tooltip("Minimum world-space distance between same-category emissions in the same frame.")]
        [SerializeField] private float _spatialThrottleRadius = 0.4f;

        [Header("Per-Category Frame Caps")]
        [SerializeField] private int _maxImpactPerFrame      = 12;
        [SerializeField] private int _maxMuzzlePerFrame      = 8;
        [SerializeField] private int _maxShellPerFrame       = 16;
        [SerializeField] private int _maxExplosionPerFrame   = 4;
        [Tooltip("Cap applied to any user-added category not listed above.")]
        [SerializeField] private int _maxOtherPerFrame       = 8;

        // ── Events ────────────────────────────────────────────────────────────

        /// <summary>
        /// Raised for each effect that plays, with its category and volume. MID_FXAudioRelay in
        /// com.midmanstudio.audio listens to it and plays the matching clip.
        /// </summary>
        public static event System.Action<EffectCategory, float> CategoryAudioRequested;

        // ── Runtime state ─────────────────────────────────────────────────────

        private readonly Dictionary<long, FXEntry> _lookup = new();
        private readonly List<(EffectCategory cat, Vector3 pos)> _frameEmissions = new(64);
        private readonly Dictionary<int, int> _frameCounts = new();
        private ParticleSystem.EmitParams _emitParams;

        // ── Unity Lifecycle ───────────────────────────────────────────────────

        protected override void Awake()
        {
            base.Awake();
            BuildLookup();
            ValidateSystems();
        }

        private void LateUpdate()
        {
            _frameEmissions.Clear();
            _frameCounts.Clear();
        }

        // ── Public API - primary (with EffectType) ────────────────────────────

        /// <summary>Trigger an effect by category and type at the given world position.</summary>
        public void TriggerEffect(EffectCategory category, EffectType effectType,
                                   Vector3 position, Vector3 normal ,
                                   int particleCount = -1, float audioVolume = 1f)
            => TriggerEffect((int)category, (int)effectType, position, normal, particleCount, audioVolume);

        public void TriggerEffect(int category, int effectType,
                                   Vector3 position, Vector3 normal,
                                   int particleCount = -1, float audioVolume = 1f)
        {
            if (!CanEmit((EffectCategory)category, position)) return;

            long key = MakeKey(category, effectType);
            if (!_lookup.TryGetValue(key, out var entry))
            {
                long fallback = MakeKey(category, (int)EffectType.Generic);
                if (!_lookup.TryGetValue(fallback, out entry))
                {
                    MID_Logger.LogWarning(_logLevel,
                        $"No FXEntry for category={category} type={effectType} (no Generic fallback either).",
                        nameof(GlobalFXManager));
                    return;
                }
            }

            if (entry.IsFlipbook)
            {
                EmitFlipbook(entry, position, normal);
                RecordEmission((EffectCategory)category, position);
                RequestCategoryAudio((EffectCategory)category, audioVolume);
                return;
            }

            if (entry.particleSystem == null) return;

            int count = particleCount >= 0 ? particleCount : entry.defaultParticleCount;

            _emitParams.position             = position;
            if (normal != Vector3.zero)
            {
                _emitParams.rotation3D = Quaternion.LookRotation(normal).eulerAngles;
            }
           _emitParams.applyShapeToPosition = true;
            entry.particleSystem.Emit(_emitParams, count);

            RecordEmission((EffectCategory)category, position);
            RequestCategoryAudio((EffectCategory)category, audioVolume);
        }

        /// <summary>
        /// Plays an FXEntry's flipbookFrames via a pooled MID_FlipbookEffect instead of
        /// emitting particles. Silently no-ops (with a warning) if the pool type isn't
        /// registered yet - same "not set up" handling as the rest of this manager.
        /// </summary>
        private void EmitFlipbook(FXEntry entry, Vector3 position, Vector3 normal)
        {
            if (!LocalObjectPool.HasInstance ||
                !LocalObjectPool.Instance.IsRegistered(PoolableObjectType.FlipbookEffect))
            {
                MID_Logger.LogWarning(_logLevel,
                    $"FXEntry '{entry.Name}' wants a flipbook but PoolableObjectType.FlipbookEffect " +
                    "isn't registered in LocalObjectPool.",
                    nameof(GlobalFXManager));
                return;
            }

            Quaternion rot = normal != Vector3.zero ? Quaternion.LookRotation(normal) : Quaternion.identity;
            var go = LocalObjectPool.Instance.GetObject(PoolableObjectType.FlipbookEffect, position, rot);
            if (go == null) return;

            var flipbook = go.GetComponent<MID_FlipbookEffect>();
            if (flipbook == null)
            {
                MID_Logger.LogWarning(_logLevel,
                    "Pooled FlipbookEffect object has no MID_FlipbookEffect component.",
                    nameof(GlobalFXManager));
                return;
            }

            flipbook.Play(entry.flipbookFrames, entry.flipbookFps, position, rot);
        }

        // ── Public API - with EffectType (explicit) ───────────────────────────

        /// <summary>Trigger an impact effect at a surface hit point.</summary>
        public void TriggerImpact(EffectType type, Vector3 position, Vector3 normal,
                                   int particleCount = -1, float audioVolume = 1f)
            => TriggerEffect(EffectCategory.Impact, type, position, normal, particleCount, audioVolume);

        /// <summary>Trigger a muzzle flash at a weapon barrel position.</summary>
        public void TriggerMuzzleFlash(EffectType type, Vector3 position, Vector3 direction,
                                        int particleCount = -1, float audioVolume = 0.8f)
            => TriggerEffect(EffectCategory.MuzzleFlash, type, position, direction, particleCount, audioVolume);

        /// <summary>Eject a shell casing with explicit EffectType.</summary>
        public void EjectShell(EffectType type, Vector3 position, Vector3 ejectionVelocity,
                                float audioVolume = 0.4f)
        {
            if (!CanEmit(EffectCategory.ShellEjection, position)) return;

            long key = MakeKey((int)EffectCategory.ShellEjection, (int)type);
            if (!_lookup.TryGetValue(key, out var entry)) return;
            if (entry.particleSystem == null) return;

            _emitParams.position             = position;
            _emitParams.velocity             = ejectionVelocity;
            _emitParams.applyShapeToPosition = false;
            entry.particleSystem.Emit(_emitParams, 1);

            RecordEmission(EffectCategory.ShellEjection, position);
            RequestCategoryAudio(EffectCategory.ShellEjection, audioVolume);
        }

        // ── Public API - convenience overloads (no EffectType) ───────────────

        /// <summary>
        /// Trigger a generic impact effect. Defaults to EffectType.Generic.
        /// Use TriggerImpact(EffectType, ...) for surface-specific effects.
        /// </summary>
        public void TriggerImpact(Vector3 position, Vector3 normal,
                                   int particleCount = -1, float volumeOverride = 1f)
            => TriggerImpact(EffectType.Generic, position, normal, particleCount, volumeOverride);

        /// <summary>
        /// Trigger a generic muzzle flash. Defaults to EffectType.SmallMuzzle.
        /// Use TriggerMuzzleFlash(EffectType, ...) for weapon-specific flashes.
        /// </summary>
        public void TriggerMuzzleFlash(Vector3 position, Vector3 direction,
                                        int particleCount = -1, float audioVolume = 0.8f)
            => TriggerMuzzleFlash(EffectType.SmallMuzzle, position, direction, particleCount, audioVolume);

        /// <summary>
        /// Eject a generic brass shell. Defaults to EffectType.BrassShell.
        /// </summary>
        public void EjectShell(Vector3 position, Vector3 ejectionVelocity, float audioVolume = 0.4f)
            => EjectShell(EffectType.BrassShell, position, ejectionVelocity, audioVolume);

        // ── TryGetEffect ──────────────────────────────────────────────────────

        public bool TryGetEffect(EffectCategory category, EffectType type, out ParticleSystem ps)
        {
            ps = null;
            if (!_lookup.TryGetValue(MakeKey((int)category, (int)type), out var entry)) return false;
            ps = entry.particleSystem;
            return ps != null;
        }

        // ── Private - throttling ──────────────────────────────────────────────

        private bool CanEmit(EffectCategory category, Vector3 position)
        {
            int cat = (int)category;
            int max = category switch
            {
                EffectCategory.Impact        => _maxImpactPerFrame,
                EffectCategory.MuzzleFlash   => _maxMuzzlePerFrame,
                EffectCategory.ShellEjection => _maxShellPerFrame,
                EffectCategory.Explosion     => _maxExplosionPerFrame,
                _                            => _maxOtherPerFrame
            };

            _frameCounts.TryGetValue(cat, out int currentCount);
            if (currentCount >= max) return false;

            if (category == EffectCategory.Impact || category == EffectCategory.Explosion)
            {
                float rSq = _spatialThrottleRadius * _spatialThrottleRadius;
                for (int i = 0; i < _frameEmissions.Count; i++)
                {
                    var (emittedCat, emittedPos) = _frameEmissions[i];
                    if (emittedCat == category &&
                        Vector3.SqrMagnitude(emittedPos - position) < rSq)
                        return false;
                }
            }

            return true;
        }

        private void RecordEmission(EffectCategory category, Vector3 position)
        {
            _frameEmissions.Add((category, position));
            int cat = (int)category;
            _frameCounts[cat] = (_frameCounts.TryGetValue(cat, out int c) ? c : 0) + 1;
        }

        // ── Private - audio hook ──────────────────────────────────────────────

        private static void RequestCategoryAudio(EffectCategory category, float volume)
        {
            CategoryAudioRequested?.Invoke(category, volume);
        }

        // ── Private - setup ───────────────────────────────────────────────────

        private void BuildLookup()
        {
            _lookup.Clear();
            int duplicates = 0;

            foreach (var entry in _effects)
            {
                if (entry.particleSystem == null && !entry.IsFlipbook)
                {
                    MID_Logger.LogWarning(_logLevel,
                        $"FXEntry '{entry.Name}' has neither a ParticleSystem nor flipbookFrames — skipping.",
                        nameof(GlobalFXManager));
                    continue;
                }

                long key = MakeKey((int)entry.category, (int)entry.effectType);
                if (_lookup.ContainsKey(key))
                {
                    MID_Logger.LogWarning(_logLevel,
                        $"Duplicate FXEntry for category={entry.category} type={entry.effectType}. " +
                        "First entry wins — remove the duplicate.",
                        nameof(GlobalFXManager));
                    duplicates++;
                    continue;
                }
                _lookup[key] = entry;
            }

            MID_Logger.LogInfo(_logLevel,
                $"FX lookup built — {_lookup.Count} entries" +
                (duplicates > 0 ? $", {duplicates} duplicate(s) skipped" : "") + ".",
                nameof(GlobalFXManager));
        }

        private void ValidateSystems()
        {
            foreach (var entry in _effects)
            {
                if (entry.IsFlipbook) continue; // flipbook entries have no ParticleSystem to validate
                if (entry.particleSystem == null) continue;
                var main = entry.particleSystem.main;

                if (main.simulationSpace != ParticleSystemSimulationSpace.World)
                {
                    MID_Logger.LogWarning(_logLevel,
                        $"FXEntry '{entry.Name}': ParticleSystem must use Simulation Space = World. " +
                        "Auto-correcting.",
                        nameof(GlobalFXManager));
                    main.simulationSpace = ParticleSystemSimulationSpace.World;
                }

                if (main.loop)
                {
                    MID_Logger.LogWarning(_logLevel,
                        $"FXEntry '{entry.Name}': Loop is enabled — disabling.",
                        nameof(GlobalFXManager));
                    main.loop = false;
                }
            }
        }

        // ── Utilities ─────────────────────────────────────────────────────────

        private static long MakeKey(int category, int effectType) =>
            (long)category * 100_000L + effectType;
    }
}
