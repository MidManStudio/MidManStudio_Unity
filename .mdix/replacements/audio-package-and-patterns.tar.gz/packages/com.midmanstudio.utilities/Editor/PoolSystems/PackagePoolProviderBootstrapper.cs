// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/com.midmanstudio.utilities/pool-systems.md, section "PackagePoolProviderBootstrapper.cs"
// ============================================================================
// Editor-only. Runs automatically after import via [InitializeOnLoad].
// Creates default PoolTypeProvider ScriptableObject assets for the utilities package.
#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEngine;
using MidManStudio.Core.Pools.Generator;

namespace MidManStudio.Core.EditorUtils
{
    [InitializeOnLoad]
    internal static class PackagePoolProviderBootstrapper
    {
        private const string UtilitiesDir = "Assets/MidManStudio/Utilities/PoolProviders";

        static PackagePoolProviderBootstrapper()
        {
            EditorApplication.delayCall += Bootstrap;
        }

        [MenuItem("MidManStudio/Utilities/Internal/Recreate Default Pool Providers")]
        public static void Bootstrap()
        {
            bool changed = false;
            changed |= EnsureUtilitiesObjectProvider();
            changed |= EnsureUtilitiesParticleProvider();

            if (changed)
            {
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
                Debug.Log("[PoolProviderBootstrapper] Default provider assets created.");
            }
        }

        // ── Provider assets ───────────────────────────────────────────────────

        private static bool EnsureUtilitiesObjectProvider()
        {
            const string path = UtilitiesDir + "/ObjectPoolTypeProvider_Utilities.asset";
            if (File.Exists(path)) return false;

            EnsureDir(UtilitiesDir);
            var so = ScriptableObject.CreateInstance<ObjectPoolTypeProviderSO>();
            so.packageId   = "com.midmanstudio.utilities";
            so.displayName = "MidMan Studio Utilities";
            so.priority    = 0;
            so.entries.Add(new PoolEntryDefinition
            {
                entryName      = "Trail",
                comment        = "Pooled trail renderer object",
                explicitOffset = 1
            });
            so.entries.Add(new PoolEntryDefinition
            {
                entryName      = "FlipbookEffect",
                comment        = "Pooled sprite-sheet flipbook effect (GlobalFXManager)",
                explicitOffset = 2
            });

            AssetDatabase.CreateAsset(so, path);
            return true;
        }

        private static bool EnsureUtilitiesParticleProvider()
        {
            const string path = UtilitiesDir + "/ParticlePoolTypeProvider_Utilities.asset";
            if (File.Exists(path)) return false;

            EnsureDir(UtilitiesDir);
            var so = ScriptableObject.CreateInstance<ParticlePoolTypeProviderSO>();
            so.packageId   = "com.midmanstudio.utilities";
            so.displayName = "MidMan Studio Utilities";
            so.priority    = 0;
            // Utilities defines no particle types by default

            AssetDatabase.CreateAsset(so, path);
            return true;
        }

        private static void EnsureDir(string dir)
        {
            if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
        }
    }
}
#endif
