# com.midmanstudio.audio
**MidMan Studio Audio** v1.0.0. Audio for Unity 2022.3+: music with crossfade, SFX playback, a pooled-voice clip
player, pooled spatial audio objects, a peak limiter for the final mix, and a relay for `GlobalFXManager` effects.

This package was split out of `com.midmanstudio.utilities`. The namespace is still `MidManStudio.Core.Audio`.

## Requirements
| Dependency | Version |
|---|---|
| Unity | 2022.3 LTS |
| com.midmanstudio.utilities | 1.0.0 |

## Installation
**Via git URL** (Unity Package Manager, Add package from git URL):
https://github.com/MidManStudio/MidManStudio_Unity.git?path=/packages/com.midmanstudio.audio

**Via local file path** (development, manifest.json):
"com.midmanstudio.audio": "file:../../packages/com.midmanstudio.audio"

Utilities is installed alongside it. Code that already used `MidManStudio.Core.Audio` needs a reference to the
`MidManStudio.Audio` assembly (automatic when the assembly is auto-referenced, which it is by default).

## What's Included
| Type | Description |
|---|---|
| `MID_AudioManager` | Music with crossfade, pause/resume, pitch glide and an enabled flag, plus SFX playback by id, mixer group routing |
| `MID_AudioLibrarySO` | ScriptableObject mapping string ids to clips and volumes |
| `MID_NativeAudioBridge` | Pool of AudioSources (4 to 32, default 16) that plays clips by index, stealing the oldest voice when full |
| `MID_AudioLimiter` | Peak limiter for the final mix. Rust DSP on desktop and mobile, C# fallback on WebGL. Goes on the AudioListener GameObject |
| `MID_SpawnableAudio` | Pooled audio object: one-shot, looping with follow, and flight then collision playback |
| `MID_FXAudioRelay` | Plays bridge clips for `GlobalFXManager` effects |

## Setup
1. Add `MID_NativeAudioBridge` to your Managers prefab and fill its clip array.
2. Add `MID_AudioLimiter` to the GameObject that has the AudioListener.
3. For music and named SFX, create libraries with `Create > MidManStudio > Audio > Audio Library`, assign them to
   `MID_AudioManager`, then call `PlayMusic("id")` and `PlaySFX("id")`.
4. For effect audio, add `MID_FXAudioRelay` to an active GameObject and set the clip index per category.
5. For `MID_SpawnableAudio`, run `MidManStudio > Utilities > Pool Type Generator` once so the `SpawnableAudio`
   pool type exists, then register the prefab in the `LocalObjectPool` inspector.

## Native library
The limiter uses the `mid_audio` Rust crate (`rust_lib/mid_audio`). Prebuilt libraries are committed in
`Runtime/Plugins/Native/Audio` and rebuilt by `.github/workflows/build-audio-libs.yml`. Run that workflow by hand
after a crate change, because the workflow's own commit carries `[skip ci]`.

## Benchmarks
`MidManStudio > Audio > Tests > Audio Bench` opens the in-editor benchmark window.

See `APICATALOG.md` for the API and `docs/com.midmanstudio.audio.md` for the design notes.

## License
MIT, see LICENSE.md.
