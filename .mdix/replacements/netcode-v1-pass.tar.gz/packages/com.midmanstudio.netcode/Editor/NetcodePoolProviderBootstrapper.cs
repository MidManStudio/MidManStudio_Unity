// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/com.midmanstudio.netcode.md, section "NetcodePoolProviderBootstrapper.cs"
// ============================================================================

#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEngine;
using MidManStudio.Netcode.Generator;

namespace MidManStudio.Netcode.Editor
{
    /// <summary>
    /// Creates the default NetworkPoolTypeProvider asset for the netcode package
    /// on first import.
    /// </summary>
    [InitializeOnLoad]
    internal static class NetcodePoolProviderBootstrapper
    {
        private const string NetcodeDir =
            "Assets/MidManStudio/Netcode/PoolProviders";

        static NetcodePoolProviderBootstrapper()
        {
            EditorApplication.delayCall += EnsureProviders;
        }

        [MenuItem("MidManStudio/Netcode/Internal/Recreate Netcode Pool Providers", priority = 100)]
        public static void EnsureProviders()
        {
            bool changed = EnsureNetcodeNetworkProvider();
            if (changed)
            {
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
                Debug.Log("[NetcodePoolProviderBootstrapper] Netcode providers created.");
            }
        }

        private static bool EnsureNetcodeNetworkProvider()
        {
            const string path =
                NetcodeDir + "/NetworkPoolTypeProvider_Netcode.asset";
            if (File.Exists(path)) return false;

            EnsureDirectory(NetcodeDir);
            var so = ScriptableObject.CreateInstance<NetworkPoolTypeProviderSO>();
            so.packageId   = "com.midmanstudio.netcode";
            so.displayName = "MidMan Studio Netcode";
            so.priority    = 0;
            // The netcode package defines no network pool entries by default.
            // Game code adds entries via their own NetworkPoolTypeProviderSO.

            AssetDatabase.CreateAsset(so, path);
            return true;
        }

        private static void EnsureDirectory(string dir)
        {
            if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
        }
    }
}
#endif
