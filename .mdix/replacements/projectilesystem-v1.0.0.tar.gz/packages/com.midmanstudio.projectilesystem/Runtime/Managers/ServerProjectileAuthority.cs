// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/com.midmanstudio.projectilesystem.md, section "ServerProjectileAuthority.cs"
// ============================================================================
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using Unity.Netcode;
using MidManStudio.Core.HelperFunctions;
using MidManStudio.Projectiles.Core;
using MidManStudio.Projectiles.Config;
using MidManStudio.Projectiles.Adapters;
using MidManStudio.Projectiles.Data;
using MidManStudio.Projectiles.Visuals;
using MidManStudio.Projectiles.Network;

namespace MidManStudio.Projectiles.Managers
{
    /// <summary>
    /// Position snapshot of one 2D projectile, sent to clients for reconciliation
    /// (LocalProjectileManager.ReconcileSnapshots2D). X and Y serialize as
    /// half-precision floats (2 bytes each instead of 4) through
    /// Mathf.FloatToHalf/HalfToFloat. The public fields stay plain floats, so
    /// only NetworkSerialize knows about the compression. ProjId and ServerTick
    /// stay full size: ProjId needs exact equality for buffer matching, and
    /// ServerTick needs its full range for long sessions at high tick rates.
    ///
    /// Precision: a half-precision value is off by at most half the spacing
    /// between neighbouring half values, which is about 0.0005 per unit of
    /// magnitude. That is 0.03 units for coordinates between 64 and 128, 0.06
    /// between 128 and 256, and 0.125 between 256 and 512. The client skips a
    /// correction when the error is under ReconcileSnapshots2D's kSkip (0.08), so
    /// beyond roughly 256 units from the origin the quantisation error alone
    /// can exceed that band and trigger corrections.
    /// </summary>
    public struct ProjectileSnapshot2D : INetworkSerializable
    {
        public uint  ProjId;
        public float X;
        public float Y;
        public int   ServerTick;

        public void NetworkSerialize<T>(BufferSerializer<T> s) where T : IReaderWriter
        {
            s.SerializeValue(ref ProjId);

            if (s.IsWriter)
            {
                ushort hx = Mathf.FloatToHalf(X);
                ushort hy = Mathf.FloatToHalf(Y);
                s.SerializeValue(ref hx);
                s.SerializeValue(ref hy);
            }
            else
            {
                ushort hx = 0, hy = 0;
                s.SerializeValue(ref hx);
                s.SerializeValue(ref hy);
                X = Mathf.HalfToFloat(hx);
                Y = Mathf.HalfToFloat(hy);
            }

            s.SerializeValue(ref ServerTick);
        }
    }

    /// <summary>Same half-precision treatment as ProjectileSnapshot2D — see its doc comment.</summary>
    public struct ProjectileSnapshot3D : INetworkSerializable
    {
        public uint  ProjId;
        public float X;
        public float Y;
        public float Z;
        public int   ServerTick;

        public void NetworkSerialize<T>(BufferSerializer<T> s) where T : IReaderWriter
        {
            s.SerializeValue(ref ProjId);

            if (s.IsWriter)
            {
                ushort hx = Mathf.FloatToHalf(X);
                ushort hy = Mathf.FloatToHalf(Y);
                ushort hz = Mathf.FloatToHalf(Z);
                s.SerializeValue(ref hx);
                s.SerializeValue(ref hy);
                s.SerializeValue(ref hz);
            }
            else
            {
                ushort hx = 0, hy = 0, hz = 0;
                s.SerializeValue(ref hx);
                s.SerializeValue(ref hy);
                s.SerializeValue(ref hz);
                X = Mathf.HalfToFloat(hx);
                Y = Mathf.HalfToFloat(hy);
                Z = Mathf.HalfToFloat(hz);
            }

            s.SerializeValue(ref ServerTick);
        }
    }

    public class ServerProjectileAuthority : MonoBehaviour
    {
        #region Configuration

        [Header("Buffer Capacity")]
        [SerializeField] private int _maxProjectiles2D = 2048;
        [SerializeField] private int _maxProjectiles3D = 512;
        [SerializeField] private int _maxTargets2D     = 128;
        [SerializeField] private int _maxTargets3D     = 64;
        [Tooltip("Box/Capsule/Edge/Polygon shape colliders — a separate, smaller " +
                 "buffer from the circle/sphere targets above (see ShapeCollider2D/3D's " +
                 "doc comment). Expected to be tens, not hundreds — mostly static level " +
                 "geometry, not per-enemy hurtboxes.")]
        [SerializeField] private int _maxShapes2D      = 64;
        [SerializeField] private int _maxShapes3D      = 32;
        [SerializeField] private int _maxHitsPerTick   = 256;

        [Header("Collision Tuning")]
        [SerializeField] private float _cellSize2D = 4f;
        [SerializeField] private float _cellSize3D = 4f;

        [Header("Snapshot")]
        [SerializeField] private int _snapshotIntervalTicks = 4;

        [Header("Distance Culling (opt-in — off changes nothing)")]
        [Tooltip("When off (default), snapshots broadcast to every client exactly as " +
                 "before this existed. When on, each client only receives snapshots for " +
                 "projectiles within Cull Vis Range of their own observer position (via " +
                 "ObserverProvider) — clients with no registered/resolvable observer " +
                 "position still get everything, unfiltered, as a safe fallback.")]
        [SerializeField] private bool  _enableDistanceCulling = false;
        public bool EnableDistanceCulling => _enableDistanceCulling;

        [Tooltip("Radius around a client's observer position within which projectile " +
                 "snapshots are sent to them. Same units as your world (2D or 3D).")]
        [SerializeField] private float _cullVisRange = 60f;
        public float CullVisRange => _cullVisRange;

        [Header("Rendering (Host / Offline)")]
        [Tooltip("Assign the scene ProjectileRenderer2D here.\n" +
                 "In host mode this renders the server-side Rust buffer.\n" +
                 "Leave null on dedicated server (headless — no rendering).")]
        [SerializeField] private ProjectileRenderer2D _renderer2D;

        [Tooltip("Assign the scene ProjectileRenderer3D here.")]
        [SerializeField] private ProjectileRenderer3D _renderer3D;

        [Header("Debug")]
        [SerializeField] private bool _enableLogs = false;

        #endregion

        #region Owned References

        public RustSimAdapter              Adapter       { get; private set; }
        public TrailObjectPool             TrailPool     { get; set; }

        /// <summary>
        /// Optional. Implement IProjectileObserverProvider in your game code and
        /// assign it here (e.g. from your session/lobby manager's Start()) to
        /// enable distance culling — see IProjectileObserverProvider's doc
        /// comment. Left null (default), _enableDistanceCulling has no effect
        /// even if turned on in the inspector; both must be set for culling to
        /// actually engage, and either one being unset/off is a fully safe,
        /// unfiltered fallback.
        /// </summary>
        public IProjectileObserverProvider ObserverProvider { get; set; }
        public MID_ProjectileNetworkBridge NetworkBridge { get; set; }

        #endregion

        #region 2D Sim Buffer

        private NativeProjectile[]  _projs2D;
        private CollisionTarget[]   _targets2D;
        private ShapeCollider2D[]   _shapes2D;
        private HitResult[]         _hits2D;
        private int                 _count2D;
        private int                 _targetCount2D;
        private int                 _shapeCount2D;
        private uint                _nextProjId = 1;

        private GCHandle _pinProjs2D;
        private GCHandle _pinTargets2D;
        private GCHandle _pinShapes2D;
        private GCHandle _pinHits2D;

        #endregion

        #region 3D Sim Buffer

        private NativeProjectile3D[] _projs3D;
        private CollisionTarget3D[]  _targets3D;
        private ShapeCollider3D[]    _shapes3D;
        private HitResult3D[]        _hits3D;
        private int                  _count3D;
        private int                  _targetCount3D;
        private int                  _shapeCount3D;

        private GCHandle _pinProjs3D;
        private GCHandle _pinTargets3D;
        private GCHandle _pinShapes3D;
        private GCHandle _pinHits3D;

        #endregion

        #region Layer Tracking

        private readonly Dictionary<uint, int> _targetLayerDict2D = new(64);
        private readonly Dictionary<uint, int> _targetLayerDict3D = new(64);

        #endregion

        #region Piercing — Permanent Per-Projectile Target Immunity

        private readonly Dictionary<uint, HashSet<uint>> _hitTargets2D = new(128);
        private readonly Dictionary<uint, HashSet<uint>> _hitTargets3D = new(128);

        private static readonly Stack<HashSet<uint>> _setPool = new(32);

        private static HashSet<uint> RentSet()
            => _setPool.Count > 0 ? _setPool.Pop() : new HashSet<uint>(4);

        private static void ReturnSet(HashSet<uint> s) { s.Clear(); _setPool.Push(s); }

        private bool AlreadyHit2D(uint projId, uint targetId)
        {
            if (!_hitTargets2D.TryGetValue(projId, out var set)) return false;
            return set.Contains(targetId);
        }

        private bool AlreadyHit3D(uint projId, uint targetId)
        {
            if (!_hitTargets3D.TryGetValue(projId, out var set)) return false;
            return set.Contains(targetId);
        }

        private void RecordHit2D(uint projId, uint targetId)
        {
            if (!_hitTargets2D.TryGetValue(projId, out var set))
            {
                set = RentSet();
                _hitTargets2D[projId] = set;
            }
            set.Add(targetId);
        }

        private void RecordHit3D(uint projId, uint targetId)
        {
            if (!_hitTargets3D.TryGetValue(projId, out var set))
            {
                set = RentSet();
                _hitTargets3D[projId] = set;
            }
            set.Add(targetId);
        }

        private void ClearHitRecord2D(uint projId)
        {
            if (_hitTargets2D.TryGetValue(projId, out var set))
            {
                ReturnSet(set);
                _hitTargets2D.Remove(projId);
            }
        }

        private void ClearHitRecord3D(uint projId)
        {
            if (_hitTargets3D.TryGetValue(projId, out var set))
            {
                ReturnSet(set);
                _hitTargets3D.Remove(projId);
            }
        }

        #endregion

        #region Snapshot Staging

        private ProjectileSnapshot2D[] _snapshots2D;
        private ProjectileSnapshot3D[] _snapshots3D;
        private int _fixedUpdateCounter;

        // Reused across every client, every tick, when distance culling is on —
        // refilled in place per client, never reallocated. Same max size as the
        // combined arrays above since a single client's filtered set can never
        // exceed the full candidate set.
        private ProjectileSnapshot2D[] _cullScratch2D;
        private ProjectileSnapshot3D[] _cullScratch3D;

        // Cached byte values for movement type filter in SendSnapshots —
        // avoids repeated enum casts inside the hot loop.
        private static readonly byte _movWave     = (byte)ProjectileMovementType.Wave;
        private static readonly byte _movCircular = (byte)ProjectileMovementType.Circular;

        #endregion

        #region Public API — Counts

        public int ActiveCount2D    => _count2D;
        public int ActiveCount3D    => _count3D;
        public int TargetCount2D    => _targetCount2D;
        public int TargetCount3D    => _targetCount3D;
        public int ShapeCount2D     => _shapeCount2D;
        public int ShapeCount3D     => _shapeCount3D;
        public int MaxProjectiles2D => _maxProjectiles2D;
        public int MaxProjectiles3D => _maxProjectiles3D;

        #endregion

        #region Initialisation

        private void Awake()
        {
            _spawnQueuedCb = OnQueuedPellet;
            Adapter = new RustSimAdapter();
            Adapter.OnProjectileDied += OnAdapterProjectileDied;
            AllocateBuffers();
            BatchSpawnHelper.Initialise();
            Log("ServerProjectileAuthority initialised.");
        }

        private void OnDestroy()
        {
            BatchSpawnHelper.Shutdown();
            FreeBuffers();
            ProjectileLib.clear_movement_params();
        }

        private void AllocateBuffers()
        {
            _projs2D   = new NativeProjectile[_maxProjectiles2D];
            _targets2D = new CollisionTarget[_maxTargets2D];
            _shapes2D  = new ShapeCollider2D[_maxShapes2D];
            _hits2D    = new HitResult[_maxHitsPerTick];
            _pinProjs2D   = GCHandle.Alloc(_projs2D,   GCHandleType.Pinned);
            _pinTargets2D = GCHandle.Alloc(_targets2D, GCHandleType.Pinned);
            _pinShapes2D  = GCHandle.Alloc(_shapes2D,  GCHandleType.Pinned);
            _pinHits2D    = GCHandle.Alloc(_hits2D,    GCHandleType.Pinned);

            _projs3D   = new NativeProjectile3D[_maxProjectiles3D];
            _targets3D = new CollisionTarget3D[_maxTargets3D];
            _shapes3D  = new ShapeCollider3D[_maxShapes3D];
            _hits3D    = new HitResult3D[_maxHitsPerTick];
            _pinProjs3D   = GCHandle.Alloc(_projs3D,   GCHandleType.Pinned);
            _pinTargets3D = GCHandle.Alloc(_targets3D, GCHandleType.Pinned);
            _pinShapes3D  = GCHandle.Alloc(_shapes3D,  GCHandleType.Pinned);
            _pinHits3D    = GCHandle.Alloc(_hits3D,    GCHandleType.Pinned);

            _snapshots2D = new ProjectileSnapshot2D[_maxProjectiles2D];
            _snapshots3D = new ProjectileSnapshot3D[_maxProjectiles3D];

            _cullScratch2D = new ProjectileSnapshot2D[_maxProjectiles2D];
            _cullScratch3D = new ProjectileSnapshot3D[_maxProjectiles3D];
        }

        private void FreeBuffers()
        {
            if (_pinProjs2D.IsAllocated)   _pinProjs2D.Free();
            if (_pinTargets2D.IsAllocated) _pinTargets2D.Free();
            if (_pinShapes2D.IsAllocated)  _pinShapes2D.Free();
            if (_pinHits2D.IsAllocated)    _pinHits2D.Free();
            if (_pinProjs3D.IsAllocated)   _pinProjs3D.Free();
            if (_pinTargets3D.IsAllocated) _pinTargets3D.Free();
            if (_pinShapes3D.IsAllocated)  _pinShapes3D.Free();
            if (_pinHits3D.IsAllocated)    _pinHits3D.Free();
        }

        #endregion

        #region LateUpdate — Render Server Buffers (Host / Offline)

        private void LateUpdate()
        {
            if (!IsServer()) return;
            _renderer2D?.Render(_projs2D, _count2D);
            _renderer3D?.Render(_projs3D, _count3D);
        }

        #endregion

        #region FixedUpdate — Main Sim Loop

        private void FixedUpdate()
        {
            if (!IsServer()) return;

            float dt = Time.fixedDeltaTime;
            _fixedUpdateCounter++;

            _delayed.Advance(dt, _spawnQueuedCb);

            if (_count2D > 0)
            {
                Tick2D(dt);
                Collision2D();
                TrailPool?.SyncToSimulation(_projs2D, _count2D);
                CompactDead2D();
            }

            if (_count3D > 0)
            {
                Tick3D(dt);
                Collision3D();
                TrailPool?.SyncToSimulation3D(_projs3D, _count3D);
                CompactDead3D();
            }

            if (_fixedUpdateCounter % _snapshotIntervalTicks == 0)
                SendSnapshots();
        }

        private void Tick2D(float dt)
            => ProjectileLib.tick_projectiles(_pinProjs2D.AddrOfPinnedObject(), _count2D, dt);

        private void Collision2D()
        {
            if (_targetCount2D == 0 && _shapeCount2D == 0) return;

            int hitCount = 0;

            if (_targetCount2D > 0)
            {
                ProjectileLib.check_hits_grid_ex(
                    _pinProjs2D.AddrOfPinnedObject(),   _count2D,
                    _pinTargets2D.AddrOfPinnedObject(), _targetCount2D,
                    _pinHits2D.AddrOfPinnedObject(),    _hits2D.Length,
                    _cellSize2D,
                    out hitCount);
            }

            // SHAPE COLLIDERS: additive pass, appends into the SAME _hits2D
            // buffer starting at hitCount — see ShapeCollider2D's doc comment.
            // Everything below (headshot check, ProcessHit, piercing dedup)
            // is completely unmodified: shape hits flow through the exact
            // same pipeline as circle hits, keyed off the same TargetId.
            if (_shapeCount2D > 0)
            {
                hitCount = ProjectileLib.check_hits_shapes_2d(
                    _pinProjs2D.AddrOfPinnedObject(),  _count2D,
                    _pinShapes2D.AddrOfPinnedObject(), _shapeCount2D,
                    _pinHits2D.AddrOfPinnedObject(),   _hits2D.Length,
                    hitCount);
            }

            for (int i = 0; i < hitCount; i++)
            {
                ref var h   = ref _hits2D[i];
                int     idx = (int)h.ProjIndex;
                if (idx < 0 || idx >= _count2D) continue;

                if (AlreadyHit2D(h.ProjId, h.TargetId)) continue;
                if (!PassesLayerFilter2D(h.ProjId, h.TargetId)) continue;

                bool headshot = CheckHeadshot2D(in h);
                Adapter.ProcessHit(in h, headshot);

                RecordHit2D(h.ProjId, h.TargetId);

                if (!Adapter.IsRegistered(h.ProjId))
                {
                    if (idx < _count2D) _projs2D[idx].Alive = 0;
                }
            }
        }

        private void CompactDead2D()
        {
            int write = 0;
            for (int read = 0; read < _count2D; read++)
            {
                if (_projs2D[read].Alive == 0)
                {
                    uint deadId = _projs2D[read].ProjId;
                    Adapter.NotifyDead(deadId);
                    TrailPool?.NotifyDead(deadId);
                    ClearHitRecord2D(deadId);
                    continue;
                }
                if (write != read) _projs2D[write] = _projs2D[read];
                write++;
            }
            _count2D = write;
        }

        private void Tick3D(float dt)
            => ProjectileLib.tick_projectiles_3d(_pinProjs3D.AddrOfPinnedObject(), _count3D, dt);

        private void Collision3D()
        {
            if (_targetCount3D == 0 && _shapeCount3D == 0) return;

            int hitCount = 0;

            if (_targetCount3D > 0)
            {
                ProjectileLib.check_hits_grid_3d(
                    _pinProjs3D.AddrOfPinnedObject(),   _count3D,
                    _pinTargets3D.AddrOfPinnedObject(), _targetCount3D,
                    _pinHits3D.AddrOfPinnedObject(),    _hits3D.Length,
                    _cellSize3D,
                    out hitCount);
            }

            if (_shapeCount3D > 0)
            {
                hitCount = ProjectileLib.check_hits_shapes_3d(
                    _pinProjs3D.AddrOfPinnedObject(),  _count3D,
                    _pinShapes3D.AddrOfPinnedObject(), _shapeCount3D,
                    _pinHits3D.AddrOfPinnedObject(),   _hits3D.Length,
                    hitCount);
            }

            for (int i = 0; i < hitCount; i++)
            {
                ref var h   = ref _hits3D[i];
                int     idx = (int)h.ProjIndex;
                if (idx < 0 || idx >= _count3D) continue;

                if (AlreadyHit3D(h.ProjId, h.TargetId)) continue;
                if (!PassesLayerFilter3D(h.ProjId, h.TargetId)) continue;

                bool headshot = CheckHeadshot3D(in h);
                Adapter.ProcessHit3D(in h, headshot);

                RecordHit3D(h.ProjId, h.TargetId);

                if (!Adapter.IsRegistered(h.ProjId))
                {
                    if (idx < _count3D) _projs3D[idx].Alive = 0;
                }
            }
        }

        private void CompactDead3D()
        {
            int write = 0;
            for (int read = 0; read < _count3D; read++)
            {
                if (_projs3D[read].Alive == 0)
                {
                    uint deadId = _projs3D[read].ProjId;
                    Adapter.NotifyDead(deadId);
                    TrailPool?.NotifyDead(deadId);
                    ClearHitRecord3D(deadId);
                    continue;
                }
                if (write != read) _projs3D[write] = _projs3D[read];
                write++;
            }
            _count3D = write;
        }

        #endregion

        #region Layer Filter Helpers

        private bool PassesLayerFilter2D(uint projId, uint targetId)
        {
            if (!_targetLayerDict2D.TryGetValue(targetId, out int layer)) return true;
            if (!Adapter.IsRegistered(projId)) return true;
            ushort configId = GetConfigId2D(projId);
            return PassesLayerMask(configId, layer);
        }

        private bool PassesLayerFilter3D(uint projId, uint targetId)
        {
            if (!_targetLayerDict3D.TryGetValue(targetId, out int layer)) return true;
            ushort configId = GetConfigId3D(projId);
            return PassesLayerMask(configId, layer);
        }

        private ushort GetConfigId2D(uint projId)
        {
            for (int i = 0; i < _count2D; i++)
                if (_projs2D[i].ProjId == projId) return _projs2D[i].ConfigId;
            return 0;
        }

        private ushort GetConfigId3D(uint projId)
        {
            for (int i = 0; i < _count3D; i++)
                if (_projs3D[i].ProjId == projId) return _projs3D[i].ConfigId;
            return 0;
        }

        private static bool PassesLayerMask(ushort configId, int targetLayer)
        {
            var cfg = ProjectileRegistry.Instance?.Get(configId);
            if (cfg == null) return true;
            int mask = cfg.HitLayers.value;
            if (mask == -1) return true;
            return (mask & (1 << targetLayer)) != 0;
        }

        #endregion

        #region Snapshot

        /// <summary>
        /// Sends position snapshots for active projectiles to clients for
        /// linear-prediction reconciliation.
        ///
        /// Wave and Circular projectiles are left out of the snapshot payload. The
        /// client's own native sim reproduces them from the same parameters, and
        /// ReconcileSnapshots2D/3D extrapolates linearly, which does not describe
        /// those movement types, so sending them would only cost bandwidth (they
        /// contributed to the UTP "Receive queue is full" warning at high fire
        /// rates).
        ///
        /// DISTANCE CULLING (opt-in, see _enableDistanceCulling / ObserverProvider):
        /// off by default and behaves exactly as before — one combined array,
        /// one broadcast to everyone. Turned on, the same candidate pool gets
        /// filtered per connected client (distance from their observer position,
        /// plus excluding projectiles that client owns — matches
        /// LocalProjectileManager's own client-side ownership exemption, just
        /// applied at the source instead of discarded on arrival) and sent as N
        /// separate targeted RPCs instead of one broadcast. Clients with no
        /// resolvable observer position fall back to the full unfiltered set —
        /// never silently starved of data just because their position isn't
        /// known yet.
        /// </summary>
        private void SendSnapshots()
        {
            if (NetworkBridge == null) return;

            int serverTick  = NetworkBridge.GetServerTick();
            int snap2DCount = 0;
            int snap3DCount = 0;

            for (int i = 0; i < _count2D; i++)
            {
                if (_projs2D[i].Alive == 0) continue;

                // Skip Wave and Circular: clients reproduce them from the same
                // parameters, and the linear reconciliation does not fit them.
                byte mt = _projs2D[i].MovementType;
                if (mt == _movWave || mt == _movCircular) continue;

                _snapshots2D[snap2DCount++] = new ProjectileSnapshot2D
                {
                    ProjId = _projs2D[i].ProjId, X = _projs2D[i].X,
                    Y = _projs2D[i].Y, ServerTick = serverTick
                };
            }

            for (int i = 0; i < _count3D; i++)
            {
                if (_projs3D[i].Alive == 0) continue;

                byte mt = _projs3D[i].MovementType;
                if (mt == _movWave || mt == _movCircular) continue;

                _snapshots3D[snap3DCount++] = new ProjectileSnapshot3D
                {
                    ProjId = _projs3D[i].ProjId, X = _projs3D[i].X,
                    Y = _projs3D[i].Y, Z = _projs3D[i].Z, ServerTick = serverTick
                };
            }

            if (snap2DCount == 0 && snap3DCount == 0) return;

            if (!_enableDistanceCulling || ObserverProvider == null || NetworkManager.Singleton == null)
            {
                SendSnapshotChunked(_snapshots2D, snap2DCount, _snapshots3D, snap3DCount, default);
                return;
            }

            SendSnapshotsCulled(snap2DCount, snap3DCount);
        }

        private void SendSnapshotsCulled(int snap2DCount, int snap3DCount)
        {
            float rangeSq = _cullVisRange * _cullVisRange;

            foreach (ulong clientId in NetworkManager.Singleton.ConnectedClientsIds)
            {
                bool hasObserver = ObserverProvider.TryGetObserverPosition(clientId, out Vector3 observerPos);

                var targetParams = new ClientRpcParams
                {
                    Send = new ClientRpcSendParams { TargetClientIds = new[] { clientId } }
                };

                // No resolvable position for this client — safest fallback is
                // "send everything," never "send nothing." Same candidate set,
                // just re-targeted to this one client instead of a broadcast —
                // still goes through the chunked sender, same as everyone else.
                if (!hasObserver)
                {
                    SendSnapshotChunked(_snapshots2D, snap2DCount, _snapshots3D, snap3DCount, targetParams);
                    continue;
                }

                int filtered2D = 0;
                for (int i = 0; i < snap2DCount; i++)
                {
                    ref readonly var snap = ref _snapshots2D[i];
                    if (IsOwnedBy(snap.ProjId, clientId)) continue;

                    float dx = snap.X - observerPos.x;
                    float dy = snap.Y - observerPos.y;
                    if (dx * dx + dy * dy > rangeSq) continue;

                    _cullScratch2D[filtered2D++] = snap;
                }

                int filtered3D = 0;
                for (int i = 0; i < snap3DCount; i++)
                {
                    ref readonly var snap = ref _snapshots3D[i];
                    if (IsOwnedBy(snap.ProjId, clientId)) continue;

                    float dx = snap.X - observerPos.x;
                    float dy = snap.Y - observerPos.y;
                    float dz = snap.Z - observerPos.z;
                    if (dx * dx + dy * dy + dz * dz > rangeSq) continue;

                    _cullScratch3D[filtered3D++] = snap;
                }

                if (filtered2D == 0 && filtered3D == 0) continue;

                SendSnapshotChunked(_cullScratch2D, filtered2D, _cullScratch3D, filtered3D, targetParams);
            }
        }

        // ── Chunked sender ──────────────────────────────────────────────────────
        //
        // NGO serializes a T[] RPC parameter by its real .Length. The snapshot and
        // culling arrays (_snapshots2D, _cullScratch2D and the 3D ones) are
        // pre-allocated at full capacity (_maxProjectiles2D = 2048) and reused in
        // place to avoid GC pressure, so passing one straight to an RPC would
        // serialize every slot (about 24.5 KB for 2D alone), not only the live
        // ones. Reliable delivery fragments that silently, while unreliable
        // delivery has no fragmentation and hits the size ceiling at once.
        //
        // Two things are done here. Every chunk handed to the RPC is resized to
        // exactly the entries it holds (_chunk2D and _chunk3D reallocate only when
        // the requested size changes, so a steady stream of same-sized chunks
        // costs nothing extra). And each chunk is capped to a conservative byte
        // budget, so even a large legitimate snapshot (for example 150
        // projectiles in one tick) stays under NGO's unreliable ceiling and
        // becomes 2 or 3 RPC calls instead of one. Losing one chunk to a dropped
        // unreliable packet costs that slice of projectiles one update, corrected
        // on the next tick.

        private const int kSafeUnreliablePayloadBytes = 900; // conservative; real ceiling is MTU-bound, ~1200
        private const int kFixedRpcOverheadBytes       = 48;  // two counts + two length-prefixes + rpc header headroom
        private const int kEntry2DBytes = 12; // ProjId(4) + halfX(2) + halfY(2) + ServerTick(4) — see WireCompression.cs
        private const int kEntry3DBytes = 14; // + halfZ(2)

        private ProjectileSnapshot2D[] _chunk2D = new ProjectileSnapshot2D[0];
        private ProjectileSnapshot3D[] _chunk3D = new ProjectileSnapshot3D[0];

        private void SendSnapshotChunked(
            ProjectileSnapshot2D[] src2D, int count2D,
            ProjectileSnapshot3D[] src3D, int count3D,
            ClientRpcParams targetParams)
        {
            int i2 = 0, i3 = 0;

            while (i2 < count2D || i3 < count3D)
            {
                int budget = kSafeUnreliablePayloadBytes - kFixedRpcOverheadBytes;
                int n2 = 0, n3 = 0;

                while (i2 + n2 < count2D && budget >= kEntry2DBytes)
                {
                    n2++;
                    budget -= kEntry2DBytes;
                }
                while (i3 + n3 < count3D && budget >= kEntry3DBytes)
                {
                    n3++;
                    budget -= kEntry3DBytes;
                }

                // Guard against a pathological zero-progress case (shouldn't be
                // reachable at these entry sizes vs. budget, but never loop forever).
                if (n2 == 0 && n3 == 0)
                {
                    if (i2 < count2D) n2 = 1;
                    else if (i3 < count3D) n3 = 1;
                    else break;
                }

                if (_chunk2D.Length != n2) System.Array.Resize(ref _chunk2D, n2);
                if (_chunk3D.Length != n3) System.Array.Resize(ref _chunk3D, n3);

                if (n2 > 0) System.Array.Copy(src2D, i2, _chunk2D, 0, n2);
                if (n3 > 0) System.Array.Copy(src3D, i3, _chunk3D, 0, n3);

                NetworkBridge.SendSnapshotClientRpc(_chunk2D, n2, _chunk3D, n3, targetParams);

                i2 += n2;
                i3 += n3;
            }
        }

        /// <summary>True if the given client id is this projectile's owner — see ServerProjectileData.ownerClientId.</summary>
        private bool IsOwnedBy(uint projId, ulong clientId)
            => Adapter.TryGetData(projId, out var data) && data.ownerClientId == clientId;

        #endregion

        #region Public API — Spawn

        public bool AddProjectile2D(in NativeProjectile proj, ServerProjectileData data)
        {
            if (_count2D >= _maxProjectiles2D) { LogWarning("2D buffer full."); return false; }
            _projs2D[_count2D] = proj;
            data.projectileId_u32 = proj.ProjId;
            data.configId         = proj.ConfigId;
            _count2D++;
            Adapter.Register(data);
            return true;
        }

        public bool AddProjectile3D(in NativeProjectile3D proj, ServerProjectileData data)
        {
            if (_count3D >= _maxProjectiles3D) { LogWarning("3D buffer full."); return false; }
            _projs3D[_count3D] = proj;
            data.projectileId_u32 = proj.ProjId;
            data.configId         = proj.ConfigId;
            data.is3D             = true;
            _count3D++;
            Adapter.Register(data);
            return true;
        }

        // ── Burst timing ──────────────────────────────────────────────────────

        private readonly DelayedSpawnQueue _delayed = new DelayedSpawnQueue();
        private Action<DelayedSpawnQueue.Entry> _spawnQueuedCb;
        private readonly SpawnPoint[] _singlePoint = new SpawnPoint[1];

        private sealed class StaggeredShotContext
        {
            public ServerProjectileData Template;
            public Transform            GuidedTarget;
        }

        /// <summary>
        /// Spawns a shot whose projectiles do not all start together. Projectiles
        /// with no remaining delay are written now, the rest wait in a queue and
        /// are written when their time comes. Ids are baseId + index either way.
        /// </summary>
        /// <param name="latencyComp">
        /// Seconds since the client fired. Server side compensation only shortens
        /// the projectile's lifetime and never moves it, so it must not be taken
        /// from the start delay: that would spawn the delayed projectiles on top
        /// of each other and the burst would collapse into one shot. Every
        /// projectile keeps its full delay and gets the same lifetime cut.
        /// </param>
        /// <returns>Projectiles spawned now plus projectiles queued.</returns>
        public int SpawnStaggered(
            SpawnPoint[] points, int count, uint baseId, ushort configId, float speed,
            ProjectileConfigSO cfg, ServerProjectileData template, float latencyComp,
            Transform guidedTarget)
        {
            var context = new StaggeredShotContext
            {
                Template     = template,
                GuidedTarget = cfg.MovementType == ProjectileMovementType.Guided ? guidedTarget : null
            };

            int accepted = 0;
            for (int i = 0; i < count; i++)
            {
                float delay = points[i].StartDelay;
                var entry = new DelayedSpawnQueue.Entry
                {
                    Point    = points[i],
                    ProjId   = baseId + (uint)i,
                    ConfigId = configId,
                    Speed    = speed,
                    Elapsed  = latencyComp,
                    Kind     = DelayedSpawnKind.Server,
                    Context  = context
                };

                if (delay > 0f)
                {
                    entry.DueTime = _delayed.Now + delay;
                    _delayed.Enqueue(entry);
                    accepted++;
                }
                else if (SpawnServerPellet(entry, cfg))
                {
                    accepted++;
                }
            }
            return accepted;
        }

        private void OnQueuedPellet(DelayedSpawnQueue.Entry entry)
        {
            var cfg = ProjectileRegistry.Instance != null
                ? ProjectileRegistry.Instance.Get(entry.ConfigId)
                : null;
            if (cfg != null) SpawnServerPellet(entry, cfg);
        }

        private bool SpawnServerPellet(in DelayedSpawnQueue.Entry entry, ProjectileConfigSO cfg)
        {
            var context    = (StaggeredShotContext)entry.Context;
            var rustParams = ProjectileRegistry.Instance.GetRustSpawnParams(entry.ConfigId, entry.Speed);
            _singlePoint[0] = entry.Point;

            if (!cfg.Is3D)
            {
                var (ptr, rem) = Get2DWriteHead();
                int written = BatchSpawnHelper.SpawnBatch2D(
                    _singlePoint, 1, null, rustParams,
                    entry.ConfigId, 0, entry.ProjId, ptr, rem, entry.Elapsed);
                if (written <= 0) return false;

                NotifyBatchSpawned2D(written, entry.ProjId, context.Template);
                if (context.GuidedTarget != null)
                    ProjectileGuidanceTracker.Instance.RegisterGuidedTarget2D(entry.ProjId, context.GuidedTarget);
            }
            else
            {
                var (ptr, rem) = Get3DWriteHead();
                int written = BatchSpawnHelper.SpawnBatch3D(
                    _singlePoint, 1, rustParams,
                    entry.ConfigId, 0, entry.ProjId, ptr, rem, entry.Elapsed);
                if (written <= 0) return false;

                NotifyBatchSpawned3D(written, entry.ProjId, context.Template);
                if (context.GuidedTarget != null)
                    ProjectileGuidanceTracker.Instance.RegisterGuidedTarget3D(entry.ProjId, context.GuidedTarget);
            }
            return true;
        }

        public void NotifyBatchSpawned2D(int spawned, uint baseId, ServerProjectileData templateData)
        {
            for (uint i = 0; i < (uint)spawned; i++)
            {
                int  bufIdx = _count2D + (int)i;
                uint projId = baseId + i;
                var  data   = templateData.CloneForSpawn(projId, _projs2D[bufIdx].ConfigId);
                data.isCrit = UnityEngine.Random.value < data.critChance;
                Adapter.Register(data);
            }
            _count2D += spawned;
        }

        public void NotifyBatchSpawned3D(int spawned, uint baseId, ServerProjectileData templateData)
        {
            for (uint i = 0; i < (uint)spawned; i++)
            {
                int  bufIdx = _count3D + (int)i;
                uint projId = baseId + i;
                var  data   = templateData.CloneForSpawn(projId, _projs3D[bufIdx].ConfigId);
                data.is3D   = true;
                data.isCrit = UnityEngine.Random.value < data.critChance;
                Adapter.Register(data);
            }
            _count3D += spawned;
        }

        public (IntPtr ptr, int remaining) Get2DWriteHead()
        {
            IntPtr ptr = IntPtr.Add(
                _pinProjs2D.AddrOfPinnedObject(),
                _count2D * Marshal.SizeOf<NativeProjectile>());
            return (ptr, _maxProjectiles2D - _count2D);
        }

        public (IntPtr ptr, int remaining) Get3DWriteHead()
        {
            IntPtr ptr = IntPtr.Add(
                _pinProjs3D.AddrOfPinnedObject(),
                _count3D * Marshal.SizeOf<NativeProjectile3D>());
            return (ptr, _maxProjectiles3D - _count3D);
        }

        public uint AllocateProjIds(int count)
        {
            uint baseId = _nextProjId;
            _nextProjId += (uint)count;
            return baseId;
        }

        #endregion

        #region Public API — Targets

        public void RegisterTarget2D(in CollisionTarget target, int unityLayer = 0)
        {
            _targetLayerDict2D[target.TargetId] = unityLayer;
            for (int i = 0; i < _targetCount2D; i++)
            {
                if (_targets2D[i].TargetId != target.TargetId) continue;
                _targets2D[i] = target; return;
            }
            if (_targetCount2D >= _maxTargets2D) { LogWarning("2D target buffer full."); return; }
            _targets2D[_targetCount2D++] = target;
        }

        public void RegisterTarget3D(in CollisionTarget3D target, int unityLayer = 0)
        {
            _targetLayerDict3D[target.TargetId] = unityLayer;
            for (int i = 0; i < _targetCount3D; i++)
            {
                if (_targets3D[i].TargetId != target.TargetId) continue;
                _targets3D[i] = target; return;
            }
            if (_targetCount3D >= _maxTargets3D) { LogWarning("3D target buffer full."); return; }
            _targets3D[_targetCount3D++] = target;
        }

        public void DeactivateTarget2D(uint targetId)
        {
            for (int i = 0; i < _targetCount2D; i++)
                if (_targets2D[i].TargetId == targetId) { _targets2D[i].Active = 0; return; }
        }

        public void DeactivateTarget3D(uint targetId)
        {
            for (int i = 0; i < _targetCount3D; i++)
                if (_targets3D[i].TargetId == targetId) { _targets3D[i].Active = 0; return; }
        }

        public void ClearAllTargets()
        {
            _targetCount2D = 0;
            _targetCount3D = 0;
            _shapeCount2D  = 0;
            _shapeCount3D  = 0;
            _targetLayerDict2D.Clear();
            _targetLayerDict3D.Clear();
        }

        #endregion

        #region Public API — Shape Colliders (Box/Capsule/Edge/Polygon)
        //
        // Mirrors the Target API above exactly — same upsert-by-TargetId
        // pattern, same shared _targetLayerDict2D/3D (a shape hit's TargetId
        // flows through PassesLayerFilter2D/3D in Collision2D/3D identically
        // to a circle hit's, no separate shape-layer tracking needed).

        public void RegisterShape2D(in ShapeCollider2D shape, int unityLayer = 0)
        {
            _targetLayerDict2D[shape.TargetId] = unityLayer;
            for (int i = 0; i < _shapeCount2D; i++)
            {
                if (_shapes2D[i].TargetId != shape.TargetId) continue;
                _shapes2D[i] = shape; return;
            }
            if (_shapeCount2D >= _maxShapes2D) { LogWarning("2D shape buffer full."); return; }
            _shapes2D[_shapeCount2D++] = shape;
        }

        public void RegisterShape3D(in ShapeCollider3D shape, int unityLayer = 0)
        {
            _targetLayerDict3D[shape.TargetId] = unityLayer;
            for (int i = 0; i < _shapeCount3D; i++)
            {
                if (_shapes3D[i].TargetId != shape.TargetId) continue;
                _shapes3D[i] = shape; return;
            }
            if (_shapeCount3D >= _maxShapes3D) { LogWarning("3D shape buffer full."); return; }
            _shapes3D[_shapeCount3D++] = shape;
        }

        public void DeactivateShape2D(uint targetId)
        {
            for (int i = 0; i < _shapeCount2D; i++)
                if (_shapes2D[i].TargetId == targetId) { _shapes2D[i].Active = 0; return; }
        }

        public void DeactivateShape3D(uint targetId)
        {
            for (int i = 0; i < _shapeCount3D; i++)
                if (_shapes3D[i].TargetId == targetId) { _shapes3D[i].Active = 0; return; }
        }

        #endregion

        #region Public API — Guided

        public void SetAcceleration2D(uint projId, Vector2 accelDir)
        {
            for (int i = 0; i < _count2D; i++)
            {
                if (_projs2D[i].ProjId != projId) continue;
                Vector2 n = accelDir.normalized;
                _projs2D[i].Ax = n.x; _projs2D[i].Ay = n.y;
                return;
            }
        }

        public void SetAcceleration3D(uint projId, Vector3 accelDir)
        {
            for (int i = 0; i < _count3D; i++)
            {
                if (_projs3D[i].ProjId != projId) continue;
                Vector3 n = accelDir.normalized;
                _projs3D[i].Ax = n.x; _projs3D[i].Ay = n.y; _projs3D[i].Az = n.z;
                return;
            }
        }

        /// <summary>
        /// Live position lookup by ProjId — added for ProjectileGuidanceTracker,
        /// which needs "where is this projectile right now" every tick to compute
        /// a fresh direction-to-target before calling SetAcceleration2D/3D. Linear
        /// scan like every other by-ProjId lookup in this file (GetConfigId2D/3D,
        /// IsOwnedBy) — fine at these buffer sizes, not worth a dictionary given
        /// how often the whole buffer already gets scanned per tick anyway.
        /// </summary>
        public bool TryGetPosition2D(uint projId, out Vector2 pos)
        {
            for (int i = 0; i < _count2D; i++)
            {
                if (_projs2D[i].ProjId != projId) continue;
                pos = new Vector2(_projs2D[i].X, _projs2D[i].Y);
                return true;
            }
            pos = default;
            return false;
        }

        public bool TryGetPosition3D(uint projId, out Vector3 pos)
        {
            for (int i = 0; i < _count3D; i++)
            {
                if (_projs3D[i].ProjId != projId) continue;
                pos = new Vector3(_projs3D[i].X, _projs3D[i].Y, _projs3D[i].Z);
                return true;
            }
            pos = default;
            return false;
        }

        #endregion

        #region State Save / Restore

        public int SaveState2D(byte[] buf)
        {
            if (buf == null || buf.Length < _count2D * 72) return 0;
            var pin = GCHandle.Alloc(buf, GCHandleType.Pinned);
            int n   = ProjectileLib.save_state(
                _pinProjs2D.AddrOfPinnedObject(), _count2D,
                pin.AddrOfPinnedObject(), buf.Length);
            pin.Free();
            return n;
        }

        public int RestoreState2D(byte[] buf, int byteCount)
        {
            if (buf == null || byteCount <= 0) return 0;
            var pin = GCHandle.Alloc(buf, GCHandleType.Pinned);
            ProjectileLib.restore_state(
                _pinProjs2D.AddrOfPinnedObject(), _maxProjectiles2D,
                pin.AddrOfPinnedObject(), byteCount,
                out int restored);
            pin.Free();
            _count2D = restored;
            return restored;
        }

        #endregion

        #region Headshot / Events

        protected virtual bool CheckHeadshot2D(in HitResult   hit) => false;
        protected virtual bool CheckHeadshot3D(in HitResult3D hit) => false;
        private void OnAdapterProjectileDied(uint projId) { }

        #endregion

        #region Utilities

        private static bool IsServer()
            => NetworkManager.Singleton != null && NetworkManager.Singleton.IsServer;

        private void Log(string msg)
        {
            if (_enableLogs) MID_HelperFunctions.LogDebug(msg, nameof(ServerProjectileAuthority));
        }

        private void LogWarning(string msg)
            => MID_HelperFunctions.LogWarning(msg, nameof(ServerProjectileAuthority));

        #endregion
    }
}
